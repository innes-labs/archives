img2ppk V1.11.10: user manual

img2ppk permits to convert a .bmp or .png picture into .ppk picture, in order to be displayed on a SLATE106.

.bmp file characteristics:
	- 800x600
	- RGB, 24bits
.png file characteristics: 
	- 800x600 
	- Any PNG file

As SLATE106 .ppk format is a 4-level grey color, the conversion may make disappear some parts of the original picture, because it passes from 16M colors to 4 colors.

If the .bmp size doesn't match 800x600, it will be resized (without ratio deformation), but it is adviced to respect the 800x600 size.
Png files have to be 800x600.

For .bmp and .png source files : 
Launch img2ppk.exe. It asks to select source file. When selected, it asks for the name of the destination .ppk file. 
- select the drive on which SLATE106 appears, and 
- call the destination file "spe.ppk". 
- Close img2ppk. 
- Then, eject properly your SLATE106.

For .bmp and .png source files : 
Call img2ppk.exe in command-line interface with the .bmp on .png file as argument. It generates a .ppk file with the same base name as the input file.
- select the drive on which SLATE106 appears in the File Explorer
- Copy the generated .ppk file as "spe.ppk".
- Then, eject properly your SLATE106.

Refer to SLATE106 user manual to obtain more information on how to display an image on a SLATE106.


