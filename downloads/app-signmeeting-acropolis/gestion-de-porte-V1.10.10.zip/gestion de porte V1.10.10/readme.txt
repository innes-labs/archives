The file .hta is an executable file to change the value of the variable 'Doorclosed' on a Gekkota player.

To change the IP of the player, you have to edit the .HTA file, and change the value of the part 'players' :

<script type="text/javascript">
			var buttons = [
							{label:"Ouvrir", src:"open"},
							{label:"Fermer", src:"close"}
						];

			var players = [
							{host:"192.168.1.21", username:"admin", password:"admin"}
						];
		</script>