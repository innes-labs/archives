<#
.SYNOPSIS
This script allows you to install firmware, an app, or a configuration script on a pool of devices
.DESCRIPTION
This script allows you to install firmware, an app, or a configuration script on a pool of devices.
The type of component to install is specified with the -installType option which can be "install", "app" or "comfiguration".
The components to be installed are stored in the directory specified by the "installDirPath" option. Each type of device has an associated subdirectory:

+ `aqs` for Aqs device,
+ `gekkota` for Gekkota device,
+ `bm0032` for Bm0032 device.
.PARAMETER jsonDevicesFilePath
The path of the json file which contains the list of devices. The default value is ".\devices.json"
.PARAMETER installType
the components type to install. Can be "firmware" (default), "app" or "configuration"
.PARAMETER installDirPath
The path to the directory that contains the components to install. The default value is ".\install"
.PARAMETER logFile
The path of log file
.EXAMPLE
PS .\Get-AqsAppsInformations"
.NOTES
VERSION:1.10.11
#>
[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$false)]
    [string] $jsonDevicesFilePath = ".\devices.json",
    [string] $installType = "firmware",
    [string] $installDirPath = ".\install",
    [string] $LogFile="installDevices.log"
)
Import-Module PSDevice
if (-Not (Test-Path -path  $jsonDevicesFilePath)) {
    throw "wrong path of devices file"
}
if (-Not (Test-Path -path  $installDirPath)) {
    throw "wrong path of source installation directory"
}
# Clear the log file of any previous try
If ($LogFile -and (Test-Path $LogFile) -eq $True) {
    Remove-Item -Path $LogFile
}
$global:verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
$global:LogFile = $LogFile

[System.Collections.ArrayList] $devicesInfo = @();
$config = Get-Content -Path $jsonDevicesFilePath | ConvertFrom-Json
foreach ($device in $config.devices) {
    if (-not (Test-Connection $device.host -Quiet -Count 1))
    {
        Write-Host("device " + $device.host + " not responding")
        continue;
    }
    if ($Authentication = Test-GktDevice -urlHost $device.host -urlLogin $device.login -urlPassword $device.password) {
        $dir="$installDirPath\\gekkota\"
        if ($installType -eq "firmware") {
            $infoGeneral = Get-GktInfos -urlHost $device.host -urlLogin $device.login -urlPassword $device.password
            $platform=$infoGeneral.platform.toLower()
            $filter = "$dir\*$platform*.frm"
            $list = Get-ChildItem -Path $filter
            foreach ($file in $list)
            {
                $name = $file.name;
                Write-Host("Install firmware `"" + $file.name + "`" on Gekkota device `"" + $device.host + "`"")
                Install-GktFirmware -firmwareFile $file -urlHost $device.host -urlLogin $device.login -urlPassword $device.password -Authentication $Authentication
                break;
            }
        } elseif ($installType -eq "configuration") {
            $list = Get-ChildItem -Path "$dir\*.js"
            foreach ($file in $list)
            {
                Write-Host("Install configuration `"" + $file.name + "`" on Gekkota device `"" + $device.host + "`"")
                Install-GktConfiguration -configurationFile $file -urlHost $device.host -urlLogin $device.login -urlPassword $device.password -Authentication $Authentication
                break;
            }
        }
    }
    elseif (Test-AqsDevice -urlHost $device.host -urlLogin $device.login -urlPassword $device.password) {
        $dir="$installDirPath\\aqs\"
        if ($installType -eq "firmware") {
            $infoGeneral = Get-AqsInfos -urlHost $device.host -urlLogin $device.login -urlPassword $device.password
            $platform=$infoGeneral.platform.toLower()
            $filter = "$dir\*$platform*.fqs"
            $list = Get-ChildItem -Path $filter
            foreach ($file in $list)
            {
                Write-Host("Install firmware `"" + $file.name + "`" on Aqs device `"" + $device.host + "`"")
                Install-AqsFirmware -firmwareFile $file -urlHost $device.host -urlLogin $device.login -urlPassword $device.password 
                break;
            }
        } elseif ($installType -eq "configuration") {
            $list = Get-ChildItem -Path "$dir\*.js"
            foreach ($file in $list)
            {
                Write-Host("Install configuration `"" + $file.name + "`" on Aqs device `"" + $device.host + "`"")
                Install-AqsConfiguration -configurationFile $file -urlHost $device.host -urlLogin $device.login -urlPassword $device.password 
                break;
            }
        }
        elseif ($installType -eq "app") {
            $list = Get-ChildItem -Path "$dir\*.apk"
            foreach ($file in $list)
            {
                Write-Host("Install App `"" + $file.name + "`" on Aqs device `"" + $device.host + "`"")
                Install-AqsApp -apkFile $file -urlHost $device.host -urlLogin $device.login -urlPassword $device.password 
                break;
            }
        }
    }
    elseif (Test-Bm0032Device -urlHost $device.host -urlLogin $device.login -urlPassword $device.password) {
        $dir="$installDirPath\\bm0032\"
        if ($installType -eq "firmware") {
            $infoGeneral = Get-Bm0032Infos -urlHost $device.host -urlLogin $device.login -urlPassword $device.password
            $platform=$infoGeneral.model.toLower()
            $filter = "$dir\bm0032*$platform*.bin"
            $list = Get-ChildItem -Path $filter
            foreach ($file in $list)
            {
                Write-Host("Install firmware `"" + $file.name + "`" on Bm0032 device `"" + $device.host + "`"")
                Install-Bm0032Firmware -firmwareFile $file -urlHost $device.host -urlLogin $device.login -urlPassword $device.password 
                break;
            }
        }
        elseif ($installType -eq "configuration") {
            $list = Get-ChildItem -Path "$dir\*.js"
            foreach ($file in $list)
            {
                Write-Host("Install configuration `"" + $file.name + "`" on Bm0032 device `"" + $device.host + "`"")
                Install-Bm0032Configuration -configurationFile $file -urlHost $device.host -urlLogin $device.login -urlPassword $device.password 
                break;
            }
    }
    }
}