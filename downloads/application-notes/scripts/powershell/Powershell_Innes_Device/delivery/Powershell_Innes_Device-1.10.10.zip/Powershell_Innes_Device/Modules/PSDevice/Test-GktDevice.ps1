Function Test-GktDevice {
<# 
.SYNOPSIS
This function test if a host is an Gekkota device
.DESCRIPTION
This function queries a Gkt device to retrieve general information of device
.PARAMETER urlHost
The Gkt device host (IP or DNS domain)
.PARAMETER urlPort
The  Gkt device port (empty by default)
.PARAMETER urlLogin
The login of authentication
.PARAMETER urlPassword
The password of authentication
.PARAMETER logFile
The path of log file
.OUTPUTS 
returns the type of authentication "basic" or "digest" if the device is a Gekkota platform, if not return $null
$true or $false
.EXAMPLE
$auth = Test-GktDevice -urlHost 192.168.1.186 -urlLogin admin -urlPassword admin
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)


$device=$urlHost
if ($urlPort) {
   $device += ":" + $urlPort
}
$BaseDeviceUri = "http://$device/.playout/"
# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Test Gekkota device `"$device`"")

if (-not (Test-Connection $device -Quiet -Count 1)) {
    LogWrite("device `"$device`" not reponding")
    return $false
}

try {
    $ExecutedRequest =  MakeRequest -Method 'GET' -ContentType 'application/json;charset=utf-8' -Uri "$BaseDeviceUri"
    if ($ExecutedRequest.StatusCode -eq 200) {
        return "basic"
    }
}
catch {
    $UrlLogin="$UrlLogin@realm"
    try {
        $ExecutedRequest =  MakeRequest -Method 'GET' -ContentType 'application/json;charset=utf-8' -Uri "$BaseDeviceUri"
        if ($ExecutedRequest.StatusCode -eq 200) {
            return "digest"
        }
    }
    catch {
        return $null
    }
}
return $null
}




# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUNxh7AqDvA87uv0UgyGwWAyYb
# EVygggP3MIID8zCCAtugAwIBAgIQK9H4d0OBsJBMAJr7o5+5OTANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTI0
# MDcwODExNTg0NVoXDTI1MDcwODEyMTg0NVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALYc/bCz
# jCYPFlXgYFCHxGORJgU1SV9Dbuq29DLEnsHyq5lKi4/kKFVcXtLuSVML1XRogDFg
# BXMaJXqG5SBG3teuaaXHNhN08NLURNQn2uFRH/J9P7hfPxjPiprdR0uxXuiFCase
# q508ACLiCq0iq+JXVZI7vEc7+ry3ns49stCcg2GBYhi6PSYi7zjNUKvrciAuLjUY
# IUdodGZGPlDU58JuU19agZmcOpxb/6RZoEUdhBB++Y8mNDUZI2VsoHa9j0imUpoI
# QMjVG1mrrvx5V6DS/UCZnvJxc5ucQMCz9mDpYZ7UD7bSZ+1De570h6wL1e69ZX0J
# sOfz5xV9V57hI/ECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBR6Gl4CUkwT/9Hgcww6bHn1vOFkaTANBgkqhkiG9w0BAQsFAAOCAQEASR33
# EG9LerM80avGHziPYtzTcktixbn0rfaTIXS02OVvZhT6nXFAwBCoRb1JpP4X3FFC
# 0sde1wXwMAR/Vet+PDwcjzsC/z2sZUmDTB4ecXqCDR4FC+Jh6f0YWJY5iilfh3mY
# Wq22ZYBp11WHABegV9ipgK7jILs9zaJWcTADqir6CvILNqfZhQp+0PV8QMpY3SZr
# 2O1iogmLv5tnJn0BKpBNzKsMweKQDGUAg6JIuWcCwPK+oO27Yk5BoT19djaOft6i
# SGPe7Ig/7ieEurj2ZsrwWDCf3XAlD4Qs69Komum9BRjzq1LMMtHsXP/lxqutZNkP
# mq/gaq4irhELfj2yYTGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECvR+HdDgbCQTACa+6OfuTkwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFIz/a/rSz71UJ0Pg4C3jdiY6SidzMA0GCSqGSIb3DQEBAQUABIIBAEN3HNmG
# OTRTD92t/JHj4gxdkLe0PRF+6oiB3FFpd7E1o0CmmPAXL31MJd68o0yzg5oVw3ff
# GgNWsXcmA5CJUvsnsCw+FOGMktnMnAbb5Q4ZsZB4N7mKqQDorsRDUHmVULIlu65r
# bqj/0ajKPKxlR48Fvap5XQyn59DEUDT7mkcREFvxDL1PIyZq/kzFMoIa4D9AttoR
# 1sXQO4TyoPXZMQOJSCYEwRA4kEhH5JHXObH5MQ16l6qAXQwwixJqRAZtGDk7rR+W
# G8p6C062TE7uyeHQNlJPrAGyS+ddC9ECPR4Iv7q7o1rs2x0K/CC5f438ThFIRXQz
# yBgqeR+Cnx0Hhcs=
# SIG # End signature block
