Function Restart-AqsApp {
<# 
.SYNOPSIS
This function queries a Aqs device to restart an app
.DESCRIPTION
This function queries a Aqs device to restart an app
.PARAMETER appName
The name of App to restart
The Aqs device host (IP or DNS domain)
.PARAMETER urlHost
The Aqs device host (IP or DNS domain)
.PARAMETER urlPort
The  Aqs device port (empty by default)
.PARAMETER urlLogin
The login of authentication
.PARAMETER urlPassword
The password of authentication
.PARAMETER logFile
The path of log file
.OUTPUTS 
nothing
.EXAMPLE
Restart-AqsApp -appName "tech.qeedji.powerbi_online_viewer" -urlHost 192.168.1.186 -urlLogin admin -urlPassword admin
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $AppName,
    [string] $UrlHost,
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)


$device=$urlHost
if ($urlPort) {
   $device += ":" + $urlPort
}
$BaseDeviceUri = "http://$device/odata.qs/v1/"
$Uri = "$BaseDeviceUri/Apps('$AppName')"
$UrlLogin="$UrlLogin@realm"
$Body = @{
    Status = "Running"
}
$JsonBody = $Body | ConvertTo-Json
# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve apps for device `"$device`"")
 

try {
    $request=MakeRequest -Method 'PATCH' -ContentType 'application/json;charset=utf-8' -Uri "$Uri" -Body "$JsonBody"
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}
}




# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUFxedoE4gX6/ds8wtEsizVU/x
# CJOgggP3MIID8zCCAtugAwIBAgIQK9H4d0OBsJBMAJr7o5+5OTANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTI0
# MDcwODExNTg0NVoXDTI1MDcwODEyMTg0NVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALYc/bCz
# jCYPFlXgYFCHxGORJgU1SV9Dbuq29DLEnsHyq5lKi4/kKFVcXtLuSVML1XRogDFg
# BXMaJXqG5SBG3teuaaXHNhN08NLURNQn2uFRH/J9P7hfPxjPiprdR0uxXuiFCase
# q508ACLiCq0iq+JXVZI7vEc7+ry3ns49stCcg2GBYhi6PSYi7zjNUKvrciAuLjUY
# IUdodGZGPlDU58JuU19agZmcOpxb/6RZoEUdhBB++Y8mNDUZI2VsoHa9j0imUpoI
# QMjVG1mrrvx5V6DS/UCZnvJxc5ucQMCz9mDpYZ7UD7bSZ+1De570h6wL1e69ZX0J
# sOfz5xV9V57hI/ECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBR6Gl4CUkwT/9Hgcww6bHn1vOFkaTANBgkqhkiG9w0BAQsFAAOCAQEASR33
# EG9LerM80avGHziPYtzTcktixbn0rfaTIXS02OVvZhT6nXFAwBCoRb1JpP4X3FFC
# 0sde1wXwMAR/Vet+PDwcjzsC/z2sZUmDTB4ecXqCDR4FC+Jh6f0YWJY5iilfh3mY
# Wq22ZYBp11WHABegV9ipgK7jILs9zaJWcTADqir6CvILNqfZhQp+0PV8QMpY3SZr
# 2O1iogmLv5tnJn0BKpBNzKsMweKQDGUAg6JIuWcCwPK+oO27Yk5BoT19djaOft6i
# SGPe7Ig/7ieEurj2ZsrwWDCf3XAlD4Qs69Komum9BRjzq1LMMtHsXP/lxqutZNkP
# mq/gaq4irhELfj2yYTGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECvR+HdDgbCQTACa+6OfuTkwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFCDt8Rx21Zv7u20b++LQWSNk59MnMA0GCSqGSIb3DQEBAQUABIIBAGUfIK4Z
# vnsaDwvkQ+ZDA9Mz0fpDI5K9uJ15c5Hm2waPgEf4AXOWg94oKqyy1n9A3sQplCm7
# h5nsr1AqC/HXKDswLFi4T29hTBw5Gu0BBUCWxjLYNgxzjRD2sf5ddXDcu6KGCP7i
# P1vz5rOerrW+FyK6xwzh5wilFy2nJ6RNnb04Zexpr43nWTlrTf02e1yqqKpXDxuo
# a6DC6QhVQ2F7HWs9qhH8e1UhrZoNvY3dYbRA+I42bWDD+82aXF7Y+TRN0K9Xb2W7
# B6QhmpIakCRB6d8OFtCREGoMuqViJWfST0syOmka/nde05Ty0qTEzzplpy5u0lZc
# YSsJ/1vGQeVEMOE=
# SIG # End signature block
