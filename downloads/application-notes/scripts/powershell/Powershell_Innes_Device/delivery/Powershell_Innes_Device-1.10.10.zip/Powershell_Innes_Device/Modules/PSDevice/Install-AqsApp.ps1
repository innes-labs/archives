Function Install-AqsApp {
<# 
.SYNOPSIS
This function queries a Aqs device to install an app
.DESCRIPTION
This function queries a Aqs device to install an app
.PARAMETER apkFile
The APK file path of App to install
The Aqs device host (IP or DNS domain)
.PARAMETER urlHost
The Aqs device host (IP or DNS domain)
.PARAMETER urlPort
The  Aqs device port (empty by default)
.PARAMETER urlLogin
The login of authentication.
.PARAMETER urlPassword
The password of authentication.
.PARAMETER logFile
The path of log file
.OUTPUTS 
nothing
.EXAMPLE
Install-AqsApp -apkFile "powerbi_online_viewer-qeedjisystem_aosp-setup-1.10.11.apk" -urlHost 192.168.1.186 -urlLogin admin -urlPassword admin
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $ApkFile,
    [string] $UrlHost,
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)


$device=$urlHost
if ($urlPort) {
   $device += ":" + $urlPort
}
if ((Test-Path -path $ApkFile) -ne $True) {
    throw "bad apk file path"
}
$File = Get-Item $ApkFile
$name = $File.BaseName + $File.Extension
$BaseDeviceUri = "http://$device/.apps"
$Uri = "$BaseDeviceUri/$name"

$UrlLogin="$UrlLogin@realm"
# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Install App on device `"$device`"")
 

try {
    $request=MakeRequest -Method 'PUT' -ContentType 'application/octet-stream' -Uri "$Uri" -Infile $ApkFile
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}
}




# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUohMM/MgQYfnbvVcZ3/eUD9N6
# jNGgggP3MIID8zCCAtugAwIBAgIQK9H4d0OBsJBMAJr7o5+5OTANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTI0
# MDcwODExNTg0NVoXDTI1MDcwODEyMTg0NVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALYc/bCz
# jCYPFlXgYFCHxGORJgU1SV9Dbuq29DLEnsHyq5lKi4/kKFVcXtLuSVML1XRogDFg
# BXMaJXqG5SBG3teuaaXHNhN08NLURNQn2uFRH/J9P7hfPxjPiprdR0uxXuiFCase
# q508ACLiCq0iq+JXVZI7vEc7+ry3ns49stCcg2GBYhi6PSYi7zjNUKvrciAuLjUY
# IUdodGZGPlDU58JuU19agZmcOpxb/6RZoEUdhBB++Y8mNDUZI2VsoHa9j0imUpoI
# QMjVG1mrrvx5V6DS/UCZnvJxc5ucQMCz9mDpYZ7UD7bSZ+1De570h6wL1e69ZX0J
# sOfz5xV9V57hI/ECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBR6Gl4CUkwT/9Hgcww6bHn1vOFkaTANBgkqhkiG9w0BAQsFAAOCAQEASR33
# EG9LerM80avGHziPYtzTcktixbn0rfaTIXS02OVvZhT6nXFAwBCoRb1JpP4X3FFC
# 0sde1wXwMAR/Vet+PDwcjzsC/z2sZUmDTB4ecXqCDR4FC+Jh6f0YWJY5iilfh3mY
# Wq22ZYBp11WHABegV9ipgK7jILs9zaJWcTADqir6CvILNqfZhQp+0PV8QMpY3SZr
# 2O1iogmLv5tnJn0BKpBNzKsMweKQDGUAg6JIuWcCwPK+oO27Yk5BoT19djaOft6i
# SGPe7Ig/7ieEurj2ZsrwWDCf3XAlD4Qs69Komum9BRjzq1LMMtHsXP/lxqutZNkP
# mq/gaq4irhELfj2yYTGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECvR+HdDgbCQTACa+6OfuTkwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFDhM1exxBPpJCqUeNWT335j3B8YCMA0GCSqGSIb3DQEBAQUABIIBAHcRE2qi
# zpUb5WbwS25nZP8ABMCa0rDt+Jl1Af/6XxGqz/hTyqBPbTp2NWzrUWjFs5OORsS5
# u7lrzARrcUX1LesGLp/S/lG1dyf9FPZfKKkRZ9K/MsglF7edPZLOUJxclH1lcqQH
# ZN7J5zEcnyXHJecKzJTC8/89tJhXPen0j+Yk9rDht35Si8dd8WQAgQ6MuAuCUSTA
# 78Rik9V2JTF39y5Cqi4qQTgxOfbutMLX1bW32q/GNKYDn5CZIkrfQH59+AgfXuQZ
# pmDzO/EZRoS4yTrEx0lIkeHBcZFqXTpk2amSOdFS/hwiX8uO6uQYD+0yPKQg8sKM
# m5BYGBYtbiPWM5A=
# SIG # End signature block
