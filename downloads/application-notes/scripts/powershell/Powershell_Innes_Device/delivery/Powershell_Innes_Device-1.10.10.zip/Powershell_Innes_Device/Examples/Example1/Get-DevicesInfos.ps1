<#
.SYNOPSIS
This script allows you to retrieve information from a device pool
.DESCRIPTION
This script allows you to retrieve information from a device pool
.PARAMETER jsonDevicesFilePath
The path of the json file which contains the list of devices. The default value is ".\devices.json"
.PARAMETER jsonResultFilePath
The path of the json file which contains the result. The default value is ".\result.json"
.PARAMETER logFile
The path of log file
.EXAMPLE
PS C:\install directory>.\Get-DevicesInfos"
.NOTES
VERSION:1.10.12
#>
[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$false)]
    [string] $jsonDevicesFilePath = ".\devices.json",
    [string] $jsonResultFilePath = ".\result.json",
    [string] $LogFile
)
Import-Module PSDevice
# Clear the log file of any previous try
If ($LogFile -and (Test-Path $LogFile) -eq $True) {
    Remove-Item -Path $LogFile
}
$global:verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
$global:LogFile = $LogFile

Write-host "Get devices Informations..."
[System.Collections.ArrayList] $devicesInfo = @();
$config = Get-Content -Path $jsonDevicesFilePath | ConvertFrom-Json
foreach ($device in $config.devices) {
    if (-not (Test-Connection $device.host -Quiet -Count 1))
    {
        LogWrite("device " + $device.host + " not responding")
        $info= [ordered]@{
            host=$device.host
            error="Not responding"
        }
        $devicesInfo.Add($info) | Out-Null
    }
    elseif (Test-AqsDevice -urlHost $device.host -urlLogin $device.login -urlPassword $device.password) {
        $apps = Get-AqsApps -urlHost $device.host -urlLogin $device.login -urlPassword $device.password
        $infoGeneral = Get-AqsInfos -urlHost $device.host -urlLogin $device.login -urlPassword $device.password
        $infoGeneral.runningApps = $apps;
        $info= [ordered]@{
            host=$device.host
            info= $infoGeneral;
        }
        $devicesInfo.Add($info) | Out-Null
    }
    elseif ($Authentication = Test-GktDevice -urlHost $device.host -urlLogin $device.login -urlPassword $device.password) {
        $infoGeneral = Get-GktInfos -urlHost $device.host -urlLogin $device.login -urlPassword $device.password -Authentication $Authentication
        $info= [ordered]@{
            host=$device.host
            info= $infoGeneral;
        }
        $devicesInfo.Add($info) | Out-Null
    }
    elseif (Test-Bm0032Device -urlHost $device.host -urlLogin $device.login -urlPassword $device.password) {
        $infoGeneral = Get-Bm0032Infos -urlHost $device.host -urlLogin $device.login -urlPassword $device.password
        $info= [ordered]@{
            host=$device.host
            info= $infoGeneral;
        }
        $devicesInfo.Add($info) | Out-Null
    }
    else {
        $info= [ordered]@{
            host=$device.host
            error="Unknow device"
        }
        $devicesInfo.Add($info) | Out-Null
    }
}

Write-host "Write the result into the file" $jsonResultFilePath "..."
$devicesInfo | ConvertTo-Json -Depth 5 | Out-File $jsonResultFilePath
