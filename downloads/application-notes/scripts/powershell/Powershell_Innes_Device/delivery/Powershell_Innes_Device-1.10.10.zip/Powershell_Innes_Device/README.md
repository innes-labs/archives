# Qeedji devices Powershell modules

## Introduction

This set of *Powershell* functions allows to:

for AQS devices :

+ retrieve general information of device, with the `Get-AqsInfos`, functions,
+ to retrieve all installed APPs, with the `Get-AqsApps` function,
+ install new App with the `Install-AqsApp` function,
+ remove an App with the `Remove-AqsApp` function,
+ restart new App with the `Restart-AqsApp` function,
+ stop new App with the `Stop-AqsApp` function,
+ install a new firmware with the `Install-AqsFirmware` function.
+ install a configuration script with the `Install-AqsConfiguration` function.

for Bm0032 devices :

+ retrieve general information of device, with the `Get-Bm0032Infos`, functions,
+ install a new firmware with the `Install-Bm0032Firmware` function.
+ install a configuration script with the `Install-Bm0032Configuration` function.

for Gekkota devices :

+ retrieve general information of device, with the `Get-GtkInfos`, functions,
+ install a new firmware with the `Install-GtkFirmware` function,
+ install a configuration script with the `Install-GtkConfiguration` function.

*These functions are defined in the `PSDevice` PowerShell module stored in the `Modules\PSDevice\` directory.*

## Security

By default, the execution of local *Powershell* scripts are not allowed. You can change their execution rights by changing the *PowerShell* security policy. This modification has to be done once with the `Set-ExecutionPolicy` *Powershell* function. Your organization may have to change it according to your security rules.  

For example, to authorize the execution of all scripts, launch a *Powershell* console with administrator rights, and type: 

````powershell
PS > Set-ExecutionPolicy -ExecutionPolicy Unrestricted -scope CurrentUser
````

For further information, look at the cmdlet `Set-ExecutionPolicy` help page.  

If you cannot allow the execution of unsigned local scripts, you can install the provided certificate in the list of authorized root certificates with the command:

````powershell
PS > cd <your_path_to_the_scripts>\Powershell_Innes_Device\Certificate\
PS > Import-PfxCertificate -FilePath InnesCodeSigningRootCA_1.pfx -CertStoreLocation cert:\CurrentUser\Root -Password $(ConvertTo-SecureString "1234" -AsPlainText -Force)
````

*To import the .pfx certificate, you can also use the MS-Windows application `certmgr.msc`, select the `Trusted Root Certification Authorities`, right clic on `All Tasks`, select the `Import` item, select the file and enter the password `1234`. When ended, close the current Powershell console.*  

<div style="page-break-after: always;"></div>


## Usage

To use Device *Powershell* modules, you have 3 possibilities:

+ Either copy the directories under `Modules\` into a standard *Powershell* module installation directory, for example "C:\Program Files\WindowsPowerShell\Modules". Then launch a *Powershell* console.
+ Or redefine the search variable for *Powershell* modules (the `$Env:PSModulePath` *Powershell* variable) each time you will use theses functions. In this case, launch a *Powershell* console, and type the line below, adapting it to your path. Each time you will launch a new *Powershell* console, you will have to enter it again.  

For example:

````powershell
PS > $Env:PSModulePath="$Env:PSModulePath;<your_path_to_the_scripts>\Powershell_Innes_Device\Modules"
````

+ Or redefine the search variable for *Powershell* modules in the Windows environment variables. For that, add the path `<your_path_to_the_scripts>\Powershell_Innes_Device\Modules` to the environment variable `PSModulePath`. Then, launch afterwards a *Powershell* console.

To use the functions or get help, you must then import the module(s) with the `Import-Module` function. Example:

````powershell
PS > Import-Module PSDevice
````

Depending on how your get the scripts, you may have this following warning:  

````powershell
Security Warning Run only scripts that you trust. While scripts from the Internet can be useful, this script can potentially harm your computer. Do you want to run \device\scripts\my.ps1? [D] Do not run [R] Run once [S] Suspend [?] Help (default is "D"):
````

To avoid this message, you can unblock the script files (to do only once):

````powershell
PS > cd <your_path_to_the_scripts>\Powershell_Innes_Device\
PS > dir -Recurse | Unblock-File
````

The `Get-Command` function allows you to list the functions defined in a module. Example:  

````powershell
PS > Get-Command -Module PSDevice
````
Answer example:
```powershell
CommandType     Name                                               Version    Source
-----------     ----                                               -------    ------
Function        Disable-AqsApp                                     1.10.10    PSDevice
Function        Enable-AqsApp                                      1.10.10    PSDevice
Function        Get-AqsApps                                        1.10.10    PSDevice
Function        Get-AqsInfos                                       1.10.10    PSDevice
Function        Get-Bm0032Infos                                    1.10.10    PSDevice
Function        Get-GktInfos                                       1.10.10    PSDevice
Function        Install-AqsApp                                     1.10.10    PSDevice
Function        Install-AqsConfiguration                           1.10.10    PSDevice
Function        Install-AqsFirmware                                1.10.10    PSDevice
Function        Install-Bm0032Firmware                             1.10.10    PSDevice
Function        Install-Bm0032Configuration                        1.10.10    PSDevice
Function        Install-GktConfiguration                           1.10.10    PSDevice
Function        Install-GktFirmware                                1.10.10    PSDevice
Function        LogWrite                                           1.10.10    PSDevice
Function        Remove-AqsApp                                      1.10.10    PSDevice
Function        Restart-AqsApp                                     1.10.10    PSDevice
Function        Stop-AqsApp                                        1.10.10    PSDevice
Function        Test-AqsDevice                                     1.10.10    PSDevice
Function        Test-Bm0032Device                                  1.10.10    PSDevice
Function        Test-GktDevice                                     1.10.10    PSDevice
```

You can get help on each function of the module by using the standard cmdlet `Get-Help` with options:

+ `-detailed`,

+ `-full`,

+ `-examples`.

Example:

````powershell
PS > Get-Help -detailed Install-AqsApp
````

## Examples

In the directory `Examples`, you can find different powershell scripts which uses the functions of the modules.

You can get help on each example scripts, for example:

````powershell
PS > Get-Help -detailed .\Examples\Example1\Get-DevicesInfos.ps1
````

### Example 1

The script `Examples\Example1\Get-DevicesInfos` is an example to retrieve informations about a pool of devices described in a json file. It uses the module `PSDevice`.  
Example:

````powershell
PS > cd <your_path_to_the_scripts>\Powershell_Innes_Pnc\Examples\Example1\
PS > .\Get-PSDevice.ps1 -LogFile result.txt
````

If any error occurs, look at the logfile (`result.txt` in the example) to see what the problem may be.  

### Example 2

The script `Examples\Example1\Install-Devices` is an example to install firmware, an app, or a configuration script on a pool of devices described in a json file. The type of component to install is specified with the -installType option which can be "install", "app" or "comfiguration".
The components to be installed are stored in the directory specified by the "installDirPath" option. Each type of device has an associated subdirectory:

+ `aqs` for Aqs device,
+ `gekkota` for Gekkota device,
+ `bm0032` for Bm0032 device.

It uses the module `PSDevice`.  
Example:

````powershell
PS > cd <your_path_to_the_scripts>\Powershell_Innes_Pnc\Examples\Example2\
PS > .\Install-Devices.ps1
````

If any error occurs, look at the logfile (`result.txt` in the example) to see what the problem may be. 

