Function Install-GktConfiguration {
    <# 
    .SYNOPSIS
    This installs configuration on a Gekkota device
    .DESCRIPTION
    This installs configuration on a Gekkota device
    .PARAMETER configurationFile
    The Configuration file path to install
    .PARAMETER urlHost
    The Gkt device host (IP or DNS domain)
    .PARAMETER urlPort
    The  Gkt device port (empty by default)
    .PARAMETER urlLogin
    The login of authentication.
    .PARAMETER urlPassword
    The password of authentication.
    .PARAMETER authentication
    Type of authentication : "basic" or "digest" (default)
    .PARAMETER logFile
    The path of log file
    .OUTPUTS 
    nothing
    .EXAMPLE
    Install-GktConfiguration -configurationFile "aosp-amp300-setup-9.11.10_alpha2.fqs" -urlHost 192.168.1.186 -urlLogin admin -urlPassword admin
    .NOTES
    VERSION:1.10.10
    #>
    
    [CmdletBinding()] 
    param(
        [Parameter(Mandatory=$true)]
        [string] $ConfigurationFile,
        [string] $UrlHost,
        [string] $UrlPort,
        [string] $UrlLogin,
        [string] $UrlPassword,
        [string] $Authentication="digest",
        [string] $LogFile
    )
    

    $device=$urlHost
    if ($urlPort) {
       $device += ":" + $urlPort
    }
    if (-Not (Test-Path -path  $ConfigurationFile)) {
        throw "bad configuration file path"
    }
    $File = Get-Item -path $ConfigurationFile
    $name = $File.BaseName + $File.Extension
    $BaseDeviceUri = "http://$device/.extension"
    $Uri = "$BaseDeviceUri/$name"
    if ($Authentication -eq "digest") {
        $UrlLogin="$UrlLogin@realm"
    }    # Load utilities
    $ScriptName=$MyInvocation.MyCommand.Name
    
    $date = Get-Date
    LogWrite("$date - $ScriptName")
    LogWrite("Install configuration on `"$device`"")
     

    try {
        $request=MakeRequest -Method 'PUT' -ContentType 'application/octet-stream' -Uri "$Uri" -Infile $ConfigurationFile
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw $_.Exception
    }
}    
    
    
    
# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUDjg+GC6+mgXb1nlKxFYlLyw7
# NdWgggP3MIID8zCCAtugAwIBAgIQK9H4d0OBsJBMAJr7o5+5OTANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTI0
# MDcwODExNTg0NVoXDTI1MDcwODEyMTg0NVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALYc/bCz
# jCYPFlXgYFCHxGORJgU1SV9Dbuq29DLEnsHyq5lKi4/kKFVcXtLuSVML1XRogDFg
# BXMaJXqG5SBG3teuaaXHNhN08NLURNQn2uFRH/J9P7hfPxjPiprdR0uxXuiFCase
# q508ACLiCq0iq+JXVZI7vEc7+ry3ns49stCcg2GBYhi6PSYi7zjNUKvrciAuLjUY
# IUdodGZGPlDU58JuU19agZmcOpxb/6RZoEUdhBB++Y8mNDUZI2VsoHa9j0imUpoI
# QMjVG1mrrvx5V6DS/UCZnvJxc5ucQMCz9mDpYZ7UD7bSZ+1De570h6wL1e69ZX0J
# sOfz5xV9V57hI/ECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBR6Gl4CUkwT/9Hgcww6bHn1vOFkaTANBgkqhkiG9w0BAQsFAAOCAQEASR33
# EG9LerM80avGHziPYtzTcktixbn0rfaTIXS02OVvZhT6nXFAwBCoRb1JpP4X3FFC
# 0sde1wXwMAR/Vet+PDwcjzsC/z2sZUmDTB4ecXqCDR4FC+Jh6f0YWJY5iilfh3mY
# Wq22ZYBp11WHABegV9ipgK7jILs9zaJWcTADqir6CvILNqfZhQp+0PV8QMpY3SZr
# 2O1iogmLv5tnJn0BKpBNzKsMweKQDGUAg6JIuWcCwPK+oO27Yk5BoT19djaOft6i
# SGPe7Ig/7ieEurj2ZsrwWDCf3XAlD4Qs69Komum9BRjzq1LMMtHsXP/lxqutZNkP
# mq/gaq4irhELfj2yYTGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECvR+HdDgbCQTACa+6OfuTkwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFAfZA557yq54ELpR1wxvKS53EF9dMA0GCSqGSIb3DQEBAQUABIIBAIQoGHbT
# hjmewDtfWcAPa0u3q7THK6h8kgimfbb2QZJS8RWqjLTsHlhNx+4jbmSMYm1c2F/Y
# tTVuRd+j/7TqZQIQfE8e+C2QicnyGxaYTmrFdkudRBJiYNJpn2lo8dfUSPPyMJdV
# 6AwG1mGGQdDKEx/GCnwtAARwFToE3aT3GGt48GBorH0EbOkiKVvmyYS5cBbZLNAq
# 9waV0sO+45tED8+Ju3zGMa6vVSe8h70ngKyupXV9qO1ASilMamI+WPOge9KNTgZO
# LTgFIO3o3HCu7PJ7kmfQYH9EsM7G9puoHVJWopX6Uh0446ikk1stGFccGaLJRR5m
# 7SIiG4Ghh9QGqSQ=
# SIG # End signature block
