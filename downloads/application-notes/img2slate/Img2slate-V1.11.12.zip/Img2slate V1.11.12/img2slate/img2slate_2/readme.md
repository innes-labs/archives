# Exemple de construction de plusieurs images PPK depuis un fichier Excel.

Recopier le répertoire img2slate_1.11.11_G4 en local sur votre ordinateur.

1. Dans le répertoire `/img2slate_2`, Modifier le fichier `slate.xlsx` à votre convenance en fonction de vos salles. Les 20 permiers noms sont affectés au premier hub SMH300, les 20 suivants sont affectés au hub SMH300 suivant, ...
  
2. Exécuter le fichier `picture_builder.hta` pour générer respectivement pour chaque ligne contenant un nom de collaborateur et un numéro de bureau, une image `Diapositive<i>.PNG` lui correspondant dans le répertoire `slate`.

2a. Pour générer uniquement dans le répertoire `slate`, les contenu `Diapositive<i>.PPK` au format propriétaire à partir des images `Diapositive<i>.PNG`, exécuter le script `generator.cmd`.

2b. Si vous souhaitez transformer chacune de vos diapositives exportées avec le format `Diapositive<i>.PNG` en format propriétaire `Diapositive<i>.PPK` et aussi les envoyer sur vos hub SMH300, éditer le script `sender.cmd`, remplir convenablement 
- les adresses IP de vos hub SMH300,
- le nombre de hub concernés dans la variable `NBHUB`
Sauvegarder les modifications et exécuter le script `sender.cmd`. 
 
Exemple de script `sender.cmd` dans le cas d'un seul hub SMH300:  
```
@set FOLDERIMAGE=slate
@set TYPEIMAGE=PNG
@set URLHUB[0]=192.168.1.214
@set URLHUB[1]=192.168.1.1
@set URLHUB[2]=192.168.1.1
@set URLHUB[3]=192.168.1.1
@set NBHUB=1
../common-sender.cmd
```

Le script envoie ainsi toutes les `Diapositives<i>.PPK` sur le serveur WebDAV des différents hub SMH300 `http://<SMH300_Hub_Ip_Addr>/<i>/hub.ppk`.

Attention: les slides du media MS-Powerpoint `slate.pptx` de 1 à 20 correspondent respectivement aux id des slates appairés dans le hub SMH300: 
- contenu `Diapositive1.PPK` destiné au Slate1
- contenu `Diapositive2.PPK` destiné au Slate2
- ..
- contenu `Diapositive20.PPK` destiné au Slate20)

Compatibilité: Gekkota SMH300 V4.11.11



