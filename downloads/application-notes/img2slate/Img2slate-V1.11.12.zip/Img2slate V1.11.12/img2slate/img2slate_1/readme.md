# Génération et envoi de contenu *.PPK depuis un fichier MS-Powerpoint.

1. Ouvrir le fichier fourni MS-PowerPoint `slate.pptx`. Modifier à votre convenance le contenu de chaque diapositive. Puis `Enregistrer sous` le format ```Bitmap indépendante du périphérique (*.bmp)```, et choisir d'exporter `Toutes les diapositives`. Fermer le fichier MS-Powerpoint `slate.pptx`. Toutes les diapositives du fichier MS-Powerpoint `slate.pptx` se retrouvent ainsi dans le dossier `slate` au format `Diapositive<i>.BMP`.

2a. Si vous souhaitez uniquement transformer chacune de vos diapositives exportés avec le format `Diapositive<i>.BMP` en format propriétaire `Diapositive<i>.PPK`, exécuter `generator.cmd`. 
 
2b. Si vous souhaitez transformer chacune de vos diapositives exportées avec le format `Diapositive<i>.BMP` en format propriétaire `Diapositive<i>.PPK` et aussi les envoyer sur vos hub SMH300, éditer le script `sender.cmd`, remplir convenablement 
- les adresses IP de vos hub SMH300
- le nombre de hub SMH300 concernés (variable `NBHUB=1` si un seul hub SMH300)
Sauvegarder vos modifications et exécuter `sender.cmd`.

Exemple de script `sender.cmd` dans le cas d'un seul hub SMH300 dont l'adresse IP est *192.168.1.214*:
```
@set FOLDERIMAGE=slate
@set TYPEIMAGE=BMP
@set URLHUB[0]=192.168.1.214
@set URLHUB[1]=192.168.1.1
@set URLHUB[2]=192.168.1.1
@set URLHUB[3]=192.168.1.1
@set NBHUB=1
../common-sender.cmd
```

Le script `sender.cmd` envoie ainsi toutes les `Diapositives<i>.PPK` du répertoire `/slate` sur le serveur WebDAV des différents hub SMH300 `http://<SMH300_Ip_Addr>/<i>/hub.ppk`.

Attention: les slides du media MS-Powerpoint `slate.pptx` de 1 à 20 correspondent respectivement aux id des slates appairés au niveau de chaques hub SMH300: 
- contenu `Diapositive1.PPK` destiné au Slate1
- contenu `Diapositive2.PPK` destiné au Slate2
- ..
- contenu `Diapositive20.PPK` destiné au Slate20)

Dans le cas de modification du fichier Excel, notamment le nombre de ligne, il est conseillé d'effacer ce qui se trouve dans le répertoire `/slate`. 
Attention: ne pas effacer le répertoire `/slate`. Sinon, le recréer de nouveau     

Compatibilité: Gekkota SMH300 V4.11.11


