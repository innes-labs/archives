<#
.SYNOPSIS
This script permits to sign a xml file for AQS.
.DESCRIPTION
This script permits to sign a xml file for AQS.
The result is saved in a xml signed file.
This xml signed file can be send to a AQS product.
.PARAMETER pk12File
Defines the name of the pk12 file as parameter. Default value is ".\contoso_certificate_and_key_for_qeedji_aosp.pk12"
.PARAMETER xmlFile
Defines the name of the xml file to sign as parameter. Default value is ".\app-list.xml"
.PARAMETER outputFile
Defines the name of the xml file to sign as parameter. Default value is ".\app-list-signed.xml"
.EXAMPLE
PS C:\install directory>.\AQS-setAppAsSystemApp.ps1 -pk12File .\contoso_certificate_and_key_for_qeedji_aosp.pk12 -xmlFile .\app-list.xml -outputFile .\app-list-signed.xml
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$false, HelpMessage = 'Select the pk12 file')]
    [ValidateNotNullOrEmpty()]
    [string]$pk12File = '.\contoso_certificate_and_key_for_qeedji_aosp.pk12',
    [Parameter(Mandatory=$false, HelpMessage = 'Select the xml file to sign')]
    [ValidateNotNullOrEmpty()]
    [string]$xmlFile = '.\app-list.xml',
    [Parameter(Mandatory=$false, HelpMessage = 'Select the xml file signed')]
    [ValidateNotNullOrEmpty()]
    [string]$outputFile = '.\app-list-signed.xml'
)

Add-Type -AssemblyName System.Security

function Sign-XML {
    Param ( [xml]$xml, [System.Security.Cryptography.X509Certificates.X509Certificate2Collection]$certificate )
 
	$xml.PreserveWhitespace = $true;

    [System.Security.Cryptography.xml.SignedXml]$signedXml = $NULL
    $signedXml = New-Object System.Security.Cryptography.Xml.SignedXml -ArgumentList $xml
    $signedXml.SigningKey = $certificate.Item(1).PrivateKey
	
	$signedXml.Signature.SignedInfo.CanonicalizationMethod ="http://www.w3.org/2001/10/xml-exc-c14n#"

    $keyInfo = New-Object System.Security.Cryptography.Xml.KeyInfo
	$keyInfoX509Data = New-Object System.Security.Cryptography.Xml.KeyInfoX509Data
	$keyInfoX509Data.AddCertificate($certificate.Item(0))
	$keyInfoX509Data.AddCertificate($certificate.Item(1))
    $keyInfo.AddClause($keyInfoX509Data)
    $signedXml.KeyInfo = $keyInfo
	
    $Reference = New-Object System.Security.Cryptography.Xml.Reference
    $Reference.Uri = ""
	$Reference.DigestMethod = "http://www.w3.org/2001/04/xmlenc#sha512"
 
    $env = New-Object System.Security.Cryptography.Xml.XmlDsigEnvelopedSignatureTransform
 
    $Reference.AddTransform($env);
    $signedXml.AddReference($Reference)
    $signedXml.ComputeSignature()
	
    [System.Xml.XmlElement]$xmlSignature = $signedXml.GetXml()
    [void]$xml.DocumentElement.AppendChild($xml.ImportNode($xmlSignature, $true))
}
	
function Verify-XmlSignature {
    Param ( [xml]$signed )

    [System.Security.Cryptography.Xml.SignedXml]$signedXml = New-Object System.Security.Cryptography.Xml.SignedXml -ArgumentList $signed
    $XmlNodeList = $signed.GetElementsByTagName("Signature")
    $signedXml.LoadXml([System.Xml.XmlElement] ($XmlNodeList[0]))

    return $signedXml.CheckSignature()
}

Write-Host
$fileexists = Test-Path -Path $pk12File
if ($fileexists -eq $false)
{
	Write-Host "The pk12 file "" $pk12File "" can't be found. Please check file name and retry."
	exit 1
}

$fileexists = Test-Path -Path $xmlFile
if ($fileexists -eq $false)
{
	Write-Host "The xml file "" $xmlFile "" can't be found. Please check file name and retry."
	exit 1
}

$fileexists = Test-Path -Path $outputFile
if ($fileexists -eq $true)
{
	Write-Host "The output file "" $outputFile "" already exists. Can the file be overwritten (y) ?:"
	$answer = Read-Host Answer
	if ($answer -ne "y")
	{
		Write-Host "The xml file has not been signed and has not been created. Please change the outputFile name in the PowerShell command and retry."
		exit 1
	}
	Remove-Item -Path $outputFile -Force
}
New-Item -Name $outputFile -ItemType file | Out-Null
$outputFile = Resolve-Path $outputFile
#Now $outputFile is absolute, we can remove the file
Remove-Item -Path $outputFile -Force

Write-Host "Please enter your public certificate key (.pk12) password:"
$password = Read-Host password
$pk12File = Resolve-Path $pk12File

[xml]$xml = Get-Content $xmlFile
$certificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
try
{
	$certificate.Import($pk12File , $password, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]"DefaultKeySet")
}
catch
{ 
	Write-Host "Wrong Password. Please retry again with the right password suitable for your public certificate key (.pk12)."
	exit 1
}

Sign-XML $xml $certificate
$res = Verify-XmlSignature $xml
Write-Host
If($res -eq $true) 
{
	$xml.save($outputFile)
	Write-Host "The xml file has been signed. The result file is "" $outputFile ""."
}
else
{
	Write-Host "A problem occured during the signing process. Please contact Qeedji support."
}
