Playzilla.Ontologies["AVCommand"]=(function(Logger,Ontology){
"use strict";
var logger=Logger?new Logger("app.ontologies.AVCommand"):null;

var avcommand = new Ontology();
var apb = Components.interfaces.nsISystemAPBAVCmd;

function forEachAvCommand(callback){
	var profiles = systemManager.getApplicationProfileBindingsByProfileUri("av-cmd");

	if(profiles != null){
		var length = profiles.length;
		if(logger) logger.debug("has", length, "profiles");
		for(var i = 0; i < length; ++i){
			try{
				var profile = profiles.queryElementAt(i, apb);
				callback(profile);
			}catch(e){
				if(logger) logger.errorEx(e);
			}
		}
	}
}

avcommand.powerModeOff = function powerModeOff(){
	if(logger) logger.debug("powermode off");
	forEachAvCommand(function(profile){
		profile.powerMode = apb.POWER_MODE_OFF;
	});
}

avcommand.powerModeOn = function powerModeOn(){
	if(logger) logger.debug("powermode on");
	forEachAvCommand(function(profile){
		profile.powerMode = apb.POWER_MODE_ON;
	});
}

avcommand.powerModeSuspend = function powerModeSuspend(){
	if(logger) logger.debug("powermode suspend");
	forEachAvCommand(function(profile){
		profile.powerMode = apb.POWER_MODE_SUSPEND;
	});
}

avcommand.powerModeStandby = function powerModeStandby(){
	if(logger) logger.debug("powermode standby");
	forEachAvCommand(function(profile){
		profile.powerMode = apb.POWER_MODE_STANDBY;
	});
}

avcommand.powerModeOffPowerButton = function powerModeOffPowerButton(){
	if(logger) logger.debug("powermode off power button");
	forEachAvCommand(function(profile){
		profile.powerMode = apb.POWER_MODE_OFF_POWER_BUTTON;
	});
}

avcommand.mute = function mute(m){
	var value = !!m;
	if(logger) logger.debug("mute", value);
	forEachAvCommand(function(profile){
		profile.mute = value;
	});
}

avcommand.brightness = function brightness(value){
	if(logger) logger.debug("brightness", value);
	forEachAvCommand(function(profile){
		profile.brightness = value;
	});
}

avcommand.backlight = function backlight(value){
	if(logger) logger.debug("backlight", value);
	forEachAvCommand(function(profile){
		profile.backlight = value;
	});
}

avcommand.volume = function volume(value){
	if(logger) logger.debug("volume", value);
	forEachAvCommand(function(profile){
		profile.volume = value;
	});
}

avcommand.videoInput = function videoInput(value){
	if(logger) logger.debug("videoInput", value);
	forEachAvCommand(function(profile){
		profile.videoInput = value;
	});
}

avcommand.setIds = function setIds(idsStr){
	if(logger) logger.debug("setIds", idsStr);
	try{
		var ids = JSON.parse(idsStr);
		if(Array.isArray(ids)){
			throw new Error("is not an array");
		}
		forEachAvCommand(function(profile){
			profile.setIds(ids, ids.length);
		});
	}catch(e){
		if(logger) logger.errorEx(e);
	}
}

avcommand.call = function call(command, paramsStr){
	if(logger) logger.debug("call", command, "params=", params);
	try{
		var params = JSON.parse(paramsStr);
		if(typeof(params) != "object"){
			params = null;
		}

		forEachAvCommand(function(profile){
			profile.call(command, params);
		});
	}catch(e){
		if(logger) logger.errorEx(e);
	}
}

return avcommand;
})(Playzilla.Logger,Playzilla.Ontology);