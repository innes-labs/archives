Playzilla.Ontologies["XpfDisplay"]=(function(Logger,Ontology){
"use strict";
var logger=Logger?new Logger("app.ontologies.XpfDisplay"):null;

var display = new Ontology();

function forEachAdadpter(callback){
	var Ci = Components.interfaces;
	var displayOutput = Ci.nsISystemAdapterDisplayOutput;

	var adapters = systemManager.getAdaptersByIId(displayOutput);
	if(adapters){
		var length = adapters.length;
		if(logger) logger.debug("has", length, "adapters");
		for(var i = 0; i < length; ++i){
			try{
				var adapter = adapters.queryElementAt(i, displayOutput);
				callback(adapter);
			}catch(e){
				if(logger) logger.errorEx(e);
			}
		}
	}
}

function setPower(value){
	var Ci = Components.interfaces;
	var displayOutput = Ci.nsISystemAdapterDisplayOutput;
	if(logger) logger.debug("setPower", value);

	forEachAdadpter(function(adapter){
		try{
			adapter.powerMode = value ? displayOutput.POWERMODE_ON : displayOutput.POWERMODE_OFF;
		}catch(e){
			if(logger) logger.warnEx(e);
			adapter.isStandby = !value;
		}
	});
}

display.wakeup = function wakeup(){
	setPower(true);
}

display.sleep = function sleep(){
	setPower(false);
}

display.brightness = function brightness(value){
	if(logger) logger.debug("brightness", value);

	forEachAdadpter(function(adapter){
		adapter.brightness = value;
	});
}

display.contrast = function contrast(value){
	if(logger) logger.debug("contrast", value);

	forEachAdadpter(function(adapter){
		adapter.contrast = value;
	});
}

return display;
})(Playzilla.Logger,Playzilla.Ontology);