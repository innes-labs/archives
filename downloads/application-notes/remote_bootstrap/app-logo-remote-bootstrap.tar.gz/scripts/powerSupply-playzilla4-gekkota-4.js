Playzilla.Ontologies["PowerSupply"]=(function(Logger,Ontology){
"use strict";
var logger=Logger?new Logger("app.ontologies.PowerSupply"):null;

var powerSupply = new Ontology();
powerSupply.reboot = systemMaintenance.reboot.bind(systemMaintenance);
return powerSupply;
})(Playzilla.Logger,Playzilla.Ontology);