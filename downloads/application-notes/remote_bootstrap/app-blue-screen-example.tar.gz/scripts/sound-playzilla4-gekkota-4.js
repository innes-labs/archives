Playzilla.Ontologies["Sound"]=(function(Logger,Ontology){
"use strict";
var logger=Logger?new Logger("app.ontologies.Sound"):null;

var sound = new Ontology();
function forEachAdadpter(callback){
	var Ci = Components.interfaces;
	var soundOutput = Ci.nsISystemAdapterSoundOutput;

	var adapters = systemManager.getAdaptersByIId(soundOutput);
	if(adapters){
		var length = adapters.length;
		if(logger) logger.debug("has", length, "adapters");
		for(var i = 0; i < length; ++i){
			try{
				var adapter = adapters.queryElementAt(i, soundOutput);
				callback(adapter);
			}catch(e){
				if(logger) logger.errorEx(e);
			}
		}
	}
}

function setMute(value){
	if(logger) logger.debug("setMute", value);

	forEachAdadpter(function(adapter){
		try{
			adapter.mute = value;
		}catch(e){
			if(logger) logger.warnEx(e);
		}
	});
}

sound.mute = function mute(){
	setMute(true);
}

sound.unmute = function unmute(){
	setMute(false);
}

sound.volume = function setVolume(volume) {
	if(logger) logger.debug("setVolume", volume);

	forEachAdadpter(function(adapter){
		try{
			adapter.volume = volume;
		}catch(e){
			if(logger) logger.warnEx(e);
		}
	});
}

return sound;
})(Playzilla.Logger,Playzilla.Ontology);