# Powershell utilities  
# 
#
# VERSION 1.10.10
#
if ($UtilsLoaded)
{
    return
}
$UtilsLoaded = 1

if ($LogFile -eq "none")
{
    $LogFile = $null
}

# Accept all certificates for http connection.
add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[Net.ServicePointManager]::SecurityProtocol = "tls12, tls11, tls"
Function LogWrite {
    Param ([string]$logstring)
    if ($LogFile -eq "none") {
        return
    }
    if ($verbose) {
        Write-Host $logstring
    }
    Write-Verbose $logstring
    if ($LogFile)
    {
        Add-content -Encoding UTF8 $LogFile -value $logstring
    }
}

Function LogArray{
    Param([System.Collections.ArrayList] $array)
    foreach ($str in $array)
    {
        LogWrite $str
    }
}
Function ArrayToString{
    Param([System.Collections.ArrayList] $array)
    $result = ""
    foreach ($str in $array)
    {
        $result += $str + "`r`n"
    }
    return $result
}

function InitCredential {
    $credential=@{ 
        basicAuthValue = ""
        certificate = ""
    }
    if ($urlLogin -and $urlPassword) {
        $pair = "$($urlLogin):$($urlPassword)"
        $encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($pair))
        $credential.basicAuthValue = "Basic $encodedCreds"
    }
    elseif (!$doNotGetCertificate) {
        # Get stored certificate
        try {
            $credential.certificate = Get-PncCertificate
        }
        catch { 
            LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
            LogWrite($_.Exception.InnerException.Message)
            throw $_.Exception
        }
    }
    return $credential
}
function MakeRequest {
    Param (
        [string]$Method,
        [string]$ContentType,
        [string]$Uri,
        [string]$Body,
        [string]$Infile,
        $Headers = @{}
    )
    try {
        $Cmd="Invoke-WebRequest -UseBasicParsing -Method `$method -Content `$ContentType -Uri `$Uri"
        $newHeaders = $Headers
        $credential = InitCredential
        if ($credential.certificate) {
            $Cmd += " -Certificate `$credential.certificate -Headers `$Headers"
        } elseif ($credential.basicAuthValue) {
            if ($Headers) {
                $newHeaders.Add("Authorization", $credential.basicAuthValue) | Out-Null
            } else {
                $newHeaders = @{Authorization = $credential.basicAuthValue}
            }
            $Cmd += " -Headers `$newHeaders"
        }
        else {
            throw "no authentication"
        }
        if ($Body) {
            $Cmd += " -Body `$Body"
        } elseif ($Infile) {
            $Cmd += " -InFile `$Infile"
        }
        $ExecutedRequest = Invoke-Expression $Cmd
        return $ExecutedRequest
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        LogWrite($_.Exception.InnerException.Message)
        throw $_.Exception
    }
}
Function Parsedate {
    Param ([string]$stringdate)
    $string = $stringDate
    $index = $string.IndexOf('T');
    if ($index -gt 0)
    {
        $string = $string.Substring(0, $index);
    }
    $date = $null;
    try{
        $date=[DateTime]::ParseExact($string, "yyyy-M-d", $null)
        return $date
    }
    catch{}
    try {
        $date=[DateTime]::ParseExact($string, "yyyy-M-dd", $null)
        return $date
    }
    catch { }
    try {
        $date=[DateTime]::ParseExact($string, "yyyy-MM-dd", $null)
        return $date
    }
    catch {}
    try {
        $date=[DateTime]::ParseExact($string, "yyyy-MM-d", $null)
        return $date
    }
    catch { }
    try {
        $date=[DateTime]::ParseExact($string, "yyyy-MM", $null)
        return $date
    }
    catch { }
    try {
        $date=[DateTime]::ParseExact($string, "yyyy-M", $null)
        return $date
    }
    catch { }
    throw "Can't parse date `"$string`""
}
function WriteXml ([xml]$xml)
{
    $StringWriter = New-Object System.IO.StringWriter;
    $XmlWriter = New-Object System.Xml.XmlTextWriter $StringWriter;
    $XmlWriter.Formatting = "indented";
    $xml.WriteTo($XmlWriter);
    $XmlWriter.Flush();
    $StringWriter.Flush();
    return $StringWriter.ToString();
}
Function ServerGetLicense {
    Param ([string]$psn)
    $Body = @{
        target = "nsIAppliLicenses.list"
    }
    $JsonBody = $Body | ConvertTo-Json
    try {
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    $LicensesObject = $ExecutedRequest | ConvertFrom-Json
    $license = $LicensesObject.licenses.$psn
    return $license
}
Function ServerSearchLicenses {
    Param ([string]$psn, [string]$psnPrefix, [string]$expired)
    $Body = @{
        target = "nsIAppliLicenses.list"
    }
    $JsonBody = $Body | ConvertTo-Json
    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    $LicensesObject = $ExecutedRequest | ConvertFrom-Json
    [System.Collections.ArrayList]$licenseArray = @()
    $license = $LicensesObject.licenses.$psn
    if ($psn -and $license)
    {
        $licenseArray.Add($license) | Out-Null
    }
    if ($psnPrefix -or ($expired -eq 1))
    {
        foreach ($prop in $LicensesObject.licenses.PsObject.Properties)
        {
            $license = $prop.Value
            if (($license.expired -eq 1 ) -or ($psnPrefix -and ($license.psn.StartsWith($psnPrefix) -eq 1)))
            {
                $licenseArray.Add($license) | Out-Null
            }
        }
    }
    return $licenseArray
}
# Retrieve the core PSN of licenses
Function GetCorePsn() {
    $Body = @{
        target = "nsIAppliLicenses.psn"
    }
    $JsonBody = $Body | ConvertTo-Json
    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    $corePsn = $ExecutedRequest | ConvertFrom-Json
    return $corePsn
}
Function AppiGetLicense {
    Param ([string]$appi, [string]$psn)
    $Body = @{
        target = "nsIAppliAppis.get"
    }
    [System.Collections.ArrayList]$argsArray = @()
    $argsArray.Add($appi) | Out-Null
    $Body | Add-Member -MemberType NoteProperty -Name args -Value $argsArray | Out-Null
    $JsonBody = $Body | ConvertTo-Json

    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    $appiObject = $ExecutedRequest | ConvertFrom-Json
    $license = $appiObject.licenses.$psn
    return $license
}
Function AppiGet {
    Param ([string]$appi)
    $Body = @{
        target = "nsIAppliAppis.get"
        args = @($appi)
    }
    $JsonBody = $Body | ConvertTo-Json
    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    $appiObject = $ExecutedRequest | ConvertFrom-Json
    return $appiObject
}

Function AppiSearchLicenses {
    Param ([string]$appi,[string]$psn, [string]$psnPrefix, [string]$expired)
    $Body = @{
        target = "nsIAppliAppis.get"
    }
    [System.Collections.ArrayList]$argsArray = @()
    $argsArray.Add($appi) | Out-Null
    $Body | Add-Member -MemberType NoteProperty -Name args -Value $argsArray | Out-Null
    $JsonBody = $Body | ConvertTo-Json

    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    $appiObject = $ExecutedRequest | ConvertFrom-Json
    [System.Collections.ArrayList]$psnArray = @()
    $license = $appiObject.licenses.$psn
    if ($psn -and $license)
    {
        $psnArray.Add($psn) | Out-Null

    }
    if ($psnPrefix -or ($expired -eq 1))
    {
        foreach ($prop in $appiObject.licenses.PsObject.Properties)
        {
            $psn = $prop.Name
            $license = $prop.Value
            if (($license.expired -eq 1 ) -or ($psn.StartsWith($psnPrefix) -eq 1))
            {
                $psnArray.Add($psn) | Out-Null
            }
        }
    }
    return ,$psnArray
}
function Lock()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [int] $timeout = 60,
        [string] $type = "upload"

    )
    $Headers = @{
        Depth="0"
        Timeout= "Second-" + $timeout
        "X-HTTP-METHOD-OVERRIDE"= "LOCK"
    }
    $provider="Indus Tools 10.10.0 indus@innes.fr"
    $uri = $baseUri + $uri
    $Body = "<D:lockinfo xmlns:D=`"DAV:`"><D:locktype><D:" +
     $type + "/></D:locktype><D:lockscope><D:exclusive/></D:lockscope><D:owner><D:href>" + 
     $provider + "</D:href></D:owner></D:lockinfo>"
    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'text/xml' -Uri $uri   -Body $Body -Headers $Headers
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    [xml]$result = [xml]$ExecutedRequest
    [System.Xml.XmlElement] $root = $result.get_DocumentElement()
    $token = $root.lockdiscovery.activelock.locktoken
    return $token.InnerText
    
}
function LockUpload()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [int] $timeout = 60
    )
    return Lock $baseUri $relUri $timeout "upload"
}
function LockWrite()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [int] $timeout = 60
    )
    return Lock $baseUri $relUri $timeout "write"
}
function LockTransaction()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [int] $timeout = 60
    )
    return Lock $baseUri $relUri $timeout "transaction"
}
function Unlock()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [string] $token
    )
    $Headers = @{
        "Lock-Token"="<" + $token + ">"
        "X-HTTP-METHOD-OVERRIDE"= "UNLOCK"
    }
    $uri = $baseUri + $uri
    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'text/xml' -Uri $uri   -Headers $Headers
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
}
function PutFileWithToken()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [string] $token,
        [string] $filePath,
        [bool] $archive = 0
    )
    $Headers = @{
        IF="<" + $uri + ">(<" + $token + ">)"
        Overwrite="T"
        "X-HTTP-METHOD-OVERRIDE"= "PUT"
    }
    if ($archive -eq $True)
    {
        $Headers.Add("X-UNARCHIVE", "1")
    }
    $uri = $baseUri + $uri
    try {
            $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/octet-stream' -Uri $uri -Infile $filePath -Headers $Headers
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
}
function PutWithToken()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [string] $token,
        [string] $body,
        [bool] $archive = 0
    )
    $Headers = @{
        IF="<" + $uri + ">(<" + $token + ">)"
        Overwrite="T"
        "X-HTTP-METHOD-OVERRIDE"= "PUT"
    }
    if ($archive -eq $True)
    {
        $Headers.Add("X-UNARCHIVE", "1")
    }
    $uri = $baseUri + $uri
    try {
            $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/octet-stream' -Uri $uri   -Body $body -Headers $Headers
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
}
Function StringHash{
    param ([String] $String, $HashName = "MD5") 
    $StringBuilder = New-Object System.Text.StringBuilder
    [System.Security.Cryptography.HashAlgorithm]::Create($HashName).ComputeHash([System.Text.Encoding]::UTF8.GetBytes($String)) | % {
        [Void]$StringBuilder.Append($_.ToString("x2"))
    }
    return $StringBuilder.ToString()
}
Function GeneratePassword {
    param (
        $numberLowercase = 4,
        $numberUppercase = 3,
        $numberSpecial = 3
    )
    for ($i = 0; $i -lt $numberLowercase; $i++) {
        $min += Get-Random -InputObject a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z
    }
    for ($i = 0; $i -lt $numberUppercase; $i++) {
        $maj += Get-Random -InputObject A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z
    }
    $nombre = Get-Random -Minimum 10 -Maximum 99
    for ($i = 0; $i -lt $numberSpecial; $i++) {
        $caracspec += Get-Random -InputObject $, !, %, *, _, -, +, =, ?, [, ], :, "@", "&", "#", "|", "(", ")", "{", "}", ";", ",", "."
    }
    $password = $min+$caracspec+$maj+$nombre
    $length = $password.length
    for ( $i = 0 ; $i -lt $length ; $i++ ){
        $newpos = (( $i + (Get-Random -Maximum $length -Minimum 0 ))%$length)
        $tmp = $password[$i]
        $password = ($password.Remove($i,1)).Insert($i,$password[$newpos])
        $password = ($password.Remove($newpos,1)).Insert($newpos,$tmp)
    }
    return $password
}
function ArrayToHash($array)
{
    $hash = @{}
    foreach ($a in $array)
    {
        $hash.Add($a, $a) | Out-Null
    }
    return $hash
}
Function ReplaceInFile {
    Param ([string]$file, [string]$old, [string]$new)
    LogWrite("Replace: file = $file old=$old new=$new")
    If ((Test-Path "$file") -ne $True) {
        LogWrite( "Replace: file '" + $file + "' not found.")
    }
    else {
        If ($debug) {
            (Get-Content -path $file -Raw) -replace "$old","$new"
        }
        ((Get-Content -path $file -Raw) -replace "$old","$new") | Set-Content -Path $file
    }
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUsMAzzxIrvMSWDwTGLpDg5o5R
# 2GagggP3MIID8zCCAtugAwIBAgIQH9b6nB4eAqFDsly3eJUlDDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDcwMjEyMDcwMloXDTIyMDcwMjEyMjcwMlowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMcqjwHs
# 8WPMEvI5SSYw5Gyli3m/sCv9WPA4pE2U8Lr0oyk71rcdZTUhqWs9GkGbI3yWPdko
# UQhAc/NDgwnAGW5g1z9gwgTTSK80PcNQH8wWFKVPLuPonSE15Msal8/RB+u0QRlh
# 6FlsOoEh+zBbQiW5RvfIEFyIDXKaJchpapQOH2AlsP8n7XGHC+2KiTBYaTf7JLAz
# +V58B6blG50qcyQsshsJwEuSA59hZODXqi4ul/O+FdHvc12dS1tA0ETB2aQTZPjq
# hUt+JYVcKNFQwGirjlPo0xzvWt52v8n7kd8ZiZGEAJP3AwNjkEKrVd3cA3y+HNV/
# kEQS0X6KpxE39EECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTiGKJSaaGLW6TpghZyrWG1l6lTRTANBgkqhkiG9w0BAQsFAAOCAQEAH/51
# KrQ1Cu9lTNapHLU+NrbrrrK5zwl3Vlo8Q+nA/iAUMS16wrtpCdSAvcrBp5XuP+6s
# Jb1uyoUAVgND5MmPEnGAsoF//iWZOyj/msPTIxQUMgta3wcDHeICLFkWArYRA4Fx
# ZJdsjEvMX9/4TZT5uvuW3OLdzofEr9oWFTes29gi5I4/TG1Ezd0WqupW4VVFhGxA
# xumsRlFq40Kd2KjE1+xNBcjSBRValP9FqSd7hpRREAP+XH8mNp9oP7bxOvvFBQZ0
# QKj1Al+c96Ul3B6RVsKIW+pTsbEBR1T5SxZAYt7xGW+e1cVCPlk1uknjjpu2s0z/
# yak+UAz4/a+WsgBZHTGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEB/W+pweHgKhQ7Jct3iVJQwwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFM0JJMaVPeBqZ6AYsg1EDZokFiBoMA0GCSqGSIb3DQEBAQUABIIBAAmtzJwg
# wGvX3tz6zmW9AeNIxmVuk8iDwYOHfLImxXa6JihapA3kXenYNErTgAqDTe9wxGfh
# 7IJpjfJydmTCfc0V3JOp82N8cbtFQ67j4q6cvlN8ESpffecLtCaePeZKZG/zjRtg
# loi6XXiahyTvvu5yBpMUYH7yxXe5qn4RC4Wz7R5Mv0G3KbUZdmlfj5GL4wXV65QY
# takeO+5EPiA7gSbZoNgSxBkQqnDogV1WfYeMYV9fkXjcvxVmKIptCSNqwjyPttCu
# o4PmDXzxCZA9yMhXTwSFxSob074tmMyorj4R4QFHfEz6pJx8rA2/vWgi9vYSMeFy
# YFUMkjxUuCiAwsg=
# SIG # End signature block
