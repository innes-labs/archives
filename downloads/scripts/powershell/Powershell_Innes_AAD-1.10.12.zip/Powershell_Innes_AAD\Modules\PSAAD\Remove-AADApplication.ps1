Function Remove-AADApplication {
<# 
.SYNOPSIS
This function removes a Azure Active Directory application.  
.DESCRIPTION
This function removes a Azure Active Directory application.  
.PARAMETER Credential
Exchange credential (admin profile) used to remove the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the Exchange credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been removed. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
The name of the Azure Active Directory application.
.OUTPUTS
Nothing
.EXAMPLE
PS C:\>Remove-AADApplication -appname "SignMeeting"
 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName
)

$date = Get-Date
LogWrite("$date : delete AAD application with name `"$appName`"")

Remove-AADApplication-CommonsUtils -credential $Credential -tenantId $tenantId -appName $appName 
LogWrite("Application removed")

}
# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUGNKiDNmaEp5ARUC1u5SFjcqj
# JBagggP3MIID8zCCAtugAwIBAgIQH9b6nB4eAqFDsly3eJUlDDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDcwMjEyMDcwMloXDTIyMDcwMjEyMjcwMlowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMcqjwHs
# 8WPMEvI5SSYw5Gyli3m/sCv9WPA4pE2U8Lr0oyk71rcdZTUhqWs9GkGbI3yWPdko
# UQhAc/NDgwnAGW5g1z9gwgTTSK80PcNQH8wWFKVPLuPonSE15Msal8/RB+u0QRlh
# 6FlsOoEh+zBbQiW5RvfIEFyIDXKaJchpapQOH2AlsP8n7XGHC+2KiTBYaTf7JLAz
# +V58B6blG50qcyQsshsJwEuSA59hZODXqi4ul/O+FdHvc12dS1tA0ETB2aQTZPjq
# hUt+JYVcKNFQwGirjlPo0xzvWt52v8n7kd8ZiZGEAJP3AwNjkEKrVd3cA3y+HNV/
# kEQS0X6KpxE39EECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTiGKJSaaGLW6TpghZyrWG1l6lTRTANBgkqhkiG9w0BAQsFAAOCAQEAH/51
# KrQ1Cu9lTNapHLU+NrbrrrK5zwl3Vlo8Q+nA/iAUMS16wrtpCdSAvcrBp5XuP+6s
# Jb1uyoUAVgND5MmPEnGAsoF//iWZOyj/msPTIxQUMgta3wcDHeICLFkWArYRA4Fx
# ZJdsjEvMX9/4TZT5uvuW3OLdzofEr9oWFTes29gi5I4/TG1Ezd0WqupW4VVFhGxA
# xumsRlFq40Kd2KjE1+xNBcjSBRValP9FqSd7hpRREAP+XH8mNp9oP7bxOvvFBQZ0
# QKj1Al+c96Ul3B6RVsKIW+pTsbEBR1T5SxZAYt7xGW+e1cVCPlk1uknjjpu2s0z/
# yak+UAz4/a+WsgBZHTGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEB/W+pweHgKhQ7Jct3iVJQwwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFLx70aBBAemhzBI57NTsD3NPEAwvMA0GCSqGSIb3DQEBAQUABIIBAJBEL8t4
# fECb7OdStpUqJSEUUoZS5t3I9MmxcG49R77lqKl5EU2CrbVQeSFlhuKTDAyAOq0J
# oi3Zwq/2+OxZWv05/Ibgh+qrPPMxHBb+rgxu29LfvWo2k4W8l4A3WO2jKvPMcGTd
# W+0gexc1CcF4aBwIHPfpl453qUAo+kibkrYtkggLdH1k1xE0zLURn11pQSlTzjN+
# +cq2NvrT+T2X5gzSisdSaEQ1SJDmJML5/lLVDa5UO1gLkwkHNUkpDepq3IfNgj25
# ogEiSqAixgyvjgDOA0heJoB7Mqe0fAWFS+TiYMASKJ7aSbUGNbHcwqRAJ64wk6nu
# t+7QnedacpKnayg=
# SIG # End signature block
