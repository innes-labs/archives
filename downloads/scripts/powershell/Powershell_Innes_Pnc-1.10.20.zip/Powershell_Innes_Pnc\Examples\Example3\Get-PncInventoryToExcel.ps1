﻿<#
.SYNOPSIS
This script permits to write an inventory of PNC informations to an Excel file.
.DESCRIPTION
This script permits to write an inventory of PNC informations to an Excel file.
The result is saved in the Excel file in a worksheet bearing today's date. If the tab already exists it is replaced.
Warning, this script file must be encoded in UTF8 with BOM so that the accented characters are correctly displayed in the Excel file.
Warning, this script needs PSPnC module version 1.10.15 minimum.

The user can modify the following script variables (at the start):
- $servers which defines the array of objects associated with the servers to query.
   Each object must at least contain the property "ip" or "host" which gives the address (or domain) of the Plugncast server. 
   It can also contain the properties:
    - port that defines the HTTPS port of server,
    - username that defines the authentication user,
    - password that defines the authentication password.
    (otherwise the default values will be: 443, "superadmin", "superadmin").
    Each object can contain other properties which are not used by the function and which are returned unchanged.
- $header which defines the array of columns names. it must contain the name associated with the fields
    - 'ip' (the 'login', 'password' and 'port' fields are not displayed),
    - to the added free fields
    - to the fields added by the Get-PncInventory function:
        - pncVersion: version of the Plugncast server,
        - nbDomain: number of domains,
        - domainNames: domain names separated by newlines,
        - licenseMail: the mail used with license,
		- psnCore: the serial number of the core license,
		- psnDomain: the serial number of the extra domain licenses separated by newline ("-" if no extra domain used),
        - nbLicenseDomain: number of valid licenses of domain,
        - nbLicensePlayzillaValid: number of valid license of playzilla,
        - nbLicensePlayzillaWithDomain: number of valid license of playzilla with domain associated,
        - nbLicensePlayzillaWithoutDomain: number of valid license of playzilla without domain associated,
        - nbLicensePlayzillaInvalid: number of invalid license of playzilla.
.PARAMETER excelFilePath
The path of the excel file path. The default value is ".\Inventory-INNES_PlugnCast.xlsx"
.PARAMETER logFile
The path of log file
.EXAMPLE
PS C:\install directory>.\Get-PncInventoryToExcel -excelFilePath ".\output.xlsx"
.NOTES
VERSION:1.10.11
#>
[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$false)]
    [string] $excelFilePath = ".\Inventory-INNES_PlugnCast.xlsx",
    [string] $LogFile
)
#-----------------------------------------------------------------------------------------------------------
#               Array of servers to edit
# Each object must at least contain the property "ip" or "host" which gives the address (or domain) of the Plugncast server. 
# It can also contain the properties:
# - port that defines the HTTPS port of server,
# - username that defines the authentication user,
# - password that defines the authentication password.
# Each object can contain other properties which are not used by the function and which are returned unchanged (example field1, field2, ...).
#-----------------------------------------------------------------------------------------------------------
[System.Collections.ArrayList]$servers = @(
    [PSCustomObject]@{ip="192.168.1.102";port="8443";login="superadmin";password="superadmin";field1="Field1 value1";field2="Field2 value1"}
    [PSCustomObject]@{ip="192.168.1.10";port="443";login="superadmin";password="superadmin";field1="Field1 value2";field2="Field2 value2"}
)
#-----------------------------------------------------------------------------------------------------------
#             Array of column names to edit
# The array must contain the names of the fields in the $servers array in the same order (except "login", "password" and "port").
# It must also define, at the end, the names of the fields added by the Get-Inventory function.
# So you can modify the first line, from "Field1", and modify the labels of the next 2 lines.
#-----------------------------------------------------------------------------------------------------------
$header=@("IP";"Field1";"Field2";`
"Version";"Domains";"Domain names";"License email";"Psn core";"Psn domains";"Valid domain licenses";"Valid Playzilla licenses";`
"Valid Playzilla licenses with domain";"Valid Playzilla licenses without domain";"Invalid Playzilla licenses")

#-----------------------------------------------------------------------------------------------------------
#                  Do not modify anything after this line
#-----------------------------------------------------------------------------------------------------------
# Import Pnc Module
Import-Module PSPnc -MinimumVersion 1.10.15
if (!$?) {
	Write-Host("You must use PnC module Version 1.10.15 minimum. Please update it before re-trying.")
	exit(1)
}
# Import Module PSExcel
Import-Module PSExcel
# Clear the log file of any previous try
If ($LogFile -and (Test-Path $LogFile) -eq $True) {
    Remove-Item -Path $LogFile
}
$verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)

# Get the inventory
Write-Host("Start to query the Pnc server(s)...")
$result = Get-PncInventory $servers -LogFile $LogFile -vb:$verbose
# compute result
$nbLicensePlayzillaValid = 0
$nbLicenseDomain = 0
$nbDomain = 0;
$nbKO = 0;
$nbOK = 0;
function Remove-Property($server, $name)
{
    if ($name -in $server.PSobject.Properties.Name) {
        $server.PSObject.properties.remove($name)
    }
}
[System.Collections.ArrayList]$errors= @()
foreach ($server in $result) {
    Remove-Property $server "login"
    Remove-Property $server "password"
    Remove-Property $server "port"
    if ($server.status -eq "OK") {
        $nbDomain += $server.nbDomain
        $nbLicensePlayzillaValid += $server.nbLicensePlayzillaValid;
        $nbLicenseDomain += $server.nbLicenseDomain
        $errors.Add($false) | Out-Null
		$nbOK++
    }
    else {
        $errors.Add($true) | Out-Null
        $nbKO++
    }
    Remove-Property $server "status"
}
if ($nbKO)
{
    Write-Warning("Warning, some servers (" + $nbKO + ") did not respond")
}
Write-Host("Write the result...")
# Write Excel file
$worksheetName=Get-Date -Format "dd.MM.yyyy"
$result | Export-XLSX -Path $excelFilePath -header $header -Autofit -WorksheetName $worksheetName -ReplaceSheet
# Re-open the file
$Excel = New-Excel -Path $excelFilePath
$WorkSheet = $Excel | Get-WorkSheet -Name $worksheetName
$Excel.Workbook.View.ActiveTab=$WorkSheet.Index-1
# Format the worksheek
$WorkSheet | Format-Cell -HorizontalAlignment "Center" -VerticalAlignment "Top" -Autofit -WrapText $true
$WorkSheet | Format-Cell -Header -Bold $True
# Computes additional informations
$row = $result.Length + 4
$col = 2
$WorkSheet.Cells.Item($row, $col).value = "Total:"; 
$WorkSheet.Cells.Item($row, $col).Style.Font.Bold = $True
$row++
$WorkSheet.Cells.Item($row, $col).value = "Number of active servers";
$WorkSheet.Cells.Item($row, $col).Style.Font.Bold = $True
$WorkSheet.Cells.Item($row, $col+1).value = $nbOK
$WorkSheet.Cells.Item($row, $col+1).Style.Font.Bold = $True
if ($nbKO) {
	$row++
	$WorkSheet.Cells.Item($row, $col).value = "Number of servers which didn't respond";
	$WorkSheet.Cells.Item($row, $col).Style.Font.Bold = $True
	$WorkSheet.Cells.Item($row, $col).Style.Fill.PatternType = "Solid"
	$WorkSheet.Cells.Item($row, $col).Style.Fill.BackgroundColor.SetColor(16711680)
	$WorkSheet.Cells.Item($row, $col+1).value = $nbKO
	$WorkSheet.Cells.Item($row, $col+1).Style.Font.Bold = $True
	$WorkSheet.Cells.Item($row, $col+1).Style.Fill.PatternType = "Solid"
	$WorkSheet.Cells.Item($row, $col+1).Style.Fill.BackgroundColor.SetColor(16711680)
}
$row++
$WorkSheet.Cells.Item($row, $col).value = "Total number of active domains"
$WorkSheet.Cells.Item($row, $col).Style.Font.Bold = $True
$WorkSheet.Cells.Item($row, $col+1).value = $nbDomain
$WorkSheet.Cells.Item($row, $col+1).Style.Font.Bold = $True
$row++
$WorkSheet.Cells.Item($row, $col).value = "Total number of extra domain licenses"
$WorkSheet.Cells.Item($row, $col).Style.Font.Bold = $True
$WorkSheet.Cells.Item($row, $col+1).value = $nbLicenseDomain
$WorkSheet.Cells.Item($row, $col+1).Style.Font.Bold = $True
$row++
$WorkSheet.Cells.Item($row, $col).value = "Total number of valid Playzilla licenses"
$WorkSheet.Cells.Item($row, $col).Style.Font.Bold = $True
$WorkSheet.Cells.Item($row, $col+1).value = $nbLicensePlayzillaValid
$WorkSheet.Cells.Item($row, $col+1).Style.Font.Bold = $True
for ($i = 0; $i -lt $errors.Count; $i++)
{
    if ($errors[$i])
    {
        $row = $i+2
        $WorkSheet | Format-Cell -StartRow $row -EndRow $row -Color Red
    }
}
# Save file
$Excel | Close-Excel -Save
Write-Host("The result is in the file " + $excelFilePath)


# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQURrHWqLzH2rQRIFG7rwIs4SwY
# v8WgggP3MIID8zCCAtugAwIBAgIQfuhSOkbbr69GivNCL+Y5nzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MDUyMzEzNDQzN1oXDTIzMDUyMzE0MDQzN1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJLtcBS+
# A9c8l7ojt1OCClFd134lp5jk/VPD8B5b3jCMg50dl+nPPdxZ84fz/iBq3A1Ur+gz
# HIp+TWwrCHgOeq+OklaCDd9yMXJGU5qiX4cM738qPm3ptqCFSXrUzNx7QI2/ktaE
# 3mLYbKONCS93CAlAlmLTsBswkdRqKXRE4jX8r453xjqChQPSLFvxrQkJUzQ2wHpC
# oEPEfSdPSKOv6Tsnkh0Y1Apn/+kJ9fqVRI5UrPBxsYeVWJYJDW0o9Dg7JY4V4bhy
# QkRVwsniB7EzUy7mYksMGM+hnewwFabzDLANx2WXmUnDVATJ73Um/9Zrxcl4FaY5
# /zFwN0X+m/5WKMUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRJYD1gbvKucZORSGJEZ2QO1h6+sDANBgkqhkiG9w0BAQsFAAOCAQEAcIwG
# fBPgQvE0ZFvW4+t2JSKLPNjG7v1+bcZThc+yOxCZgn2IvxPZWlEhgWa0ir44ll6P
# Ie41Zc6PqDTjwUulITDShXqOVlHGhE5MdwFmgUriqZ9zPbQtUAsq/uzluHu7+XRP
# k5hZ6L7Exk3Fih+pacoLoVLTjZGcrFJ973VI/wf1CjCxifuLgPSzZ7URffpqn1Q1
# D1zo6awe4evQgYJzlOsIu9Z+gSff38t75ZMYmMXFiFr3XyLREnFEviaQoGGWONAV
# ulUGn5WLp8JQ65EhJFCiIlg06nLOL6/VoG9i5jTcTu5XLq2gf9+mL5CeRm9EBQrN
# QlIeOSw2xlQ2TfuzXjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEH7oUjpG26+vRorzQi/mOZ8wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFPUowTYYLHTMR3Idktpa0mdj8gZBMA0GCSqGSIb3DQEBAQUABIIBACXEsCwr
# SdJR8LnrNG4Bh0J8VWPKO8jSX91GwPZbzkp0lxUZysrkuWYyJs/zOe+qtthWpzCo
# 0Yy+3L5wrhBrjMJ8x+Q7lGjdsdP6kuO8x+GoMVTKM277eAdLthmuMcFQaWO8IGX9
# GUw519TpP+6j5J8Ne1Flvu/H2lSDTIJ+XHxQ5RLIG93ksHaanJQdFMGYRm0NpzxD
# 3J/+Jd4mFd3oKTpyQfnRRRy6xDMyPkSi7VygbstBKdpJNDMae6U3PJDlWOKH6z9Y
# 2b9cLCoOd31qcHXwAFcYEQnMbBFKUm3N2ZP36sXG+USEzbCwIOEnWBQJQHsM6Phd
# EgGYCry8K3Er4O0=
# SIG # End signature block
