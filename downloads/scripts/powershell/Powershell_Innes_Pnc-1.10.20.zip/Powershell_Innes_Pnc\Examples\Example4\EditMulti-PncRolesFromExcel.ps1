﻿<#
.SYNOPSIS
This script permits to change the roles of a list of PlugnCast server from an MS-Excel file.
.DESCRIPTION
This script permits to change the roles of a list of PlugnCast server from an MS-Excel file.
The table of the MS-Excel file must respect the format of the table produced by the script  Get-PncRolesToExcel.
Warning, this script file must be encoded in UTF8 with BOM so that the accented characters are correctly displayed in the Excel file.

The user can modify the following script variables (at the start):
- $servers which defines the array of objects associated with the servers to query.
   Each object must at least contain the property "ip" or "host" which gives the address (or domain) of the PlugnCast server. 
   It can also contain the properties:
    - port that defines the HTTPS port of server,
    - username that defines the authentication user,
    - password that defines the authentication password.
    (otherwise the default values will be: 443, "superadmin", "superadmin").
.PARAMETER excelFilePath
The path of the MS-Excel file path. The default value is ".\Roles-INNES_PlugnCast.xlsx"
.PARAMETER permitWord
The word stored in the MS-Excel cells for the allowed features. Comparisons are not case sensitive and spaces in MS-Excel cells are removed 
.PARAMETER notPermitWord
The word stored in the MS-Excel cellsfor the unauthorized features. Comparisons are not case sensitive and spaces in MS-Excel cells are removed 
.PARAMETER logFile
The path of log file
.EXAMPLE
PS C:\install directory>.\Edit-PncRolesToExcel -excelFilePath ".\input.xlsx"
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$false)]
    [string] $excelFilePath = ".\Roles-INNES_PlugnCast.xlsx",
    [Parameter(Mandatory=$false)]
    [ValidatePattern("^[^ ]*$")]
    [string] $permitWord = "x",
    [Parameter(Mandatory=$false)]
    [ValidatePattern("^[^ ]*$")]
    [string] $notPermitWord = "",
    [string] $LogFile
)
#-----------------------------------------------------------------------------------------------------------
#               Array of servers to edit
# Each object must at least contain the property "ip" or "host" which gives the address (or domain) of the Plugncast server. 
# It can also contain the properties:
# - port that defines the HTTPS port of server,
# - username that defines the authentication user,
# - password that defines the authentication password.
#-----------------------------------------------------------------------------------------------------------
[System.Collections.ArrayList]$servers = @(
    [PSCustomObject]@{ip="localhost";port="8443";login="superadmin";password="superadmin"}
    [PSCustomObject]@{ip="192.168.1.102";port="8443"}
)
#-----------------------------------------------------------------------------------------------------------
#                  Do not modify anything after this line
#-----------------------------------------------------------------------------------------------------------
# Import Pnc Module
Import-Module PSPnc -MinimumVersion 1.10.17
if (!$?) {
	Write-Host("You must use PnC module Version 1.10.17 minimum. Please update it before re-trying.")
	exit(1)
}
# Import Module PSExcel
Import-Module PSExcel
# Clear the log file of any previous try
If ($LogFile -and (Test-Path $LogFile) -eq $True) {
    Remove-Item -Path $LogFile
}

foreach ($server in $servers)
{
    $urlHost = $server.ip
    if (!$urlHost)
    {
        $UrlHost = $server.host
    }
	$urlPort = $server.port
    if (!$urlPort)
    {
        $urlPort = 443
    }
	$serverLogin = $server.login
    if (!$serverLogin)
    {
        $serverLogin = "superadmin"
    }
	$serverPassword = $server.password
    if (!$serverPassword)
    {
        $serverPassword = "superadmin"
    }
    .\Edit-PncRolesFromExcel.ps1 -excelFilePath $excelFilePath -permitWord $permitWord -notPermitWord $notPermitWord `
    -urlHost $urlHost -urlPort $urlPort -urlLogin $serverLogin -UrlPassword $serverPassword 
}




# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU7djrxg+pPZTXWsq/ePKPwVL7
# trGgggP3MIID8zCCAtugAwIBAgIQfuhSOkbbr69GivNCL+Y5nzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MDUyMzEzNDQzN1oXDTIzMDUyMzE0MDQzN1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJLtcBS+
# A9c8l7ojt1OCClFd134lp5jk/VPD8B5b3jCMg50dl+nPPdxZ84fz/iBq3A1Ur+gz
# HIp+TWwrCHgOeq+OklaCDd9yMXJGU5qiX4cM738qPm3ptqCFSXrUzNx7QI2/ktaE
# 3mLYbKONCS93CAlAlmLTsBswkdRqKXRE4jX8r453xjqChQPSLFvxrQkJUzQ2wHpC
# oEPEfSdPSKOv6Tsnkh0Y1Apn/+kJ9fqVRI5UrPBxsYeVWJYJDW0o9Dg7JY4V4bhy
# QkRVwsniB7EzUy7mYksMGM+hnewwFabzDLANx2WXmUnDVATJ73Um/9Zrxcl4FaY5
# /zFwN0X+m/5WKMUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRJYD1gbvKucZORSGJEZ2QO1h6+sDANBgkqhkiG9w0BAQsFAAOCAQEAcIwG
# fBPgQvE0ZFvW4+t2JSKLPNjG7v1+bcZThc+yOxCZgn2IvxPZWlEhgWa0ir44ll6P
# Ie41Zc6PqDTjwUulITDShXqOVlHGhE5MdwFmgUriqZ9zPbQtUAsq/uzluHu7+XRP
# k5hZ6L7Exk3Fih+pacoLoVLTjZGcrFJ973VI/wf1CjCxifuLgPSzZ7URffpqn1Q1
# D1zo6awe4evQgYJzlOsIu9Z+gSff38t75ZMYmMXFiFr3XyLREnFEviaQoGGWONAV
# ulUGn5WLp8JQ65EhJFCiIlg06nLOL6/VoG9i5jTcTu5XLq2gf9+mL5CeRm9EBQrN
# QlIeOSw2xlQ2TfuzXjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEH7oUjpG26+vRorzQi/mOZ8wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFH6FSj0+p0LY6djYtIG+iQOVBip4MA0GCSqGSIb3DQEBAQUABIIBAIx7V2wh
# mqHojvyrJ4nYk7bfEgVm6lKE8wCO3DueLBK2+AYS2cfqXo5pH1YqxDnFfvkEeASg
# JEvS4XGpLXLUEjVUuK+tpOpjouyUBGRoxd9dTfco1yG1qJ9Gs/as3offB+CB3Fjh
# OqVFa89U9VHF2CDyCluCO8R/mBz5X2mAei7oCsS4fKfnpgB/R/h9yDxNru1HcnUH
# gbbl17sKTDd3CK/v3otIDlH/0FGlJ96JI+nrCgzuDrNJl/3mvj30G0F0TUWl4BcN
# pf3avY9+DBdd1GhOD4gDpEQD1TCbhSmGznwV6mSYZ9TNrxWs1C4Bb2JB6SfnokjU
# LMgVvTidxE0puhc=
# SIG # End signature block
