<#
.SYNOPSIS
This script permits to get devices MAC from PlugnCast Server, and corresponding label and device family
.DESCRIPTION
This script permits to get devices MAC from PlugnCast Server, and corresponding label and device family
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain). Example: "demo.plugncast.com", "localhost"
.PARAMETER urlPort
The Plugncast G3 server port (443 by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used (default "superadmin")
.PARAMETER urlPassword
The password of authentication if the certificate is not used (default "superadmin")
.PARAMETER logFile
The path of log file (default "./Get-PncDevicesMac.log")
.EXAMPLE
Get-PncDevicesMac -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort = 443,
    [string] $UrlLogin = "superadmin",
    [string] $UrlPassword = "superadmin",
    [string] $LogFile
)
# Import Pnc Module
Import-Module PSPnc
# Clear the log file of any previous try
If ($LogFile -and (Test-Path $LogFile) -eq $True) {
    Remove-Item -Path $LogFile
}
# Clear previous result
If ((Test-Path PncDevicesMac.csv) -eq $True) {
    Remove-Item -Path PncDevicesMac.csv
}
$verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
# Get all the information
Write-Host("Start to query the Pnc server '$urlHost'...")
$configObject = Get-PncDomainsAndTargets -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose

Write-Host("Extract Devices MAC...")
$objs =  @()
foreach ($domain in $configObject.domains) {
    foreach ($target in $domain.targets) {
		$obj = New-Object System.Object
		add-member -InputObject $obj -membertype noteproperty -name Mac -value $target.info.mac
		add-member -InputObject $obj -membertype noteproperty -name Label -value $target.label
		add-member -InputObject $obj -membertype noteproperty -name ModelFamily -value $target.modelFamily
		$objs += $obj;
    }
}
Write-Host($objs.count.ToString() + " devices have been found.")
$objs | Export-CSV -Delimiter ";" -Encoding UTF8 -NoTypeInformation "./PncDevicesMac.csv"  
Write-Host("You can find the result into the file ""PncDevicesMac.csv"".")

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUlDhDQPr8t73G7t+qRfPe06m7
# jBWgggP3MIID8zCCAtugAwIBAgIQfuhSOkbbr69GivNCL+Y5nzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MDUyMzEzNDQzN1oXDTIzMDUyMzE0MDQzN1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJLtcBS+
# A9c8l7ojt1OCClFd134lp5jk/VPD8B5b3jCMg50dl+nPPdxZ84fz/iBq3A1Ur+gz
# HIp+TWwrCHgOeq+OklaCDd9yMXJGU5qiX4cM738qPm3ptqCFSXrUzNx7QI2/ktaE
# 3mLYbKONCS93CAlAlmLTsBswkdRqKXRE4jX8r453xjqChQPSLFvxrQkJUzQ2wHpC
# oEPEfSdPSKOv6Tsnkh0Y1Apn/+kJ9fqVRI5UrPBxsYeVWJYJDW0o9Dg7JY4V4bhy
# QkRVwsniB7EzUy7mYksMGM+hnewwFabzDLANx2WXmUnDVATJ73Um/9Zrxcl4FaY5
# /zFwN0X+m/5WKMUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRJYD1gbvKucZORSGJEZ2QO1h6+sDANBgkqhkiG9w0BAQsFAAOCAQEAcIwG
# fBPgQvE0ZFvW4+t2JSKLPNjG7v1+bcZThc+yOxCZgn2IvxPZWlEhgWa0ir44ll6P
# Ie41Zc6PqDTjwUulITDShXqOVlHGhE5MdwFmgUriqZ9zPbQtUAsq/uzluHu7+XRP
# k5hZ6L7Exk3Fih+pacoLoVLTjZGcrFJ973VI/wf1CjCxifuLgPSzZ7URffpqn1Q1
# D1zo6awe4evQgYJzlOsIu9Z+gSff38t75ZMYmMXFiFr3XyLREnFEviaQoGGWONAV
# ulUGn5WLp8JQ65EhJFCiIlg06nLOL6/VoG9i5jTcTu5XLq2gf9+mL5CeRm9EBQrN
# QlIeOSw2xlQ2TfuzXjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEH7oUjpG26+vRorzQi/mOZ8wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFAqihJratdoeVEUIqssQdQakvVl+MA0GCSqGSIb3DQEBAQUABIIBABPDxqqn
# Ty7YRb80yCv7GtC3gdgbSZ+jR7kJ2CKPPgYidYoq6npiFcne1TH4qdjC9b+fFJGR
# +9ee4pguj+0VdxlSb/OsKDw1MS6puxM9dg6M1SPSGFRDGOwAJX1NX21owP9qU2cH
# eE9Ugj2oPftUhAWgbCtjoYuuT2XGC2SxkYBaHcRasdD0AtgIwFRfE3qh8aRHbDqI
# NzoWNdCBuLX8WWGycUmm2W7PMFQm7MpodQi8ircLlDgP8aCtthgux3auh0EY71bh
# 7/zowMPHDDeCNhGb2ynPZoGWIrmsR7UBkkoyulCZu5cvLtT/A+ryrXJDj7UT+CRL
# Qh3TCf00eRdXUYo=
# SIG # End signature block
