Function Get-PncAppiDomainAssociation {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the domains of an APPI
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the domains of an APPI
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER appi
The name of appi (playzilla) or identificator of appi (urn:innes:system-app#playzilla)
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell object that describes the domains of the APPI
Example of object formated in JSON :
{
    "nbDomains":  1,
    "domains":  [
                    {
                        "name":  "domain1",
                        "version":  null,
                        "nbLicenses":  9,
                        "licenses":  [ ... ]
                    }
    ]
}
.EXAMPLE
Get-PncAppiDomainAssociation -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [Parameter(Mandatory=$true)]
    [string] $appi,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$urn = "urn:innes:system-app#"
if (!$appi.StartsWith($urn))
{
    $appi = $urn + $appi
}

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve domains of APPI `"$appi`" for server `"$server`"")

 

$Body = @{
    target = "nsIAppliAppis.get"
}
[System.Collections.ArrayList]$argsArray = @()
$argsArray.Add($appi) | Out-Null
$Body | Add-Member -MemberType NoteProperty -Name args -Value $argsArray | Out-Null
$JsonBody = $Body | ConvertTo-Json

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}
$appiObject = $ExecutedRequest | ConvertFrom-Json
$result = [PSCustomObject]@{
    nbDomains = 0
}
$unsetDomain = "@unset@"
$domainsLicensesMap = [PSCustomObject]@{}
foreach ($prop in $appiObject.licenses.PsObject.Properties)
{
    $psn = $prop.Name;
    $license = $prop.Value
    $domain = $license.domain
    $l = [PSCustomObject]@{
        psn = $psn
        label = $license.label
        valid = $license.valid
        license = $license.license
    }
    if ($license.valid) {
        $l  | Add-Member -MemberType NoteProperty -Name expired -Value $license.expired | Out-Null
    }
    if ($license.PSObject.Properties['expireDate'])
    {
        $l  | Add-Member -MemberType NoteProperty -Name expireDate -Value $license.expireDate | Out-Null
    }
    if (!$domain)
    {
        $domain = $unsetDomain
    }
    $d = $domainsLicensesMap.$domain
    if (!$d)
    {
        $d = [PSCustomObject]@{nbLicenses = 1}
        [System.Collections.ArrayList]$licenses = @()
        $licenses.Add($l) | Out-Null
        $d | Add-Member -MemberType NoteProperty -Name licenses -Value $licenses | Out-Null
        $domainsLicensesMap | Add-Member -MemberType NoteProperty -Name $domain -Value $d | Out-Null
    }
    else {
        $d.nbLicenses++
        $d.licenses.Add($l) | Out-Null
    }
}
$domainsVersionsMap = [PSCustomObject]@{}
foreach ($prop in $appiObject.versions.PsObject.Properties)
{
    $version = $prop.Name;
    $obj = $prop.Value
    foreach ($domain in $obj.domains) {
        $d = $domainsVersionsMap.$domain
        if (!$d) {
            $d = [PSCustomObject]@{}
            [System.Collections.ArrayList]$versions = @()
            $versions.Add($version) | Out-Null
            $d | Add-Member -MemberType NoteProperty -Name versions -Value $versions | Out-Null
            $domainsVersionsMap | Add-Member -MemberType NoteProperty -Name $domain -Value $d | Out-Null
        }
        else {
            $d.versions.Add($l) | Out-Null
        }
    }
}
[System.Collections.ArrayList]$domainArray = @()
foreach ($prop in $appiObject.domains.PsObject.Properties)
{
        $result.nbDomains += 1
        $name = $prop.Name
        $domain = $prop.Value
        $d = [PSCustomObject]@{
            name = $name
        }
        if ($domain.version)
        {
            $d | Add-Member -MemberType NoteProperty -Name version -Value $domain.version | Out-Null
        }
        if ($domainsLicensesMap.$name)
        {
            $d | Add-Member -MemberType NoteProperty -Name nbLicenses -Value $domainsLicensesMap.$name.nbLicenses | Out-Null
            $d | Add-Member -MemberType NoteProperty -Name licenses -Value $domainsLicensesMap.$name.licenses | Out-Null
        }
        else {
            $d | Add-Member -MemberType NoteProperty -Name nbLicenses -Value 0 | Out-Null
        }
        $domainArray.Add($d) | Out-Null
}
$result | Add-Member -MemberType NoteProperty -Name domains -Value $domainArray | Out-Null
if ($domainsLicensesMap.$unsetDomain)
{
    $result | Add-Member -MemberType NoteProperty -Name nbUnusedLicenses -Value $domainsLicensesMap.$unsetDomain.nbLicenses | Out-Null
    $result | Add-Member -MemberType NoteProperty -Name unusedLicenses -Value $domainsLicensesMap.$unsetDomain.licenses | Out-Null
}
else {
    $result | Add-Member -MemberType NoteProperty -Name nbUnusedLicenses -Value 0 | Out-Null
}
LogWrite($result | ConvertTo-Json -Depth 5)
$result 
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUiaZxi5RTp4ofdHJAOa7kvMw9
# 5ImgggP3MIID8zCCAtugAwIBAgIQfuhSOkbbr69GivNCL+Y5nzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MDUyMzEzNDQzN1oXDTIzMDUyMzE0MDQzN1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJLtcBS+
# A9c8l7ojt1OCClFd134lp5jk/VPD8B5b3jCMg50dl+nPPdxZ84fz/iBq3A1Ur+gz
# HIp+TWwrCHgOeq+OklaCDd9yMXJGU5qiX4cM738qPm3ptqCFSXrUzNx7QI2/ktaE
# 3mLYbKONCS93CAlAlmLTsBswkdRqKXRE4jX8r453xjqChQPSLFvxrQkJUzQ2wHpC
# oEPEfSdPSKOv6Tsnkh0Y1Apn/+kJ9fqVRI5UrPBxsYeVWJYJDW0o9Dg7JY4V4bhy
# QkRVwsniB7EzUy7mYksMGM+hnewwFabzDLANx2WXmUnDVATJ73Um/9Zrxcl4FaY5
# /zFwN0X+m/5WKMUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRJYD1gbvKucZORSGJEZ2QO1h6+sDANBgkqhkiG9w0BAQsFAAOCAQEAcIwG
# fBPgQvE0ZFvW4+t2JSKLPNjG7v1+bcZThc+yOxCZgn2IvxPZWlEhgWa0ir44ll6P
# Ie41Zc6PqDTjwUulITDShXqOVlHGhE5MdwFmgUriqZ9zPbQtUAsq/uzluHu7+XRP
# k5hZ6L7Exk3Fih+pacoLoVLTjZGcrFJ973VI/wf1CjCxifuLgPSzZ7URffpqn1Q1
# D1zo6awe4evQgYJzlOsIu9Z+gSff38t75ZMYmMXFiFr3XyLREnFEviaQoGGWONAV
# ulUGn5WLp8JQ65EhJFCiIlg06nLOL6/VoG9i5jTcTu5XLq2gf9+mL5CeRm9EBQrN
# QlIeOSw2xlQ2TfuzXjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEH7oUjpG26+vRorzQi/mOZ8wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFL85uSkNocoe31EdHQRd+23SECtwMA0GCSqGSIb3DQEBAQUABIIBAFDSWq9H
# VjdOMjKLJzDAodbjl1FRx8BmlCUdAxbWRv8wy+tFxw0RLzCBCgazJe2Tcaq8L1CD
# A3wWbCa2qe9Nau6Y2XlZwEC9ouMM+HHDvrIgmjALVG6KWMK1+K9Bokhy0sdrZDoy
# 7F8/RefK5uLXK4FydQpIZNzKIde/DAPg3AvaJRJwIwAjcACnOZuU8LoLEPp7AwlM
# zZzHjQ6I/q57DjNStvDPbD7+RnZZPh8fJioUvqg25FIry2in4k74q5lfTkAVJXQk
# dBNVJ2CwJrdXS08YqMTEvq0R7MRCPxrmvpHulrvHbKViNSSvp8cP3HaOK/BdjFpK
# 2vZIRD+pWuoIMgc=
# SIG # End signature block
