Function Get-PncLicense {
<#
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the Plugncast server licenses.
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the Plugncast server licenses.
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell object describing license.
Example of object formated in JSON :
{
    "mail":  "mail@domain.com",
    "psn":  "PSN00780-00000 CD9",
    "licenses":  {
         "numberDevices":  "unlimited",
         "numberDomains":  51,
         "valid":  true,
         "licenses":  {
            "PSN00160-00180 CD7":  {
                  "psn":  "PSN00160-00000 CD7",
                 "isCore":  false,
                 "numberDevices":  "unlimited",
                  "numberDomains":  10,
                 "label":  "plugncast domain",
                 "valid":  true,
                 "license":  "xxxx - xxxx - xxxx - xxxx - xxxxx",
                 "expired":  false
            }
        }
    }
}
.EXAMPLE
Get-PncLicense -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION: 1.10.10
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost = $(throw "Please enter the Plugncast G3 host (IP or DNS domain"),
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"

# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name
$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve the Plugncast licenses for server `"$server`"")

$Body = @{
    target = "nsIAppliLicenses.list"
}
$JsonBody = $Body | ConvertTo-Json
Start-Sleep -m $SleepDurationBeforeCommand

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}

$LicensesObject = $ExecutedRequest | ConvertFrom-Json

$Body = @{
    target = "nsIAppliLicenses.mail"
}
$JsonBody = $Body | ConvertTo-Json
try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}
$mail = $ExecutedRequest | ConvertFrom-Json
$Body = @{
    target = "nsIAppliLicenses.psn"
}
$JsonBody = $Body | ConvertTo-Json
try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}
$psn = $ExecutedRequest | ConvertFrom-Json
$resultObject=[PSCustomObject]@{
    mail= $mail;
    psn = $psn;
    licenses = $LicensesObject
}
LogWrite($resultObject | ConvertTo-Json -Depth 5)
$resultObject

}


# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU5VQ5ZCe8bRovFCHaYe23UPpB
# v/WgggP3MIID8zCCAtugAwIBAgIQfuhSOkbbr69GivNCL+Y5nzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MDUyMzEzNDQzN1oXDTIzMDUyMzE0MDQzN1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJLtcBS+
# A9c8l7ojt1OCClFd134lp5jk/VPD8B5b3jCMg50dl+nPPdxZ84fz/iBq3A1Ur+gz
# HIp+TWwrCHgOeq+OklaCDd9yMXJGU5qiX4cM738qPm3ptqCFSXrUzNx7QI2/ktaE
# 3mLYbKONCS93CAlAlmLTsBswkdRqKXRE4jX8r453xjqChQPSLFvxrQkJUzQ2wHpC
# oEPEfSdPSKOv6Tsnkh0Y1Apn/+kJ9fqVRI5UrPBxsYeVWJYJDW0o9Dg7JY4V4bhy
# QkRVwsniB7EzUy7mYksMGM+hnewwFabzDLANx2WXmUnDVATJ73Um/9Zrxcl4FaY5
# /zFwN0X+m/5WKMUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRJYD1gbvKucZORSGJEZ2QO1h6+sDANBgkqhkiG9w0BAQsFAAOCAQEAcIwG
# fBPgQvE0ZFvW4+t2JSKLPNjG7v1+bcZThc+yOxCZgn2IvxPZWlEhgWa0ir44ll6P
# Ie41Zc6PqDTjwUulITDShXqOVlHGhE5MdwFmgUriqZ9zPbQtUAsq/uzluHu7+XRP
# k5hZ6L7Exk3Fih+pacoLoVLTjZGcrFJ973VI/wf1CjCxifuLgPSzZ7URffpqn1Q1
# D1zo6awe4evQgYJzlOsIu9Z+gSff38t75ZMYmMXFiFr3XyLREnFEviaQoGGWONAV
# ulUGn5WLp8JQ65EhJFCiIlg06nLOL6/VoG9i5jTcTu5XLq2gf9+mL5CeRm9EBQrN
# QlIeOSw2xlQ2TfuzXjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEH7oUjpG26+vRorzQi/mOZ8wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFKMYppfuchFWNKMQh1dl4Va3uGXQMA0GCSqGSIb3DQEBAQUABIIBAALjY1G+
# +cmaRzwlQii0spva6+byCyZA9yB/U+GW/iMPNuLxUQRSlVmMQLquCyJE+FLfJi2q
# hXw3mhgXxNwjqvoQwu1+3lsqu6gfbdEEa3NQuYctx/luEDu5OfhXfQ4YMoYrKQTW
# 3lnU5kKxobsDBQ0Bj9a5SoZZSVkY00PVbvFhZ/lhb4Nag6bdtOTysn4ipXnZ5RpU
# 3DAthCBYWUTsFuSoLkIhSFwB4j83BsaVI1You10VtpnSa87kpTaUTI4967twiP1Q
# PkU0pZt43z9aqghwHK1eh7+nMd5uS5+XXVt1WXfo+Bkg9Nr4EIsnEGVe36Kgyq6p
# 3BAb+NkQlaSFNxg=
# SIG # End signature block
