Function New-PncAADApplication {
<# 
.SYNOPSIS
This function creates the Azure AD application for Plugncast  
.DESCRIPTION
The application created can be used to create Azure AD provider with New-PncOpenIdProviderAAD function. 
.PARAMETER Credential
The credential of the Azure AD user used to create the application. if absent, a dialog is displayed to connect to Azure AD 
.PARAMETER tenantId
The Active Directory Tenant. This is a GUID which represents the "Directory ID" of the AzureAD tenant
into which you want to create the apps. Look it up in the Azure portal in the "Properties" of the Azure AD
.PARAMETER appName
The name of the application 
.PARAMETER pncUrlHost
The host (ip or domain) of Plugncast server.
.PARAMETER pncUrlPort
The port of Plugncast server
.PARAMETER logFile
The path of log file

.OUTPUTS
The object that describe the application created. This object is already dumped in the file names "<appName>.json"
Its contains the following properties:
name : the application name
tenantId : the tenant id
clientId : the client id of application
objectId : the object id of application
clientSecret: the client secret generated (present only if parameter GeneratePassword is $true)
spId : the service pricipal id of application

 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $false)]
    [string] $appName = "Plugncast",
    [Parameter(Mandatory = $true)]
    [string] $pncUrlHost,
    [string] $pncUrlPort,
    [string] $LogFile
)
$Server=$pncUrlHost
if ($pncUrlPort) {
   $Server += ":" + $pncUrlPort
}
$BaseServerUri = "https://$Server/.plugncast"

$date = Get-Date
LogWrite("$date : create new AAD application with name `"$appName`" for server `"$server`"")

[String[]] $replyUrls= @("$BaseServerUri/openid/login/redirect", "$BaseServerUri/openid/adminconsent/redirect")
$logoutUrl="$BaseServerUri/openid/logout"
$homepage="https://$Server/cms"

$app = New-AADApplication-CommonsUtils  -credential $Credential -tenantId $tenantId -appName $appName `
        -ReplyUrls $replyUrls -logoutUrl $logoutUrl -homepage $homepage `
      -generatePassword $true -applicationPermissions "User.Read.All|Group.Read.All|GroupMember.Read.All"

Set-Content -Path ".\$appName.json" -Value ($app | ConvertTo-Json -Depth 5)
LogWrite("Application created")
$app
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUmgXXXkUBausmPyWICW/14Dbp
# 6KigggP3MIID8zCCAtugAwIBAgIQfuhSOkbbr69GivNCL+Y5nzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MDUyMzEzNDQzN1oXDTIzMDUyMzE0MDQzN1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJLtcBS+
# A9c8l7ojt1OCClFd134lp5jk/VPD8B5b3jCMg50dl+nPPdxZ84fz/iBq3A1Ur+gz
# HIp+TWwrCHgOeq+OklaCDd9yMXJGU5qiX4cM738qPm3ptqCFSXrUzNx7QI2/ktaE
# 3mLYbKONCS93CAlAlmLTsBswkdRqKXRE4jX8r453xjqChQPSLFvxrQkJUzQ2wHpC
# oEPEfSdPSKOv6Tsnkh0Y1Apn/+kJ9fqVRI5UrPBxsYeVWJYJDW0o9Dg7JY4V4bhy
# QkRVwsniB7EzUy7mYksMGM+hnewwFabzDLANx2WXmUnDVATJ73Um/9Zrxcl4FaY5
# /zFwN0X+m/5WKMUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRJYD1gbvKucZORSGJEZ2QO1h6+sDANBgkqhkiG9w0BAQsFAAOCAQEAcIwG
# fBPgQvE0ZFvW4+t2JSKLPNjG7v1+bcZThc+yOxCZgn2IvxPZWlEhgWa0ir44ll6P
# Ie41Zc6PqDTjwUulITDShXqOVlHGhE5MdwFmgUriqZ9zPbQtUAsq/uzluHu7+XRP
# k5hZ6L7Exk3Fih+pacoLoVLTjZGcrFJ973VI/wf1CjCxifuLgPSzZ7URffpqn1Q1
# D1zo6awe4evQgYJzlOsIu9Z+gSff38t75ZMYmMXFiFr3XyLREnFEviaQoGGWONAV
# ulUGn5WLp8JQ65EhJFCiIlg06nLOL6/VoG9i5jTcTu5XLq2gf9+mL5CeRm9EBQrN
# QlIeOSw2xlQ2TfuzXjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEH7oUjpG26+vRorzQi/mOZ8wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFNsGJ/ypzkAS4qjodSzLm0LvzD6eMA0GCSqGSIb3DQEBAQUABIIBAD+nuFua
# CW6FYzaQgbeobFWaq+Nk4QxCO3Fd5XiNp/xODbwudlAmCsMTXZqSlROakOTjovMt
# jTP73+r8tNAOOdkpVS/qzDx2asukXdK9WsPge31asTY9c/4WnlGfOtsqM/8Uz9hZ
# TXG7LRO9ViMd2qvetcUxxOcUtUf3jQBnZ/b7ar5F4f3rm3PACA5znvl13kd9Gtr2
# 9T8PpSwD99FLr1HqHMf9uXhMer3JBJ0cvfupAg0d5WT4n20aVT8KPgrK0HtytRxG
# oMv6/sclfJqwCLqk2JYC2lh9jWsIfra6eZsDbQvyLxAh+w1eBIPIlvXHNSPMiWV2
# SFC/m6S5jQbvDYA=
# SIG # End signature block
