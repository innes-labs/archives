<#
.SYNOPSIS
   PlugnCast : .URI generator from MS-Excel
.DESCRIPTION
  Requires the installation of the PSExcel Powershell module:
  Launch a Powershell console with administrator user and type
   > Install-Module -Name PSExcel

  MS-Excel format : 
  id	name	scheme	address	    port	thumbnail
  1	    TF1	    udp://	225.1.1.1	1234	./assets/tf1.png
.PARAMETER excelFileList
The list of MS-Excel file path (absolute or relative) describing the .URI files to generate.
.PARAMETER outputDirectory
The directory containing the generated URI files (default "./output")
.EXAMPLE
New-UriFromExcel.ps1 channels.xlsx
#>
 
[CmdletBinding()]
Param
(
    [string[]] $excelFileList = "./channels.xlsx",
    [string] $outputDirectory = "./output"
)

Begin
{
    $verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
    Import-Module PSPnc   
    Import-Module PSExcel
    function Write-UriFile {
        param (
            [Parameter(Mandatory = $True, ValueFromPipeline = $true)]
            [Object[]] $in,

            [Parameter(Mandatory = $true)]
            [String] $filename
        ) 
        process {
                
            $_filename1 = $filename.Split([IO.Path]::GetInvalidFileNameChars()) -join '_'
            $_filename = "./output/" + $_filename1 + ".uri"
            add-content -path $_filename $in
        }
    }
    function New-UriFromExcelFile($path){
        $datas = Import-XLSX -RowStart 1  -Path $path
        foreach($data in $datas ){
            $uri =  "{0}{1}:{2}" -f $data.scheme, $data.address, $data.port
            $thumbnail = $data.thumbnail
            if ($thumbnail.Contains("/"))
            {
                $thumbnail = $thumbnail.Replace("/", "`\");
            }
            if ($thumbnail.StartsWith("."))
            {
                $thumbnail = [string] (Get-Location) + "\" + $thumbnail
            }
            $tokens= @{IMG= $img; CATEGORY= 'IPTV'; TITLE=$data.name ; URI=$uri}
            New-PncUri -uri $uri -thumbnail $thumbnail -title $data.name -category 'IPTV' -vb:$verbose `
               | Write-UriFile -filename $data.name 
        }
    }     
}


Process
{
    foreach($n in $excelFileList){
        $PSDefaultParameterValues['*:Encoding'] = 'utf8'
        if (Test-Path $outputDirectory) {
            Remove-Item -Path $outputDirectory/*.uri -Force
        }
        else {
            New-Item -ItemType Directory -Force -Path $outputDirectory
        }
        $path = (resolve-path $n).Path
        Write-Verbose "Converting $path"
        New-UriFromExcelFile -path $path
        Write-Verbose "End of Job"
    }
}
End
{
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUkSVFMt0iKwQeD/ZqASggJ56x
# x3+gggP3MIID8zCCAtugAwIBAgIQfuhSOkbbr69GivNCL+Y5nzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MDUyMzEzNDQzN1oXDTIzMDUyMzE0MDQzN1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJLtcBS+
# A9c8l7ojt1OCClFd134lp5jk/VPD8B5b3jCMg50dl+nPPdxZ84fz/iBq3A1Ur+gz
# HIp+TWwrCHgOeq+OklaCDd9yMXJGU5qiX4cM738qPm3ptqCFSXrUzNx7QI2/ktaE
# 3mLYbKONCS93CAlAlmLTsBswkdRqKXRE4jX8r453xjqChQPSLFvxrQkJUzQ2wHpC
# oEPEfSdPSKOv6Tsnkh0Y1Apn/+kJ9fqVRI5UrPBxsYeVWJYJDW0o9Dg7JY4V4bhy
# QkRVwsniB7EzUy7mYksMGM+hnewwFabzDLANx2WXmUnDVATJ73Um/9Zrxcl4FaY5
# /zFwN0X+m/5WKMUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRJYD1gbvKucZORSGJEZ2QO1h6+sDANBgkqhkiG9w0BAQsFAAOCAQEAcIwG
# fBPgQvE0ZFvW4+t2JSKLPNjG7v1+bcZThc+yOxCZgn2IvxPZWlEhgWa0ir44ll6P
# Ie41Zc6PqDTjwUulITDShXqOVlHGhE5MdwFmgUriqZ9zPbQtUAsq/uzluHu7+XRP
# k5hZ6L7Exk3Fih+pacoLoVLTjZGcrFJ973VI/wf1CjCxifuLgPSzZ7URffpqn1Q1
# D1zo6awe4evQgYJzlOsIu9Z+gSff38t75ZMYmMXFiFr3XyLREnFEviaQoGGWONAV
# ulUGn5WLp8JQ65EhJFCiIlg06nLOL6/VoG9i5jTcTu5XLq2gf9+mL5CeRm9EBQrN
# QlIeOSw2xlQ2TfuzXjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEH7oUjpG26+vRorzQi/mOZ8wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFJtYJ6UjC2d+lYzWgTS+MXb5/PLLMA0GCSqGSIb3DQEBAQUABIIBAEr/okKd
# IKLZnKHIhNWdEo8IUuSihgr9kQVBlpp/slU7gOFetxmI642ZFUVzb1fYWqOrcNiE
# pgpo1NfhseZrE6JS1DpW0xBsrg+iYg1NCOD4BrKCM2ml0TIkiVZ2h3AiNAJw7+h9
# TUqq2Wq48PWNe/pSGnz+O82Es3nAGXbLZqyyJDDTrhqaJhjFjUuKBtgg+eYhp7xW
# DGEvO8BN2WaYJTjN2OnLnGYZ85jPB6KNnE8xgC1bn+YqGcf41IxdEcavimUPs6Ya
# 84fTBs5I849YRHVi3bghtKaPo8PnHW+Y4MBxw4bH+ntQ3THnxOB5TV89Ac7GvU3K
# cyGl0TJYMT6wFW8=
# SIG # End signature block
