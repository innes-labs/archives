Function Get-PncContentModelInstalled {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the installed models
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the installed models
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER domainList
The list of domains involved in the installation. Use "all" for all domains (default)
.PARAMETER lang
The description language of the model ("en-US", "fr-FR", ...). "x-default" by default
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell array of installed models.
Example of object formated in JSON :
[
    {
        "domain":  "domain1"
        "models":  [
            {
               "title":  "title 1",
               "version":  "1.20.10",
               "format":  "16/9",
               "description":  "Description 1",
               "category":  "Category 1",
               "file":  "model1.mask.maff"
            }
        ],
    },
    {
        "domain":  "domain2"
        "models":  [
            {
                 "title":  "title 2",
                "version":  "1.10.12",
                 "format":  "16/9",
                 "description":  "Description 2",
                 "category":  "Category 2",
                 "file":  "model2.mask.maff"
             },
             ...
        ],
    }
]
.EXAMPLE
Get-PncContentModelInstalled -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
Retrieve all models installed
.EXAMPLE
Get-PncContentModelInstalled -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin -domainList domain1
Retrieve models installed on domain "domain1"
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [string[]] $domainList = "all",
    [string] $lang = "x-default",
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
$ServerUri = "https://$Server"

# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve models for server `"$server`"")

 
# List of domains
$configObject = Get-PncDomainsAndTargets $server -logFile "none" -UrlLogin $UrlLogin -UrlPassword $UrlPassword
function GetModels {
    param (
        [string] $domain
    )
    $Body = "<D:propfind xmlns:D=`"DAV:`" xmlns:ias=`"ns.innes.appli.server`"><D:prop><D:getcontenttype/></D:prop><D:prop><D:getcontentlength/></D:prop><D:prop><D:getlastmodified/></D:prop><D:prop><D:getetag/></D:prop><D:prop><D:id/></D:prop><D:prop><D:resourcetype/></D:prop><D:prop><D:owner/></D:prop><D:prop><D:current-user-privilege-set/></D:prop><D:prop><ias:hidden-resources/></D:prop></D:propfind>"
    $Headers = @{
        DEPTH = "1"
        "X-HTTP-METHOD-OVERRIDE" = "PROPFIND"
    }
    Start-Sleep -m $SleepDurationBeforeCommand
    $BaseUri = "/.plugncast/.domains/" + $domain
    try {
        $Uri = $ServerUri + $BaseUri + "/.domain-repository/.models/.medias/"
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'text/xml' -Uri $Uri   -Body $Body -Headers $Headers
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw $_.Exception
    }
    [xml]$result = [xml]$ExecutedRequest
    [System.Xml.XmlElement] $root = $result.get_DocumentElement()
    [System.Collections.ArrayList]$uris =@();
    foreach ($response in $root.ChildNodes) {
        foreach ($child in $response.ChildNodes) {
            $name = $child.ToString()
            $value = $child.InnerText
            if ($name -eq "href")
            {
                if ($value.EndsWith(".mask.maff") -or $value.EndsWith(".mask.uri"))
                {
                    $value = $value.Substring($BaseUri.Length+1);
                    $uris.Add($value) | Out-Null
                }
            }
        }
    }
    $Body = "declare namespace im = `"ns.innes.metadata`";im:getDescriptions(("
    for ($i = 0; $i -lt $uris.Count; $i++)
    {
        $Body += "`"" + $uris[$i] + "`""
        if ($i -ne $uris.Count -1)
        {
            $Body += ","
        }
    }
    $Body += "))"
    try {
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/xquery' -Uri $BaseServerUri".domains/"$domain"/.db/metadatadb"   -Body $Body
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw $_.Exception
    }
    $enc = [System.Text.Encoding]::UTF8
    $bytes = $enc.GetBytes($ExecutedRequest.Content)
    $content = $enc.GetString($bytes)
    [xml]$result = [xml]$content
    [System.Xml.XmlElement] $root = $result.get_DocumentElement()

    [PSCustomObject]$Namespace = @{rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
     xmp="http://ns.adobe.com/xap/1.0/"
     xmpMM="http://ns.adobe.com/xap/1.0/mm/"
      stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#"
      xmpGImg="http://ns.adobe.com/xap/1.0/g/img/"
      dc="http://purl.org/dc/elements/1.1/"
      Iptc4xmpExt="http://iptc.org/std/Iptc4xmpExt/2008-02-29/"
      im="ns.innes.metadata"
      xml="http://www.w3.org/XML/1998/namespace"
      xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/"}
    $ns = New-Object System.Xml.XmlNamespaceManager($result.NameTable)
    foreach ($key in $Namespace.keys) {
        $ns.AddNamespace($key, $Namespace[$key])
    }
    [System.Collections.ArrayList]$models =@()
    foreach ($child in $root.ChildNodes) {
        $file = $child.about
        $index = $file.LastIndexOf("/");
        $file = $file.Substring($index + 1);
        $category = ""
        $title = ""
        $description = ""
        $format = ""
        $version = ""
        $metadata = $child.EmbeddedMetadata
        if ($metadata) {
            $version = $metadata.VersionID
            $res = $metadata.SelectSingleNode("im:category//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
            if ($res) {
                $category = $res.InnerText
            }
            $res = $metadata.SelectSingleNode("dc:title//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
            if ($res) {
                $title = $res.InnerText
            }
            $res = $metadata.SelectSingleNode("dc:description//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
            if ($res) {
                $description = $res.InnerText
            }
            if ($metadata.videoDisplayAspectRatioCategory) {
                $format = $metadata.videoDisplayAspectRatioCategory
            }
        }
        $metadatas = @{
            file = $file
            version     = $version
            format      = $format
            category    = $category
            title       = $title
            description = $description
        }
        $models.Add($metadatas) | Out-Null
    }
    return ,$models
}
[System.Collections.ArrayList]$domainModels =@()
foreach ($domain in $configObject.domains) {
    if (($domainList -eq "all") -or ($domainList -contains $domain.Name)) {
        $models = GetModels $domain.Name
        if ($models.Count -ne 0)
        {
            [PSCustomObject]$obj = @{
                domain = $domain.Name
                models = $models
            }
            $domainModels.Add($obj) | Out-Null
        }
    }
}
LogWrite(,$domainModels | ConvertTo-Json -Depth 5)
,$domainModels
}






# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUDxkgk8oq4vHpW/Z//D/4mHqy
# eROgggP3MIID8zCCAtugAwIBAgIQfuhSOkbbr69GivNCL+Y5nzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MDUyMzEzNDQzN1oXDTIzMDUyMzE0MDQzN1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJLtcBS+
# A9c8l7ojt1OCClFd134lp5jk/VPD8B5b3jCMg50dl+nPPdxZ84fz/iBq3A1Ur+gz
# HIp+TWwrCHgOeq+OklaCDd9yMXJGU5qiX4cM738qPm3ptqCFSXrUzNx7QI2/ktaE
# 3mLYbKONCS93CAlAlmLTsBswkdRqKXRE4jX8r453xjqChQPSLFvxrQkJUzQ2wHpC
# oEPEfSdPSKOv6Tsnkh0Y1Apn/+kJ9fqVRI5UrPBxsYeVWJYJDW0o9Dg7JY4V4bhy
# QkRVwsniB7EzUy7mYksMGM+hnewwFabzDLANx2WXmUnDVATJ73Um/9Zrxcl4FaY5
# /zFwN0X+m/5WKMUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRJYD1gbvKucZORSGJEZ2QO1h6+sDANBgkqhkiG9w0BAQsFAAOCAQEAcIwG
# fBPgQvE0ZFvW4+t2JSKLPNjG7v1+bcZThc+yOxCZgn2IvxPZWlEhgWa0ir44ll6P
# Ie41Zc6PqDTjwUulITDShXqOVlHGhE5MdwFmgUriqZ9zPbQtUAsq/uzluHu7+XRP
# k5hZ6L7Exk3Fih+pacoLoVLTjZGcrFJ973VI/wf1CjCxifuLgPSzZ7URffpqn1Q1
# D1zo6awe4evQgYJzlOsIu9Z+gSff38t75ZMYmMXFiFr3XyLREnFEviaQoGGWONAV
# ulUGn5WLp8JQ65EhJFCiIlg06nLOL6/VoG9i5jTcTu5XLq2gf9+mL5CeRm9EBQrN
# QlIeOSw2xlQ2TfuzXjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEH7oUjpG26+vRorzQi/mOZ8wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFPCzO2F1WttbdD6BCMoAwfKU5eo/MA0GCSqGSIb3DQEBAQUABIIBADlhggJn
# 5r/xoxIimL+cgEFlfoZEN+00B6cMCSfEtBOWAvkWsY0SZ0ZY46PNbHqxK3JOKK8/
# n1RPW3Wkv61Vi4Sd+TRkGm2anYvPFyOZl6i/OA6kLpq9amN+5+46RZqtRMe1PWhz
# iHXBfqn10D8sOng5NUGaIHYGb8VMxxht9tFEfvCYpW++k5U+RWMD8FPR+2WuKbgP
# DcFaZgwkHyyfA+qmxHBMnio/jdzU4xvmM7vlWhHo8bTnTq2mALKvjIy8tAr5LUOW
# jSVeDLeF8p/wvhpdlwNwryHCTSBGW7hOyQwRMrYuA+83sw/RP3PkpjGPcBbbUOPm
# LWHoktr2wsWo4cs=
# SIG # End signature block
