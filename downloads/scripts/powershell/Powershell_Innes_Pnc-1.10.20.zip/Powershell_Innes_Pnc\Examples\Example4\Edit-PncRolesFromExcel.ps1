﻿<#
.SYNOPSIS
This script permits to change the roles of a PlugnCast server from an MS-Excel file.
.DESCRIPTION
This script permits to change the roles of a PlugnCast server from an MS-Excel file.
The table of the Excel file must respect the format of the table produced by the script Get-PncRolesToExcel.
.PARAMETER excelFilePath
The path of the MS-Excel file path. The default value is ".\Roles-INNES_PlugnCast.xlsx"
.PARAMETER permitWord
The word stored in the MS-Excel cells for the allowed features. Comparisons are not case sensitive and spaces in MS-Excel cells are removed 
.PARAMETER notPermitWord
The word stored in the MS-Excel cells for the unauthorized features. Comparisons are not case sensitive and spaces in MS-Excel cells are removed 
.PARAMETER urlHost
The plugncast G3 server host (IP or DNS domain)
 .PARAMETER urlPort
The  plugncast G3 server port (443 by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used (default "superadmin")
.PARAMETER urlPassword
The password of authentication if the certificate is not used (default "superadmin")
.PARAMETER logFile
The path of log file
.EXAMPLE
PS C:\install directory>.\Edit-PncRolesToExcel -excelFilePath ".\input.xlsx" -urlHost 192.168.1.23
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$false)]
    [string] $excelFilePath = ".\Roles-INNES_PlugnCast.xlsx",
    [Parameter(Mandatory=$false)]
    [ValidatePattern("^[^ ]*$")]
    [string] $permitWord = "x",
    [Parameter(Mandatory=$false)]
    [ValidatePattern("^[^ ]*$")]
    [string] $notPermitWord = "",
    [string] $UrlHost,
    [string] $UrlPort = 443,
    [string] $UrlLogin = "superadmin",
    [string] $UrlPassword = "superadmin",
    [string] $LogFile
)
$permitWord = $permitWord.ToLower();
$notPermitWord = $notPermitWord.ToLower();
$header=@("Description","Identifier")
[PSCustomObject] $rolesAndFeatures = Get-PncRolesInformation
$header += $rolesAndFeatures.roles

# Import Pnc Module
Import-Module PSPnc -MinimumVersion 1.10.17
if (!$?) {
	Write-Host("You must use PnC module Version 1.10.17 minimum. Please update it before re-trying.")
	exit(1)
}
# Import Module PSExcel
Import-Module PSExcel
# Clear the log file of any previous try
If ($LogFile -and (Test-Path $LogFile) -eq $True) {
    Remove-Item -Path $LogFile
}
$verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)

# Get roles
Write-Host("Start to query the Pnc server '$urlHost'")
$roles = Get-PncRoles -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -UrlPassword $UrlPassword -LogFile $LogFile -vb:$verbose
try {
# Get new role in excel file
    $excel = Import-XLSX -Path $excelFilePath -Header $header
}
catch 
{
    Write-Error($Ex.Exception.message)
    Write-Error("Unable to read the Excel file `"" + $excelFilePath + "`"")
    exit 1
}
if (!$excel)
{
    Write-Error("Unable to read the Excel file `"" + $excelFilePath + "`"")
	exit(1)
}
$edited = 0
for ($i = 0; $i -lt $rolesAndFeatures.roles.Count; $i++) { 
    $role = $rolesAndFeatures.roles[$i]
    [System.Collections.ArrayList]$features = @()

    foreach ($line in $excel)
    {
        $feature = $line.identifier;
        $r = [string] $line.$role
        $r = $r.Trim().ToLower()
        if ($r -eq $permitWord)
        {
            $features += $feature
        }
        elseif ($r -eq $notPermitWord)
        {
        }
        else {
            Write-Error("Value '" + $r + "' not permitted")
            exit 1         
        }
    }
    #  Verify if features are changed
    [System.Collections.ArrayList]$oldFeatures = @()
    foreach ($p in $roles.$role.permissions.PSObject.Properties)
    {
        if ($p.value -eq "permit")
        {
            $oldFeatures += $p.name
        }
        
    }
    $oldFeatures = $oldFeatures | Sort-Object
    $diff = Compare-Object -ReferenceObject $features -DifferenceObject $oldFeatures
    if ($diff)
    {
        if ($i -eq 0)
        {
            Write-Error ("cannot modify the super administrator role ");
            exit 1
        }
        else {
            Write-Host("Change role `"" + $role + "`"")
            Edit-PncRole -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -UrlPassword $UrlPassword -role $role -feature $features -LogFile $LogFile -vb:$verbose
            $edited++
        }
    }
}
if ($edited -eq 0)
{
    Write-Host("No role changed")
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUkVTtG/S9Z7otVGzlfsb5DBEj
# t1igggP3MIID8zCCAtugAwIBAgIQfuhSOkbbr69GivNCL+Y5nzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MDUyMzEzNDQzN1oXDTIzMDUyMzE0MDQzN1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJLtcBS+
# A9c8l7ojt1OCClFd134lp5jk/VPD8B5b3jCMg50dl+nPPdxZ84fz/iBq3A1Ur+gz
# HIp+TWwrCHgOeq+OklaCDd9yMXJGU5qiX4cM738qPm3ptqCFSXrUzNx7QI2/ktaE
# 3mLYbKONCS93CAlAlmLTsBswkdRqKXRE4jX8r453xjqChQPSLFvxrQkJUzQ2wHpC
# oEPEfSdPSKOv6Tsnkh0Y1Apn/+kJ9fqVRI5UrPBxsYeVWJYJDW0o9Dg7JY4V4bhy
# QkRVwsniB7EzUy7mYksMGM+hnewwFabzDLANx2WXmUnDVATJ73Um/9Zrxcl4FaY5
# /zFwN0X+m/5WKMUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRJYD1gbvKucZORSGJEZ2QO1h6+sDANBgkqhkiG9w0BAQsFAAOCAQEAcIwG
# fBPgQvE0ZFvW4+t2JSKLPNjG7v1+bcZThc+yOxCZgn2IvxPZWlEhgWa0ir44ll6P
# Ie41Zc6PqDTjwUulITDShXqOVlHGhE5MdwFmgUriqZ9zPbQtUAsq/uzluHu7+XRP
# k5hZ6L7Exk3Fih+pacoLoVLTjZGcrFJ973VI/wf1CjCxifuLgPSzZ7URffpqn1Q1
# D1zo6awe4evQgYJzlOsIu9Z+gSff38t75ZMYmMXFiFr3XyLREnFEviaQoGGWONAV
# ulUGn5WLp8JQ65EhJFCiIlg06nLOL6/VoG9i5jTcTu5XLq2gf9+mL5CeRm9EBQrN
# QlIeOSw2xlQ2TfuzXjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEH7oUjpG26+vRorzQi/mOZ8wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFJkhU9YPpuirdaA9JG/IKCYkYuTMMA0GCSqGSIb3DQEBAQUABIIBADskofJ/
# pGPmmcfhNYBYz6h8MVp0Pt+7n0FO7Unoqh/8Q6JgIHY7l2DElChWEsMhxgVhb6bb
# r5d9yEE/H24etzwlwMqyxKDqfUJ/NAen/BTSnNDTmunIrsIHYAyCBkmYHNvJP3oq
# J/jSn5IxsdxK1wPN03NNAff69Cyamx32eOwAPX73jVbLv5KLH/Wz1GkQ/w8xix6h
# v1oXnt5Qrzj0uwpkdNYVoYkQjX1uQo0EzU00aVRjKeN7lxzA83polvAg3WfjEi7E
# BlkBLZbwS6JBixCim3ObVxvDWnRP7NfGRBPGhYJxfBWJ9TfrDKX5Iki9SAD5m4AI
# hTZ9W5vYGLvudjU=
# SIG # End signature block
