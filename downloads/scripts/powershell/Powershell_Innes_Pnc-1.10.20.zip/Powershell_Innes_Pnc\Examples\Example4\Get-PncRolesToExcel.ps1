﻿<#
.SYNOPSIS
This script permits to read the roles of a PlugnCast server and write it into an MS-Excel file.
.DESCRIPTION
This script permits to read the roles of a PlugnCast server and write it into an MS-Excel file.
The columns names as well as the descriptions of the functionalities are translated into the selected language (-lang option).
The table identifiers are as follows:
description: description of the feature
identifier: feature identifier
super-administrator: super administrator role
administrator: general administrator role
domain-administrator: domain administrator role
domain-editor: domain editor role
editor: editor role 
help-desk : help desk role
contributor : contributor role.
The rows of the table are listed in alphabetical order of the feature identifiers in the second column.
The values of the feature authorization cells for each role are defined by the options -permitWord and -notPermitWord.
.PARAMETER excelFilePath
The MS-Excel file path. The default value is ".\Roles-INNES_PlugnCast.xlsx"
.PARAMETER lang
The language of the produced MS-excel file ("en", "fr", "es", "de", "ru")
.PARAMETER worksheet
The worksheet name of the produced MS-excel file.
.PARAMETER permitWord
The word stored in the MS-Excel cells for allowed features (space character is not allowed). The default value is "x"
.PARAMETER notPermitWord
The word stored in the MS-Excel cells for the unauthorized features (space character is not allowed). The default value is "" (empty string)
.PARAMETER urlHost
The PlugnCast G3 server host (IP or DNS domain)
 .PARAMETER urlPort
The PlugnCast G3 server port (443 by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used (default "superadmin")
.PARAMETER urlPassword
The password of authentication if the certificate is not used (default "superadmin")
.PARAMETER logFile
The path of log file
.EXAMPLE
PS C:\install directory>.\Get-PncRolesToExcel -excelFilePath ".\output.xlsx"
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$false)]
    [string] $excelFilePath = ".\Roles-INNES_PlugnCast.xlsx",
    [Parameter(Mandatory=$false)]
    [ValidateSet("en", "fr", "es", "de")]
    [string] $lang = "fr",
    [Parameter(Mandatory=$false)]
    [ValidatePattern("^[^ ]*$")]
    [string] $permitWord = "x",
    [Parameter(Mandatory=$false)]
    [ValidatePattern("^[^ ]*$")]
    [string] $notPermitWord = "",
    [string] $worksheet = "",
    [string] $UrlHost,
    [string] $UrlPort = 443,
    [string] $UrlLogin = "superadmin",
    [string] $UrlPassword = "superadmin",
    [string] $LogFile
)
# Import Pnc Module
Import-Module PSPnc -MinimumVersion 1.10.17
if (!$?) {
	Write-Host("You must use PnC module Version 1.10.17 minimum. Please update it before re-trying.")
	exit(1)
}
[PSCustomObject] $rolesAndFeatures = Get-PncRolesInformation

Function GetTranslate 
{
    Param ([PSCustomObject] $label)
    $obj = $rolesAndFeatures.translates.$label
    if (!$obj)
        {
            return $null
        }
    else {
        return $obj.locales.$lang
    }
}
$header=@("Description","Identifier")
$header += $rolesAndFeatures.roles
for ($i = 0; $i -lt $header.count; $i++)
{
    $header[$i] = GetTranslate $header[$i]
}
# Import Pnc Module
Import-Module PSPnc -MinimumVersion 1.10.17
if (!$?) {
	Write-Host("You must use PnC module Version 1.10.17 minimum. Please update it before re-trying.")
	exit(1)
}
# Import Module PSExcel
Import-Module PSExcel
# Clear the log file of any previous try
If ($LogFile -and (Test-Path $LogFile) -eq $True) {
    Remove-Item -Path $LogFile
}
$verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)

# Get roles
Write-Host("Start to query the Pnc server(s)...")
$roles = Get-PncRoles -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -UrlPassword $UrlPassword -LogFile $LogFile -vb:$verbose
# compute result
[System.Collections.ArrayList]$result = @()

foreach ($feature in $rolesAndFeatures.features) {
    $description = GetTranslate $feature
    $line = New-Object PSObject 
    $line | Add-Member -MemberType NoteProperty -Name "description" -Value $description| Out-Null
    $line | Add-Member -MemberType NoteProperty -Name "identifier" -Value $feature| Out-Null
    foreach ($role in $rolesAndFeatures.roles) {
        $permission = $roles.$role.permissions.$feature
        if ($permission -eq "permit")
        {
            $permission = $permitWord
        }
        else {
            $permission = $notPermitWord
        }
        $line | Add-Member -MemberType NoteProperty -Name "$role" -Value $permission| Out-Null

    }
    $result += $line
}

Write-Host("Write the result...")
try {
# Write Excel file
$worksheetName=$WorkSheet
if (!$WorkSheetName)
{

    $WorkSheetName = GetTranslate "Role_plural"
}
if ($excelFilePath -and (Test-Path $excelFilePath) -eq $True) {
    Remove-Item -Path $excelFilePath
}
$result | Export-XLSX -Path $excelFilePath -header $header -Autofit -WorksheetName $worksheetName
# Re-open the file
$Excel = New-Excel -Path $excelFilePath
$ExcelWorkSheet = $Excel | Get-WorkSheet -Name $worksheetName
$Excel.Workbook.View.ActiveTab=$ExcelWorkSheet.Index-1
# Format the worksheek
# $ExcelWorkSheet | Format-Cell -HorizontalAlignment "Center" -VerticalAlignment "Top" -Autofit -WrapText $true
$ExcelWorkSheet | Format-Cell -Header -Bold $True -WrapText $true
$ExcelWorkSheet | Format-Cell -StartColumn 3 -HorizontalAlignment "Center" -VerticalAlignment "Center" 

# Save file
$Excel | Close-Excel -Save
Write-Host("The result is in the file " + $excelFilePath)
}
catch {
    Write-Host("Error while writing the Excel file `"" + $excelFilePath + "`"")

}


# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUVvzO27oVudT51oqbJEk4ZW0a
# u7+gggP3MIID8zCCAtugAwIBAgIQfuhSOkbbr69GivNCL+Y5nzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MDUyMzEzNDQzN1oXDTIzMDUyMzE0MDQzN1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJLtcBS+
# A9c8l7ojt1OCClFd134lp5jk/VPD8B5b3jCMg50dl+nPPdxZ84fz/iBq3A1Ur+gz
# HIp+TWwrCHgOeq+OklaCDd9yMXJGU5qiX4cM738qPm3ptqCFSXrUzNx7QI2/ktaE
# 3mLYbKONCS93CAlAlmLTsBswkdRqKXRE4jX8r453xjqChQPSLFvxrQkJUzQ2wHpC
# oEPEfSdPSKOv6Tsnkh0Y1Apn/+kJ9fqVRI5UrPBxsYeVWJYJDW0o9Dg7JY4V4bhy
# QkRVwsniB7EzUy7mYksMGM+hnewwFabzDLANx2WXmUnDVATJ73Um/9Zrxcl4FaY5
# /zFwN0X+m/5WKMUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRJYD1gbvKucZORSGJEZ2QO1h6+sDANBgkqhkiG9w0BAQsFAAOCAQEAcIwG
# fBPgQvE0ZFvW4+t2JSKLPNjG7v1+bcZThc+yOxCZgn2IvxPZWlEhgWa0ir44ll6P
# Ie41Zc6PqDTjwUulITDShXqOVlHGhE5MdwFmgUriqZ9zPbQtUAsq/uzluHu7+XRP
# k5hZ6L7Exk3Fih+pacoLoVLTjZGcrFJ973VI/wf1CjCxifuLgPSzZ7URffpqn1Q1
# D1zo6awe4evQgYJzlOsIu9Z+gSff38t75ZMYmMXFiFr3XyLREnFEviaQoGGWONAV
# ulUGn5WLp8JQ65EhJFCiIlg06nLOL6/VoG9i5jTcTu5XLq2gf9+mL5CeRm9EBQrN
# QlIeOSw2xlQ2TfuzXjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEH7oUjpG26+vRorzQi/mOZ8wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFEwOksY/cz5+FRdkUs/oFT+BEOqLMA0GCSqGSIb3DQEBAQUABIIBAGbJHD9p
# AcoSDSNVz+PQ9LwLCWMiDgcNdwVwDWRFb5NUmbAIuN30X/CmYXJkbBnNtXm91YJg
# ft1673g7aNeqrzMhlF60tx3FGLd0nD4k+T+MBh5lsFuMsmR/7c14XYBh3kidiz+s
# 6IpH+0kho3IZaOpqIdCUIEpQJqMGjqT1mz/6VqReKDi1YEllxpqgaDNH8sn2cktu
# Qr3aPfNIyGPleWRpwNtl6QeQUw7YnWBHtSg6tcIiFFT64PE0fHqpsyzCAvLCWcui
# yLrQzJ86fLhEfk56PsRN0R94Zj0/2Q96nK5rDqo4udN0N337qLYiWmiDRm8GgsdD
# xd76eO9TW2HqC+M=
# SIG # End signature block
