Function New-AADApplication {
<# 
.SYNOPSIS
This function creates a Azure Active Directory application.  
.DESCRIPTION
This function creates a Azure Active Directory application.  
.PARAMETER Credential
Credential (admin profile) used to create the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been created. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
Name of the Azure Active Directory application.
.PARAMETER authorizations
Authorization type:
- "onedrive" : to access to OneDrive resources
- "signmeeting_ews": to access to MS-Exchange room mailbox resources for SignMeeting MS-Exchange application
- "signmeeting_m365": to access to M365 room mailbox resources for SignMeeting-M365 application
- "m365_room": to access to M365 room mailbox resource for SBL10e m365_room application
- "m365_user": to access to M365 user presence resource for SBL10e m365_user application
.PARAMETER logFile
Log file path
.OUTPUTS
The result is an object that is describing the created Azure Active Directory application. 
It contains the following properties:
- name : Azure Active directory application name
- tenantId : Azure Active directory's tenant id
- clientId : Azure Active directory's application (client) Id
- objectId : Azure Active directory's application object id
- clientSecret: Azure Active directory's client secret
- spId : Azure Active directory's application service principal id
These object properties are flushed automatically in the "<appName>.json" file in the current directory.
.EXAMPLE
PS C:\>$result = New-AADApplication -appname "SignMeeting"  -authorizations "signmeeting_ews"
A consent request will be sent in 30 seconds in your browser.
You must log into an administrator account of your organization and grant the necessary permissions.
PS C:\>$result
Name                           Value
----                           -----
clientId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
objectId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
spId                           xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
name                           SignMeeting
tenantId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
clientSecret                   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
.NOTES 
 VERSION:1.10.10
#>

   [CmdletBinding()] 
   param(
      [PSCredential] $Credential,
      [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
      [string] $tenantId,
      [Parameter(Mandatory = $true)]
      [string] $appName,
      [Parameter(Mandatory = $true)]
      [ValidateSet('onedrive','signmeeting_ews', 'signmeeting_m365', 'm365_room', 'm365_user')]
      [string[]] $authorizations,
      [string] $LogFile
   )
   $date = Get-Date
   LogWrite("$date : create new AAD application with name `"$appName`"")
   try {
      $consentRedirectUri = "http://localhost:23456/consent/redirect"
      [String[]] $replyUrls = @($consentRedirectUri)
      $app = New-AADApplication-CommonsUtils  -credential $Credential -tenantId $tenantId -appName $appName `
         -replyUrls $replyUrls `
         -generatePassword $true
      $requiredResourcesAccess = New-Object System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.RequiredResourceAccess]
      for ($i = 0; $i -lt $authorizations.length; $i++)
      {
          $authorizations[$i] = ($authorizations[$i]).ToLower();
      }
      $hasDelegatedPermission = $false;
      if ($authorizations.Contains("onedrive")) {
         $permissions = "Files.ReadWrite.All|Sites.ReadWrite.All|User.Read"
         $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions $permissions -applicationPermissions $permissions
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("signmeeting_ews")) {
         $requiredPermissions = GetRequiredPermissions -appid "00000002-0000-0ff1-ce00-000000000000" `
            -requiredApplicationPermissions "full_access_as_app"
         $requiredResourcesAccess.Add($requiredPermissions)
         $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions "EWS.AccessAsUser.All|User.Read"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("signmeeting_m365")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredApplicationPermissions "Place.Read.All|User.Read.All|Calendars.ReadWrite"
         $requiredResourcesAccess.Add($requiredPermissions)
      }
      if ($authorizations.Contains("m365_room")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredApplicationPermissions "Calendars.Read|User.Read.All"
         $requiredResourcesAccess.Add($requiredPermissions)
      }
      if ($authorizations.Contains("m365_user")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredDelegatedPermissions "Directory.AccessAsUser.All|Presence.Read.All"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      Set-AzureADApplication -ObjectId $app.ObjectId -RequiredResourceAccess $requiredResourcesAccess
    #   $app.clientSecret = [System.Web.HttpUtility]::UrlEncode($app.clientSecret)
      Set-Content -Path ".\$appName.json" -Value ($app | ConvertTo-Json -Depth 5)
      $hasDelegatedPermission = $true
      if ($hasDelegatedPermission) 
      {
        Write-Host "A consent request will be sent in 30 seconds in your browser.`
        You must log into an administrator account of your organization and grant the necessary permissions."
        Start-Sleep 30
        $request = "https://login.microsoftonline.com/" + $app.tenantId + "/adminconsent" + `
        "?client_id=" + $app.ClientId + "&redirect_uri=" + $consentRedirectUri
        Start-Process $request
        Start-ConsentRedirectServer
      }
      Write-Host("Application created")
      $app
   }
   catch {
      LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
      throw $_.Exception
   }
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUvP80zySqOUXdGJVU9pZUFeQK
# oOGgggP3MIID8zCCAtugAwIBAgIQdGxGjDixRqpIQLrPwCzIpTANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDgxNjA4MTcxM1oXDTIyMDgxNjA4MzcxM1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANLI4nRS
# NI/6Rc0n0Lt3bPJ5uqFZCzC5zpNEZ4LRDew8b6s86Avmsd6q9M5+3QRlPFzKNg86
# b6RI64cQpjrd3/YtHfe7YvLsKUkyIVXnoH/s5ItXgVWK8Oc5wNEAdl/UjwdHsCWG
# fAerS6bRe9+SU5nefEr8poGTJN74/Gk3jERa0zCqRKeXWCskHv4GaLvIAoXAmslM
# 3etZhmP4+l/6mSdtXWZ7R2vmhoeL6Evzkc7I7CUbQxSHo+SO+c+famylarbswa+g
# PLGxEADHT1vYeCd4VlOT9iC59vqNvFi+l1+6QldUmCh1ukw0+mJ4KOnx/pZPIHRq
# IjLt5YJ4fJLCiaECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBS+Fv7cxUa5SBHNE16iGCPRAQdEdDANBgkqhkiG9w0BAQsFAAOCAQEAmk/l
# 2Xt33/V6mPGRIaenr76VqhST2RCrCUXm0ezWpvQoIpzsD486GrnwX8Uc8B23GKl+
# pm8fV41Jdz5lRRqa3+PqR/wCzFnUTv1XpNcILrRvjGRYcuZPZTeqoYog+eYArWml
# kNRiJYpzx5Cm4IdgYF2pcoumoyv3XnNxZKEM67a3ZSxkkWrxlO/7zInMIz5GyE1S
# m5p9Pygq2wbNCxwdc/LSCsEULHLLOpzuy/WvzLvXZQV6Ia4Pf9o5tEuSvnL31XZN
# 3R6Jhwh2cufBtrTom8LfAdQ4MK2graz5a8jsDccm4wB4rDw+WT8LvuHas7QPX9f0
# EEwX7nuJU0FZ29mf6zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEHRsRow4sUaqSEC6z8AsyKUwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFF5PLwym5qtfXymFMBXbtzVBw7ICMA0GCSqGSIb3DQEBAQUABIIBADNEBVa9
# MKKw1x34xhQvWPC49RcqM3AAxnUvwLvRLc6SkB1X3Pn3RDC6gMufdbSwrHVYikOK
# fbqDMNzZNGlJETh/9Y4smYbIXc5cGU6FYzEIk6q0CjrtetuWCQchCBJstEjco8bd
# Gv8fPqK5VGIWkDMWErDeKtXoxtMrQH4pToJ00nXuw0ifVNITvMp5Ol+S9lSUaa2h
# AjczXjr0ImHW3/FL1vJY6wciDLIaWDUK73tR0TwELFSGk1OwHxZA22fGKa2deE8J
# 4qoX5HW5gYnM7DRHL6RJ9+PdiNmjYWTLezffakUSrXfhJHXpLR1TytvonhxYHjhh
# KOZAjrS0j02ptgE=
# SIG # End signature block
