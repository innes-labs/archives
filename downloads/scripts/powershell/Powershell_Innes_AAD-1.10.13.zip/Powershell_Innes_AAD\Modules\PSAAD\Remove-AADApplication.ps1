Function Remove-AADApplication {
<# 
.SYNOPSIS
This function removes a Azure Active Directory application.  
.DESCRIPTION
This function removes a Azure Active Directory application.  
.PARAMETER Credential
Exchange credential (admin profile) used to remove the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the Exchange credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been removed. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
The name of the Azure Active Directory application.
.OUTPUTS
Nothing
.EXAMPLE
PS C:\>Remove-AADApplication -appname "SignMeeting"
 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName
)

$date = Get-Date
LogWrite("$date : delete AAD application with name `"$appName`"")

Remove-AADApplication-CommonsUtils -credential $Credential -tenantId $tenantId -appName $appName 
LogWrite("Application removed")

}
# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUGNKiDNmaEp5ARUC1u5SFjcqj
# JBagggP3MIID8zCCAtugAwIBAgIQdGxGjDixRqpIQLrPwCzIpTANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDgxNjA4MTcxM1oXDTIyMDgxNjA4MzcxM1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANLI4nRS
# NI/6Rc0n0Lt3bPJ5uqFZCzC5zpNEZ4LRDew8b6s86Avmsd6q9M5+3QRlPFzKNg86
# b6RI64cQpjrd3/YtHfe7YvLsKUkyIVXnoH/s5ItXgVWK8Oc5wNEAdl/UjwdHsCWG
# fAerS6bRe9+SU5nefEr8poGTJN74/Gk3jERa0zCqRKeXWCskHv4GaLvIAoXAmslM
# 3etZhmP4+l/6mSdtXWZ7R2vmhoeL6Evzkc7I7CUbQxSHo+SO+c+famylarbswa+g
# PLGxEADHT1vYeCd4VlOT9iC59vqNvFi+l1+6QldUmCh1ukw0+mJ4KOnx/pZPIHRq
# IjLt5YJ4fJLCiaECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBS+Fv7cxUa5SBHNE16iGCPRAQdEdDANBgkqhkiG9w0BAQsFAAOCAQEAmk/l
# 2Xt33/V6mPGRIaenr76VqhST2RCrCUXm0ezWpvQoIpzsD486GrnwX8Uc8B23GKl+
# pm8fV41Jdz5lRRqa3+PqR/wCzFnUTv1XpNcILrRvjGRYcuZPZTeqoYog+eYArWml
# kNRiJYpzx5Cm4IdgYF2pcoumoyv3XnNxZKEM67a3ZSxkkWrxlO/7zInMIz5GyE1S
# m5p9Pygq2wbNCxwdc/LSCsEULHLLOpzuy/WvzLvXZQV6Ia4Pf9o5tEuSvnL31XZN
# 3R6Jhwh2cufBtrTom8LfAdQ4MK2graz5a8jsDccm4wB4rDw+WT8LvuHas7QPX9f0
# EEwX7nuJU0FZ29mf6zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEHRsRow4sUaqSEC6z8AsyKUwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFLx70aBBAemhzBI57NTsD3NPEAwvMA0GCSqGSIb3DQEBAQUABIIBAKUTHkct
# mNxePEDHWOdPAFKIKgrwyNxK07l7nTkLUVzdfXGMIONHuFej4g4ECor2xyRz4smB
# hb2XB8cnKHoyHjJ9uXSS1ikQsfEZsIxqlEPQDUc33xJppvaNgV4sAy/QiJQbs6wn
# rNyZ0wkMSaQH83PK8fOEkT5eFC2RtMBKc4A5UMT/8UUXXghMqjwnkItlAZFy0XkP
# ETAHlnl6RxganC7HTufUTmm/93jNs0u1kdiamJp7Qn7qQkjziMWsJPIOSvWrviQg
# 2W0MzfBvI9rel4QxVlSUZ46ynHjbKQrrydQEwFIBfx2iE0ajJEMw4gbPeQ+z5YL7
# /SrKIw194LJHfYs=
# SIG # End signature block
