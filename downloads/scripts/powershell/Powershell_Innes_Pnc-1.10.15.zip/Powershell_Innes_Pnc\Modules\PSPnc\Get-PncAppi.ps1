Function Get-PncAppi {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve all installed APPIs
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve all installed APPIs
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS 
The powershell object that describes all installed APPIs.
Example of object formated in JSON :
{
    "urn:innes:system-app#playzilla":  {
        "nbValidTokens":  0,
        "versions":  {
            "4.10.19":  {
                ...
            }
            ...
        }
         "domains":  {
            "domain1":  {
                "nbValidTokens":  0
            }
          },
        "hiddenDomains":  false,
        "id":  "urn:innes:system-app#playzilla",
        "hiddenLicenses":  false,
        "licenses":  {
             "PSN00690-00000 CD5":  {
                 "label":  "playzilla",
                 "valid":  false,
                  "license":  "xxxx - xxxx - xxxx - xxxx - xxxxx",
                 "domain":  "domain1",
                 "hiddenDomain":  false
             },
              ...
           }
        }
    }
    ...
}
.EXAMPLE
Get-PncAppi -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve appis for server `"$server`"")

 

$Body = @{
    target = "nsIAppliAppis.list"
}
$JsonBody = $Body | ConvertTo-Json
Start-Sleep -m $SleepDurationBeforeCommand

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}

$AppisObject = $ExecutedRequest | ConvertFrom-Json
# Filter null domain 
foreach ($prop in $AppisObject.PsObject.Properties)
{
    $appi = $prop.Value
    foreach ($prop in $appi.licenses.PsObject.Properties) {
        $license = $prop.Value
        if (!$license.domain)
        {
            $license.domain = ""
        }
    }
}
LogWrite($AppisObject | ConvertTo-Json -Depth 5)
$AppisObject
}




# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUIiiX8DwETwwsbm5sSXBsQQ8r
# bxagggP3MIID8zCCAtugAwIBAgIQYK2st87i8aBDVwTitTprgDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDUyODA5MjE1MFoXDTIyMDUyODA5NDE1MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOb1sssQ
# lSVDEd8Hb7b+yaSK7BVpdMsmzFLFJWRREMremRbWgXu/iesTlYIrqbQi8Ksh59p7
# mgwuuPXd9VIp9becSUhPeGQNcuPnX7O14bwwCGqMOcYd0kTss8X3n0DH7qoAvYad
# x7p8Xg7K5VWFiMraPQ/KRUUveMeAC/QCzEycIhmnXdJd5PzWD9dbJCIA/R4XqYxU
# h6n7qVBPNQsMcZaWqgadZ4wS6VQzCoFwouv08y2rCtOVjEhKIFTANsVcrJcIHGJW
# WW8xcvzg/n8FK5FJLh+8j10YhnUtfjhUFKEmh5J35BfcmUzWij+txUE0hLbE7oza
# pJZeg68+KNYbFcECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQjRoMLTw54homDATo3XJ1VfOTT2zANBgkqhkiG9w0BAQsFAAOCAQEAB6Pu
# /I/V+LfrYQ+Je3iCyYY1KcCTS7mebw46JiFKjQRAOEx2AWELHXdUIrWZpYc4uA6i
# +xQDO4RjOrjiYw29OPZzkHh4ly6AcloSnyExMGpfa256zUrQbJiq+rrIXCN8u1hg
# xoT4erR3a4/cs7JgaIuHsB458fJtgDiFv9Wvu4jtQdTC7WExoxkoXyBoPrX45rsS
# ZNjqpp7+E2dvpAZwa+54gbO543pRHBn2cKZojygBqIPIOzoFR9vWToAnemddHqpV
# JKMGeEMIVr+NkOKh7SPZ1I3B3kKsOkhXqYIq182yhOI7+oM+Ei08sSusYzh4pz9o
# 7hUl10EPnDiYmPAkXzGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEGCtrLfO4vGgQ1cE4rU6a4AwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFAyJVihZ0KTsIfU7ZF2Iz+PTlhIqMA0GCSqGSIb3DQEBAQUABIIBAIYSjVAu
# xNCpJUI9NEZSMJhmLXaymAY3TX1Txtp0fX/kb+E/W87VrwRIBIUY3k8Zmpjl32wY
# zcsb3R+4NlKr8SFhB6BwaAoAAYSz0E3PcyHsr1k3sESDeXKkndiMUy+crIfqHcLD
# 7676J0KrE7o51Rzpu8rRFHTxOHpjWq5ClCb22xW9fU6pEu0a9WRmGYwcuOtibmvu
# OB5vtz3birN6Im/BWllt5XgERNGUre47zBHzFG372Px5WkBG6ZLUY+w+nzCNdrPN
# H+ckGcGUgo73zulMNfs4Z4WKCOYtcH18/hz1ceSFKN85qngCXVA6H2y4hjS+xU6A
# pt2BclbhUyt4Bps=
# SIG # End signature block
