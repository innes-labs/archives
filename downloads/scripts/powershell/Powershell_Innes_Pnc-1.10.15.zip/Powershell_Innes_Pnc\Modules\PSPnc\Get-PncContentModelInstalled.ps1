Function Get-PncContentModelInstalled {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the installed models
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the installed models
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER domainList
The list of domains involved in the installation. Use "all" for all domains (default)
.PARAMETER lang
The description language of the model ("en-US", "fr-FR", ...). "x-default" by default
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell array of installed models.
Example of object formated in JSON :
[
    {
        "domain":  "domain1"
        "models":  [
            {
               "title":  "title 1",
               "version":  "1.20.10",
               "format":  "16/9",
               "description":  "Description 1",
               "category":  "Category 1",
               "file":  "model1.mask.maff"
            }
        ],
    },
    {
        "domain":  "domain2"
        "models":  [
            {
                 "title":  "title 2",
                "version":  "1.10.12",
                 "format":  "16/9",
                 "description":  "Description 2",
                 "category":  "Category 2",
                 "file":  "model2.mask.maff"
             },
             ...
        ],
    }
]
.EXAMPLE
Get-PncContentModelInstalled -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
Retrieve all models installed
.EXAMPLE
Get-PncContentModelInstalled -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin -domainList domain1
Retrieve models installed on domain "domain1"
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [string[]] $domainList = "all",
    [string] $lang = "x-default",
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
$ServerUri = "https://$Server"

# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve models for server `"$server`"")

 
# List of domains
$configObject = Get-PncDomainsAndTargets $server -logFile "none" -UrlLogin $UrlLogin -UrlPassword $UrlPassword
function GetModels {
    param (
        [string] $domain
    )
    $Body = "<D:propfind xmlns:D=`"DAV:`" xmlns:ias=`"ns.innes.appli.server`"><D:prop><D:getcontenttype/></D:prop><D:prop><D:getcontentlength/></D:prop><D:prop><D:getlastmodified/></D:prop><D:prop><D:getetag/></D:prop><D:prop><D:id/></D:prop><D:prop><D:resourcetype/></D:prop><D:prop><D:owner/></D:prop><D:prop><D:current-user-privilege-set/></D:prop><D:prop><ias:hidden-resources/></D:prop></D:propfind>"
    $Headers = @{
        DEPTH = "1"
        "X-HTTP-METHOD-OVERRIDE" = "PROPFIND"
    }
    Start-Sleep -m $SleepDurationBeforeCommand
    $BaseUri = "/.plugncast/.domains/" + $domain
    try {
        $Uri = $ServerUri + $BaseUri + "/.domain-repository/.models/.medias/"
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'text/xml' -Uri $Uri   -Body $Body -Headers $Headers
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw $_.Exception
    }
    [xml]$result = [xml]$ExecutedRequest
    [System.Xml.XmlElement] $root = $result.get_DocumentElement()
    [System.Collections.ArrayList]$uris =@();
    foreach ($response in $root.ChildNodes) {
        foreach ($child in $response.ChildNodes) {
            $name = $child.ToString()
            $value = $child.InnerText
            if ($name -eq "href")
            {
                if ($value.EndsWith(".mask.maff") -or $value.EndsWith(".mask.uri"))
                {
                    $value = $value.Substring($BaseUri.Length+1);
                    $uris.Add($value) | Out-Null
                }
            }
        }
    }
    $Body = "declare namespace im = `"ns.innes.metadata`";im:getDescriptions(("
    for ($i = 0; $i -lt $uris.Count; $i++)
    {
        $Body += "`"" + $uris[$i] + "`""
        if ($i -ne $uris.Count -1)
        {
            $Body += ","
        }
    }
    $Body += "))"
    try {
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/xquery' -Uri $BaseServerUri".domains/"$domain"/.db/metadatadb"   -Body $Body
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw $_.Exception
    }
    $enc = [System.Text.Encoding]::UTF8
    $bytes = $enc.GetBytes($ExecutedRequest.Content)
    $content = $enc.GetString($bytes)
    [xml]$result = [xml]$content
    [System.Xml.XmlElement] $root = $result.get_DocumentElement()

    [PSCustomObject]$Namespace = @{rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
     xmp="http://ns.adobe.com/xap/1.0/"
     xmpMM="http://ns.adobe.com/xap/1.0/mm/"
      stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#"
      xmpGImg="http://ns.adobe.com/xap/1.0/g/img/"
      dc="http://purl.org/dc/elements/1.1/"
      Iptc4xmpExt="http://iptc.org/std/Iptc4xmpExt/2008-02-29/"
      im="ns.innes.metadata"
      xml="http://www.w3.org/XML/1998/namespace"
      xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/"}
    $ns = New-Object System.Xml.XmlNamespaceManager($result.NameTable)
    foreach ($key in $Namespace.keys) {
        $ns.AddNamespace($key, $Namespace[$key])
    }
    [System.Collections.ArrayList]$models =@()
    foreach ($child in $root.ChildNodes) {
        $file = $child.about
        $index = $file.LastIndexOf("/");
        $file = $file.Substring($index + 1);
        $category = ""
        $title = ""
        $description = ""
        $format = ""
        $version = ""
        $metadata = $child.EmbeddedMetadata
        if ($metadata) {
            $version = $metadata.VersionID
            $res = $metadata.SelectSingleNode("im:category//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
            if ($res) {
                $category = $res.InnerText
            }
            $res = $metadata.SelectSingleNode("dc:title//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
            if ($res) {
                $title = $res.InnerText
            }
            $res = $metadata.SelectSingleNode("dc:description//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
            if ($res) {
                $description = $res.InnerText
            }
            if ($metadata.videoDisplayAspectRatioCategory) {
                $format = $metadata.videoDisplayAspectRatioCategory
            }
        }
        $metadatas = @{
            file = $file
            version     = $version
            format      = $format
            category    = $category
            title       = $title
            description = $description
        }
        $models.Add($metadatas) | Out-Null
    }
    return ,$models
}
[System.Collections.ArrayList]$domainModels =@()
foreach ($domain in $configObject.domains) {
    if (($domainList -eq "all") -or ($domainList -contains $domain.Name)) {
        $models = GetModels $domain.Name
        if ($models.Count -ne 0)
        {
            [PSCustomObject]$obj = @{
                domain = $domain.Name
                models = $models
            }
            $domainModels.Add($obj) | Out-Null
        }
    }
}
LogWrite(,$domainModels | ConvertTo-Json -Depth 5)
,$domainModels
}






# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUDxkgk8oq4vHpW/Z//D/4mHqy
# eROgggP3MIID8zCCAtugAwIBAgIQYK2st87i8aBDVwTitTprgDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDUyODA5MjE1MFoXDTIyMDUyODA5NDE1MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOb1sssQ
# lSVDEd8Hb7b+yaSK7BVpdMsmzFLFJWRREMremRbWgXu/iesTlYIrqbQi8Ksh59p7
# mgwuuPXd9VIp9becSUhPeGQNcuPnX7O14bwwCGqMOcYd0kTss8X3n0DH7qoAvYad
# x7p8Xg7K5VWFiMraPQ/KRUUveMeAC/QCzEycIhmnXdJd5PzWD9dbJCIA/R4XqYxU
# h6n7qVBPNQsMcZaWqgadZ4wS6VQzCoFwouv08y2rCtOVjEhKIFTANsVcrJcIHGJW
# WW8xcvzg/n8FK5FJLh+8j10YhnUtfjhUFKEmh5J35BfcmUzWij+txUE0hLbE7oza
# pJZeg68+KNYbFcECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQjRoMLTw54homDATo3XJ1VfOTT2zANBgkqhkiG9w0BAQsFAAOCAQEAB6Pu
# /I/V+LfrYQ+Je3iCyYY1KcCTS7mebw46JiFKjQRAOEx2AWELHXdUIrWZpYc4uA6i
# +xQDO4RjOrjiYw29OPZzkHh4ly6AcloSnyExMGpfa256zUrQbJiq+rrIXCN8u1hg
# xoT4erR3a4/cs7JgaIuHsB458fJtgDiFv9Wvu4jtQdTC7WExoxkoXyBoPrX45rsS
# ZNjqpp7+E2dvpAZwa+54gbO543pRHBn2cKZojygBqIPIOzoFR9vWToAnemddHqpV
# JKMGeEMIVr+NkOKh7SPZ1I3B3kKsOkhXqYIq182yhOI7+oM+Ei08sSusYzh4pz9o
# 7hUl10EPnDiYmPAkXzGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEGCtrLfO4vGgQ1cE4rU6a4AwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFPCzO2F1WttbdD6BCMoAwfKU5eo/MA0GCSqGSIb3DQEBAQUABIIBAFlpC9dK
# aYbaqulfwh64pwGNyjUGIiiklOhC0oadqNK1N0lp7CRaaAFspaFObv0HKaH50Hgd
# VwTKSh0E+d0M9ETpDZ0W/YFy0jRlDOe3E/24cf+yUxPGqjfqYMLSW7stRGxvLPnk
# mVoRx+/5MzgMS80jXg+VdHggRtefqyTeDpsLddG5SLwKgAbNAztYJIiiJP+3KGlE
# X4HCXuFb+KJGOXxXtNHYOuTIxLOCOEecdW+PQDE+kkMNON7sy4+xxU9jJtb88HX/
# muJl0LOCMVx1ZvBWk5rb6ufa5vZBSj2A478/FuydjCzNHkSC3ptj8X2pH9NBd9vL
# dpZNx3FOuwB745M=
# SIG # End signature block
