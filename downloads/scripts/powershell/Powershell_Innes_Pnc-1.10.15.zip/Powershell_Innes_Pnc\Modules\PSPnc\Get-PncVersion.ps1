# Load utilities
Function Get-PncVersion {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve its version.
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve its version.
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The string version.
.EXAMPLE
Get-PncVersion -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()] 
param(

    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
        [string] $UrlPort,
        [string] $UrlLogin,
        [string] $UrlPassword,
    [string] $LogFile
)

$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"

$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve the Plugncast version for server `"$server`"")


$Body = @{
    target = "nsIPref.getCharPref"
    args = @("extensions.lastAppVersion")
}
$JsonBody = $Body | ConvertTo-Json

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}

$VersionObject = $ExecutedRequest | ConvertFrom-Json


LogWrite($VersionObject | ConvertTo-Json -Depth 5)
$VersionObject
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUpv9CupHDsFD3BFIb653dnTAG
# OvigggP3MIID8zCCAtugAwIBAgIQYK2st87i8aBDVwTitTprgDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDUyODA5MjE1MFoXDTIyMDUyODA5NDE1MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOb1sssQ
# lSVDEd8Hb7b+yaSK7BVpdMsmzFLFJWRREMremRbWgXu/iesTlYIrqbQi8Ksh59p7
# mgwuuPXd9VIp9becSUhPeGQNcuPnX7O14bwwCGqMOcYd0kTss8X3n0DH7qoAvYad
# x7p8Xg7K5VWFiMraPQ/KRUUveMeAC/QCzEycIhmnXdJd5PzWD9dbJCIA/R4XqYxU
# h6n7qVBPNQsMcZaWqgadZ4wS6VQzCoFwouv08y2rCtOVjEhKIFTANsVcrJcIHGJW
# WW8xcvzg/n8FK5FJLh+8j10YhnUtfjhUFKEmh5J35BfcmUzWij+txUE0hLbE7oza
# pJZeg68+KNYbFcECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQjRoMLTw54homDATo3XJ1VfOTT2zANBgkqhkiG9w0BAQsFAAOCAQEAB6Pu
# /I/V+LfrYQ+Je3iCyYY1KcCTS7mebw46JiFKjQRAOEx2AWELHXdUIrWZpYc4uA6i
# +xQDO4RjOrjiYw29OPZzkHh4ly6AcloSnyExMGpfa256zUrQbJiq+rrIXCN8u1hg
# xoT4erR3a4/cs7JgaIuHsB458fJtgDiFv9Wvu4jtQdTC7WExoxkoXyBoPrX45rsS
# ZNjqpp7+E2dvpAZwa+54gbO543pRHBn2cKZojygBqIPIOzoFR9vWToAnemddHqpV
# JKMGeEMIVr+NkOKh7SPZ1I3B3kKsOkhXqYIq182yhOI7+oM+Ei08sSusYzh4pz9o
# 7hUl10EPnDiYmPAkXzGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEGCtrLfO4vGgQ1cE4rU6a4AwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFACaOc4WrHSyB9GRDFlLBG9pXxJBMA0GCSqGSIb3DQEBAQUABIIBANZ5niil
# EtjcSyoz3lHXLjlyfkUTw957YjUcdsIb8ehze8cdDPaRQK41cVqB1xlQXePedrfj
# 7kJAoP33RNOU9qSMF05k6eBKGn07n8l7V2J8uFQ5h1e3B5aLUY99o8zjZsrZrUAk
# f/sCBIw7edChdIXndTyPTGzRgaYETqIo51JGHqXTsG9S5faBzPL1lkFtjfgIdZEk
# uA6kleBb59eI7tfUjF+NO5i2A87Le5/v1ur8/FvyxalouAeRcD7C0im0lmdNuHd6
# KV7F6oxtZGG+DVa8MAImZI5rorRHcI5fslAUWlosiAf8pdppjAyOgXSpS7wisA29
# u/6cR6VO01Mot58=
# SIG # End signature block
