# Load utilities
Function Get-PncInventory {
<# 
.SYNOPSIS
This function queries a array of Plugncast G3 server to create an inventory.
.DESCRIPTION
The function uses as input a array of objects associated with the servers to be queried. 
Each object must at least contain the property "ip" or "host" which gives the address (or domain) of the Plugncast server. 
It can also contain the properties:
- port that defines the HTTPS port of server,
- username that defines the authentication user,
- password that defines the authentication password.
Each object can contain other properties which are not used by the function and which are returned unchanged.

The output of the function is the input array to which the
following properties are added to each object:
- status: which is "OK" if the server answered, "KO" otherwise
- pncVersion: version of the Plugncast server,
- nbDomain: number of domains,
- domainNames: domain names separated by newlines,
- licenseMail : the mail used with license,
- nbLicenseDomain: number of valid licenses of domain,
- nbLicensePlayzillaValid: number of valid license of playzilla,
- nbLicensePlayzillaWithDomain: number of valid license of playzilla with domain,
- nbLicensePlayzillaWithoutDomain: number of valid license of playzilla without domain,
- nbLicensePlayzillaInvalid: number of invalid license of playzilla.
.PARAMETER servers
Array the objects associated with the servers to be queried. 
Each object of the array must contain the property "ip" or "host" and optionally the properties "port", "username" and password
.PARAMETER defaultAuthentication
True if the default super administrator user credentials should be used if the credentials are missing 
.PARAMETER logFile
The path of log file
.OUTPUTS
The input array completed with the retrieved information (see DESCRIPTION).
.EXAMPLE
PS C:>[System.Collections.ArrayList]$servers = @(
    [PSCustomObject]@{ip="192.168.1.45";port="8443";login="superadmin";password="superadmin";field1="Field1 value1";field2="Field2 value1"}
    [PSCustomObject]@{ip="192.168.1.10";port="443";login="superadmin";password="superadmin";field1="Field1 value2";field2="Field2 value2"}
)
PS C:>$result = Get-PncInventory -server $servers
PS C:>$result
ip                              : 192.168.1.45
port                            : 8443
login                           : superadmin
password                        : superadmin
field1                          : Field1 value1
field2                          : Field2 value1
status                          : OK
pncVersion                      : 3.12.10
nbDomain                        : 2
domainNames                     : toto
                                  odav.fr
licenseMail	                    : labs@innes.fr
psnCore                         : PSN00780-00449 CD6
psnDomain                       : -
                                  PSN00160-00319 CD4
nbLicenseDomain                 : 101
nbLicensePlayzillaValid         : 1500
nbLicensePlayzillaWithDomain    : 9
nbLicensePlayzillaWithoutDomain : 1491
nbLicensePlayzillaInvalid       : 13

ip                              : 192.168.1.10
port                            : 443
login                           : superadmin
password                        : superadmin
field1                          : Field1 value2
field2                          : Field2 value2
status                          : OK
pncVersion                      : 3.11.11
nbDomain                        : 3
domainNames                     : domain2
                                  domain1
                                  domain3
licenseMail                     : labs@innes.fr
psnCore                         : PSN00780-00449 CD6
psnDomain                       : -
                                  PSN00160-00319 CD4
                                  PSN00160-00391 CD0
nbLicenseDomain                 : 4
nbLicensePlayzillaValid         : 5
nbLicensePlayzillaWithDomain    : 4
nbLicensePlayzillaWithoutDomain : 1
nbLicensePlayzillaInvalid       : 1
.NOTES
VERSION:1.10.11
#>
    [CmdletBinding()] 
    param(

        [Parameter(Mandatory = $true)]
        [PSCustomObject[]] $servers,
        [boolean] $defaultAuthentication = $true,
        [string] $LogFile
    )
    $verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
    $date = Get-Date
    $ScriptName = $MyInvocation.MyCommand.Name
    LogWrite("$date - $ScriptName")
    foreach ($server in $servers) {
        $urlHost = $null
        $urlPort = $server.port;
        $urlLogin = $server.login;
        $urlPassword = $server.password;
        if (!$urlLogin -and $defaultAuthentication)
        {
            $urlLogin = "superadmin"
        }
        if (!$urlPassword -and $defaultAuthentication)
        {
            $urlPassword = "superadmin"
        }
        if ($server.ip) {
            $urlHost = $server.ip
        }
        elseif ($server.host) {
            $urlHost = $server.host
        }
        else {
            throw "object must defines 'ip' or 'host' property"
        }
        try {
            $server | Add-Member -MemberType NoteProperty -Name "status" -Value "KO" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "pncVersion" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "domainNames" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "licenseMail" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "psnCore" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "psnDomain" -Value "-" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicenseDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaValid" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaWithDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaWithoutDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaInvalid" -Value 0 | Out-Null
            # Version
            $result = Get-PncVersion -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $server.pncVersion = $result;
            # Domains
            $result = Get-PncDomainsAndTargets -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $server.nbDomain = $result.numberDomain
            $domainNames = ""
            foreach ($domain in $result.domains) {
                $domainNames += $domain.Name + "`n"
            }
            if ($domainNames) {
                $domainNames = $domainNames.substring(0, $domainNames.length - 1)
            }
            $server.domainNames = $domainNames
            # Domain licenses
            $result = Get-PncLicense -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $server.licenseMail = $result.mail
            $server.nbLicenseDomain = $result.licenses.numberDomains
			$server.psnCore = $result.psn
			if ( $server.nbLicenseDomain -gt 1) {
				foreach ($prop in $result.licenses.licenses.PsObject.Properties) {
					$server.psnDomain += "`n" + $prop.Value.psn
				}
			}
            # Playzilla
            $result = Get-PncAppi -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $playzilla = $result."urn:innes:system-app#playzilla"
            $server.nbLicensePlayzillaValid = $playzilla.nbValidTokens
            foreach ($prop in $playzilla.licenses.PsObject.Properties)
            {
                $license = $prop.Value
                if (!$license.valid) {
                    $server.nbLicensePlayzillaInvalid++;
                }
                elseif ($license.domain)
                {
                    $server.nbLicensePlayzillaWithDomain++

                }                    
                else {
                    $server.nbLicensePlayzillaWithoutDomain++
                }
            }
            $server.status = "OK"
        }
        catch {
            LogWrite("Error with server " + $urlHost);
            Write-Warning("Error with server " + $urlHost);
        }
    }
    $servers
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUHgGX8ls0FgefsGH31HSragpJ
# iBmgggP3MIID8zCCAtugAwIBAgIQYK2st87i8aBDVwTitTprgDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDUyODA5MjE1MFoXDTIyMDUyODA5NDE1MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOb1sssQ
# lSVDEd8Hb7b+yaSK7BVpdMsmzFLFJWRREMremRbWgXu/iesTlYIrqbQi8Ksh59p7
# mgwuuPXd9VIp9becSUhPeGQNcuPnX7O14bwwCGqMOcYd0kTss8X3n0DH7qoAvYad
# x7p8Xg7K5VWFiMraPQ/KRUUveMeAC/QCzEycIhmnXdJd5PzWD9dbJCIA/R4XqYxU
# h6n7qVBPNQsMcZaWqgadZ4wS6VQzCoFwouv08y2rCtOVjEhKIFTANsVcrJcIHGJW
# WW8xcvzg/n8FK5FJLh+8j10YhnUtfjhUFKEmh5J35BfcmUzWij+txUE0hLbE7oza
# pJZeg68+KNYbFcECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQjRoMLTw54homDATo3XJ1VfOTT2zANBgkqhkiG9w0BAQsFAAOCAQEAB6Pu
# /I/V+LfrYQ+Je3iCyYY1KcCTS7mebw46JiFKjQRAOEx2AWELHXdUIrWZpYc4uA6i
# +xQDO4RjOrjiYw29OPZzkHh4ly6AcloSnyExMGpfa256zUrQbJiq+rrIXCN8u1hg
# xoT4erR3a4/cs7JgaIuHsB458fJtgDiFv9Wvu4jtQdTC7WExoxkoXyBoPrX45rsS
# ZNjqpp7+E2dvpAZwa+54gbO543pRHBn2cKZojygBqIPIOzoFR9vWToAnemddHqpV
# JKMGeEMIVr+NkOKh7SPZ1I3B3kKsOkhXqYIq182yhOI7+oM+Ei08sSusYzh4pz9o
# 7hUl10EPnDiYmPAkXzGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEGCtrLfO4vGgQ1cE4rU6a4AwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFMHnE7Lf8G3gY0IBrP0oko+NPL3fMA0GCSqGSIb3DQEBAQUABIIBANRQpoWz
# 6kXsT40zOdn79hHAmFJyQo5pr7DxBvst9bfhy0+Zyl1EQ/ZE/0EcE4tzlUWVWRgG
# +63V2ce2vlr+8wDPcDs63XFZyswsHucU+hp7m5qbviCCZGa00gmPSkbL4QHOKsDy
# ljBAgBqgdU8S7pyWH0/VT+h52ge8o+rkCL/lsvz5Q//dhnQO6v0r6vdl6YDnGzjb
# 7yQ2shEnphLD+VAO7zgeM+2MAKYlNIG6QgjKDCOEilSq8AeniGToDxNYK/BbuDxO
# xuYCnWH5wqFxvuz63WXl/jK5Dr9J86/hcNt3259uXe1te7/QpJ/r3u6soQ5yS7wV
# mzw4ICOVOKk5uQk=
# SIG # End signature block
