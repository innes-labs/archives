Function Get-PncAppiDomainAssociation {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the domains of an APPI
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the domains of an APPI
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER appi
The name of appi (playzilla) or identificator of appi (urn:innes:system-app#playzilla)
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell object that describes the domains of the APPI
Example of object formated in JSON :
{
    "nbDomains":  1,
    "domains":  [
                    {
                        "name":  "domain1",
                        "version":  null,
                        "nbLicenses":  9,
                        "licenses":  [ ... ]
                    }
    ]
}
.EXAMPLE
Get-PncAppiDomainAssociation -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [Parameter(Mandatory=$true)]
    [string] $appi,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$urn = "urn:innes:system-app#"
if (!$appi.StartsWith($urn))
{
    $appi = $urn + $appi
}

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve domains of APPI `"$appi`" for server `"$server`"")

 

$Body = @{
    target = "nsIAppliAppis.get"
}
[System.Collections.ArrayList]$argsArray = @()
$argsArray.Add($appi) | Out-Null
$Body | Add-Member -MemberType NoteProperty -Name args -Value $argsArray | Out-Null
$JsonBody = $Body | ConvertTo-Json

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}
$appiObject = $ExecutedRequest | ConvertFrom-Json
$result = [PSCustomObject]@{
    nbDomains = 0
}
$unsetDomain = "@unset@"
$domainsLicensesMap = [PSCustomObject]@{}
foreach ($prop in $appiObject.licenses.PsObject.Properties)
{
    $psn = $prop.Name;
    $license = $prop.Value
    $domain = $license.domain
    $l = [PSCustomObject]@{
        psn = $psn
        label = $license.label
        valid = $license.valid
        license = $license.license
    }
    if ($license.valid) {
        $l  | Add-Member -MemberType NoteProperty -Name expired -Value $license.expired | Out-Null
    }
    if ($license.PSObject.Properties['expireDate'])
    {
        $l  | Add-Member -MemberType NoteProperty -Name expireDate -Value $license.expireDate | Out-Null
    }
    if (!$domain)
    {
        $domain = $unsetDomain
    }
    $d = $domainsLicensesMap.$domain
    if (!$d)
    {
        $d = [PSCustomObject]@{nbLicenses = 1}
        [System.Collections.ArrayList]$licenses = @()
        $licenses.Add($l) | Out-Null
        $d | Add-Member -MemberType NoteProperty -Name licenses -Value $licenses | Out-Null
        $domainsLicensesMap | Add-Member -MemberType NoteProperty -Name $domain -Value $d | Out-Null
    }
    else {
        $d.nbLicenses++
        $d.licenses.Add($l) | Out-Null
    }
}
$domainsVersionsMap = [PSCustomObject]@{}
foreach ($prop in $appiObject.versions.PsObject.Properties)
{
    $version = $prop.Name;
    $obj = $prop.Value
    foreach ($domain in $obj.domains) {
        $d = $domainsVersionsMap.$domain
        if (!$d) {
            $d = [PSCustomObject]@{}
            [System.Collections.ArrayList]$versions = @()
            $versions.Add($version) | Out-Null
            $d | Add-Member -MemberType NoteProperty -Name versions -Value $versions | Out-Null
            $domainsVersionsMap | Add-Member -MemberType NoteProperty -Name $domain -Value $d | Out-Null
        }
        else {
            $d.versions.Add($l) | Out-Null
        }
    }
}
[System.Collections.ArrayList]$domainArray = @()
foreach ($prop in $appiObject.domains.PsObject.Properties)
{
        $result.nbDomains += 1
        $name = $prop.Name
        $domain = $prop.Value
        $d = [PSCustomObject]@{
            name = $name
        }
        if ($domain.version)
        {
            $d | Add-Member -MemberType NoteProperty -Name version -Value $domain.version | Out-Null
        }
        if ($domainsLicensesMap.$name)
        {
            $d | Add-Member -MemberType NoteProperty -Name nbLicenses -Value $domainsLicensesMap.$name.nbLicenses | Out-Null
            $d | Add-Member -MemberType NoteProperty -Name licenses -Value $domainsLicensesMap.$name.licenses | Out-Null
        }
        else {
            $d | Add-Member -MemberType NoteProperty -Name nbLicenses -Value 0 | Out-Null
        }
        $domainArray.Add($d) | Out-Null
}
$result | Add-Member -MemberType NoteProperty -Name domains -Value $domainArray | Out-Null
if ($domainsLicensesMap.$unsetDomain)
{
    $result | Add-Member -MemberType NoteProperty -Name nbUnusedLicenses -Value $domainsLicensesMap.$unsetDomain.nbLicenses | Out-Null
    $result | Add-Member -MemberType NoteProperty -Name unusedLicenses -Value $domainsLicensesMap.$unsetDomain.licenses | Out-Null
}
else {
    $result | Add-Member -MemberType NoteProperty -Name nbUnusedLicenses -Value 0 | Out-Null
}
LogWrite($result | ConvertTo-Json -Depth 5)
$result 
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUiaZxi5RTp4ofdHJAOa7kvMw9
# 5ImgggP3MIID8zCCAtugAwIBAgIQYK2st87i8aBDVwTitTprgDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDUyODA5MjE1MFoXDTIyMDUyODA5NDE1MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOb1sssQ
# lSVDEd8Hb7b+yaSK7BVpdMsmzFLFJWRREMremRbWgXu/iesTlYIrqbQi8Ksh59p7
# mgwuuPXd9VIp9becSUhPeGQNcuPnX7O14bwwCGqMOcYd0kTss8X3n0DH7qoAvYad
# x7p8Xg7K5VWFiMraPQ/KRUUveMeAC/QCzEycIhmnXdJd5PzWD9dbJCIA/R4XqYxU
# h6n7qVBPNQsMcZaWqgadZ4wS6VQzCoFwouv08y2rCtOVjEhKIFTANsVcrJcIHGJW
# WW8xcvzg/n8FK5FJLh+8j10YhnUtfjhUFKEmh5J35BfcmUzWij+txUE0hLbE7oza
# pJZeg68+KNYbFcECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQjRoMLTw54homDATo3XJ1VfOTT2zANBgkqhkiG9w0BAQsFAAOCAQEAB6Pu
# /I/V+LfrYQ+Je3iCyYY1KcCTS7mebw46JiFKjQRAOEx2AWELHXdUIrWZpYc4uA6i
# +xQDO4RjOrjiYw29OPZzkHh4ly6AcloSnyExMGpfa256zUrQbJiq+rrIXCN8u1hg
# xoT4erR3a4/cs7JgaIuHsB458fJtgDiFv9Wvu4jtQdTC7WExoxkoXyBoPrX45rsS
# ZNjqpp7+E2dvpAZwa+54gbO543pRHBn2cKZojygBqIPIOzoFR9vWToAnemddHqpV
# JKMGeEMIVr+NkOKh7SPZ1I3B3kKsOkhXqYIq182yhOI7+oM+Ei08sSusYzh4pz9o
# 7hUl10EPnDiYmPAkXzGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEGCtrLfO4vGgQ1cE4rU6a4AwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFL85uSkNocoe31EdHQRd+23SECtwMA0GCSqGSIb3DQEBAQUABIIBAONh9CZ1
# BRi/Uh1b0HjjnWsOTuIzxzq1lIiEFewtEYLXAsJEUUx4HwNhZcAA70cGCeWivq5F
# dgTnSxLv1qvT3PqVBXIRL1qGEDvqYy+IDHrd/wDUKbZzHnFsfezXSx2nZi87PrCu
# tGHxhj06Zz5QZBlrCsun7EiBTB7w6uMTUy8Pkaa0JXuKRWRbOQnLK40f9XGsDyen
# pisVhZ9payzGg35wsyeioV7oxGpJ3SFRAMSyIzV3kd57nK4eMXgKFgcneumF33yf
# cGQak65jWJU2BJSezJMSoXKuXtNE+HBGHuv6py+tsXPJ0AopoWsK64Ud2xiouf9c
# /+ZaWiE66Wct5yU=
# SIG # End signature block
