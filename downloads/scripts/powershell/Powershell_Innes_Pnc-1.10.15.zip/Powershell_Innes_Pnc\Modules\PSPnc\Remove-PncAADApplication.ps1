Function Remove-PncAADApplication {
<# 
.SYNOPSIS
This function remove the Azure AD application for Plugncast  
.DESCRIPTION
This function remove the Azure AD application for Plugncast  
.PARAMETER Credential
The credential of the Azure AD user used to remove the application. if absent, a dialog is displayed to connect to Azure AD 
.PARAMETER tenantId
The Active Directory Tenant. This is a GUID which represents the "Directory ID" of the AzureAD tenant
into which you want to create the apps. Look it up in the Azure portal in the "Properties" of the Azure AD
.PARAMETER appName
The name of the application 

.OUTPUTS
Nothing
 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $false)]
    [string] $appName = "Plugncast"
)

$date = Get-Date
LogWrite("$date : delete AAD application with name `"$appName`"")

Remove-AADApplication -credential $Credential -tenantId $tenantId -appName $appName 
LogWrite("Application removed")

}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU8z19sMnXQixZkx6s+xSAvl+Y
# wJ6gggP3MIID8zCCAtugAwIBAgIQYK2st87i8aBDVwTitTprgDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDUyODA5MjE1MFoXDTIyMDUyODA5NDE1MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOb1sssQ
# lSVDEd8Hb7b+yaSK7BVpdMsmzFLFJWRREMremRbWgXu/iesTlYIrqbQi8Ksh59p7
# mgwuuPXd9VIp9becSUhPeGQNcuPnX7O14bwwCGqMOcYd0kTss8X3n0DH7qoAvYad
# x7p8Xg7K5VWFiMraPQ/KRUUveMeAC/QCzEycIhmnXdJd5PzWD9dbJCIA/R4XqYxU
# h6n7qVBPNQsMcZaWqgadZ4wS6VQzCoFwouv08y2rCtOVjEhKIFTANsVcrJcIHGJW
# WW8xcvzg/n8FK5FJLh+8j10YhnUtfjhUFKEmh5J35BfcmUzWij+txUE0hLbE7oza
# pJZeg68+KNYbFcECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQjRoMLTw54homDATo3XJ1VfOTT2zANBgkqhkiG9w0BAQsFAAOCAQEAB6Pu
# /I/V+LfrYQ+Je3iCyYY1KcCTS7mebw46JiFKjQRAOEx2AWELHXdUIrWZpYc4uA6i
# +xQDO4RjOrjiYw29OPZzkHh4ly6AcloSnyExMGpfa256zUrQbJiq+rrIXCN8u1hg
# xoT4erR3a4/cs7JgaIuHsB458fJtgDiFv9Wvu4jtQdTC7WExoxkoXyBoPrX45rsS
# ZNjqpp7+E2dvpAZwa+54gbO543pRHBn2cKZojygBqIPIOzoFR9vWToAnemddHqpV
# JKMGeEMIVr+NkOKh7SPZ1I3B3kKsOkhXqYIq182yhOI7+oM+Ei08sSusYzh4pz9o
# 7hUl10EPnDiYmPAkXzGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEGCtrLfO4vGgQ1cE4rU6a4AwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFCCOjNSOnriE3/YhHXHhKE4B/MbIMA0GCSqGSIb3DQEBAQUABIIBAMpUi6mt
# E53PuqICALC+KIPATABY2ndkbYhJajyw4USivr5X1V7Ks8mEPLGo4J3ps4Pnhb6T
# 4G8OUVTK1zcMuS/VDtYSkUMjj+O4uiBU47cjeYYqNHXKlbowaK01MaPWEMJBIpFX
# ZoaUxZ48ZJg4P4St+eRFhebLyztSm/4LuUUb1JozNL65AXp3g6w5HbZ1hzsbRb0/
# oRdGdqe8u/wMMPxW73fg6AQNapj+QgDDstUTh9MXcFsH36ZunpSMM6BQXrCRZcN/
# Lo7WW2etViV3f34I/eBy1M9N77itOZeYXzw8DfQl8HRl5PXBE2sZICv2SInYvif4
# r/rbTQ52qyROqak=
# SIG # End signature block
