<#
.SYNOPSIS
   PlugnCast : .URI generator from MS-Excel
.DESCRIPTION
  Requires the installation of the PSExcel Powershell module:
  Launch a Powershell console with administrator user and type
   > Install-Module -Name PSExcel

  MS-Excel format : 
  id	name	scheme	address	    port	thumbnail
  1	    TF1	    udp://	225.1.1.1	1234	./assets/tf1.png
.PARAMETER excelFileList
The list of MS-Excel file path (absolute or relative) describing the .URI files to generate.
.PARAMETER outputDirectory
The directory containing the generated URI files (default "./output")
.EXAMPLE
New-UriFromExcel.ps1 channels.xlsx
#>
 
[CmdletBinding()]
Param
(
    [string[]] $excelFileList = "./channels.xlsx",
    [string] $outputDirectory = "./output"
)

Begin
{
    $verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
    Import-Module PSPnc   
    Import-Module PSExcel
    function Write-UriFile {
        param (
            [Parameter(Mandatory = $True, ValueFromPipeline = $true)]
            [Object[]] $in,

            [Parameter(Mandatory = $true)]
            [String] $filename
        ) 
        process {
                
            $_filename1 = $filename.Split([IO.Path]::GetInvalidFileNameChars()) -join '_'
            $_filename = "./output/" + $_filename1 + ".uri"
            add-content -path $_filename $in
        }
    }
    function New-UriFromExcelFile($path){
        $datas = Import-XLSX -RowStart 1  -Path $path
        foreach($data in $datas ){
            $uri =  "{0}{1}:{2}" -f $data.scheme, $data.address, $data.port
            $thumbnail = $data.thumbnail
            if ($thumbnail.Contains("/"))
            {
                $thumbnail = $thumbnail.Replace("/", "`\");
            }
            if ($thumbnail.StartsWith("."))
            {
                $thumbnail = [string] (Get-Location) + "\" + $thumbnail
            }
            $tokens= @{IMG= $img; CATEGORY= 'IPTV'; TITLE=$data.name ; URI=$uri}
            New-PncUri -uri $uri -thumbnail $thumbnail -title $data.name -category 'IPTV' -vb:$verbose `
               | Write-UriFile -filename $data.name 
        }
    }     
}


Process
{
    foreach($n in $excelFileList){
        $PSDefaultParameterValues['*:Encoding'] = 'utf8'
        if (Test-Path $outputDirectory) {
            Remove-Item -Path $outputDirectory/*.uri -Force
        }
        else {
            New-Item -ItemType Directory -Force -Path $outputDirectory
        }
        $path = (resolve-path $n).Path
        Write-Verbose "Converting $path"
        New-UriFromExcelFile -path $path
        Write-Verbose "End of Job"
    }
}
End
{
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUWebehhJ95GJXAMcODQDNQBSj
# WJugggP3MIID8zCCAtugAwIBAgIQYK2st87i8aBDVwTitTprgDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDUyODA5MjE1MFoXDTIyMDUyODA5NDE1MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOb1sssQ
# lSVDEd8Hb7b+yaSK7BVpdMsmzFLFJWRREMremRbWgXu/iesTlYIrqbQi8Ksh59p7
# mgwuuPXd9VIp9becSUhPeGQNcuPnX7O14bwwCGqMOcYd0kTss8X3n0DH7qoAvYad
# x7p8Xg7K5VWFiMraPQ/KRUUveMeAC/QCzEycIhmnXdJd5PzWD9dbJCIA/R4XqYxU
# h6n7qVBPNQsMcZaWqgadZ4wS6VQzCoFwouv08y2rCtOVjEhKIFTANsVcrJcIHGJW
# WW8xcvzg/n8FK5FJLh+8j10YhnUtfjhUFKEmh5J35BfcmUzWij+txUE0hLbE7oza
# pJZeg68+KNYbFcECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQjRoMLTw54homDATo3XJ1VfOTT2zANBgkqhkiG9w0BAQsFAAOCAQEAB6Pu
# /I/V+LfrYQ+Je3iCyYY1KcCTS7mebw46JiFKjQRAOEx2AWELHXdUIrWZpYc4uA6i
# +xQDO4RjOrjiYw29OPZzkHh4ly6AcloSnyExMGpfa256zUrQbJiq+rrIXCN8u1hg
# xoT4erR3a4/cs7JgaIuHsB458fJtgDiFv9Wvu4jtQdTC7WExoxkoXyBoPrX45rsS
# ZNjqpp7+E2dvpAZwa+54gbO543pRHBn2cKZojygBqIPIOzoFR9vWToAnemddHqpV
# JKMGeEMIVr+NkOKh7SPZ1I3B3kKsOkhXqYIq182yhOI7+oM+Ei08sSusYzh4pz9o
# 7hUl10EPnDiYmPAkXzGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEGCtrLfO4vGgQ1cE4rU6a4AwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFFFadnE8Fv1Y5SYuOiKb+T8VeUH5MA0GCSqGSIb3DQEBAQUABIIBANHwSlPh
# zzQ+hgmaI9mP7EdQvvSm5HtStdPCUEt8rSU+eKPhdkQa2E29c4jZiOyT7aZAbKWi
# 3ijl+cUKDKVL88VPC/cCcCU2ZRGBZr/nArsr0xfGvhZme5WfZ8tm0fS+LDBjyWzS
# 0wjNjbbqNb2ImeKEDXVa/A0ZoiG9gFZLLtfLl2/Ytj/wdf9GWXEdFeCHs9CXzOu6
# 2G0mSM0jIFTZXyWVJC5PsuJbHPVcSklk8acEVn/aEZ1oTmAdg1BJd3rZM2gpj7MQ
# 319sgY5DDd9xzR13qweaandtL7iBGvI/JrXtc3lS5XY+rHiCBVc4KNLZlDmxMMrG
# CodYIWVb3VRXA3g=
# SIG # End signature block
