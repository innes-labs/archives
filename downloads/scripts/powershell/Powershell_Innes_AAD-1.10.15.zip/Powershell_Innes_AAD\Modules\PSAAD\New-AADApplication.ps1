Function New-AADApplication {
<# 
.SYNOPSIS
This function creates a Azure Active Directory application.  
.DESCRIPTION
This function creates a Azure Active Directory application.  
.PARAMETER Credential
Credential (admin profile) used to create the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been created. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
Name of the Azure Active Directory application.
.PARAMETER authorizations
Authorization type:
-  "signcom_m365" : to access to OneDrive and Web sites for SignCom application
- "signmeeting_ews": to access to MS-Exchange room mailbox resources for SignMeeting MS-Exchange application
- "signmeeting_m365": to access to M365 room mailbox resources for SignMeeting-M365 application
- "briva_calendar_ews": to access to MS-Exchange room mailbox resources for Briva Calendar EWS application
- "m365_room": to access to M365 room mailbox resource for SBL10e m365_room application
- "m365_user": to access to M365 user presence resource for SBL10e m365_user application
- "powerbi": to access to Power BI report
.PARAMETER logFile
Log file path
.OUTPUTS
The result is an object that is describing the created Azure Active Directory application. 
It contains the following properties:
- name : Azure Active directory application name
- tenantId : Azure Active directory's tenant id
- clientId : Azure Active directory's application (client) Id
- objectId : Azure Active directory's application object id
- clientSecret: Azure Active directory's client secret
- spId : Azure Active directory's application service principal id
These object properties are flushed automatically in the "<appName>.json" file in the current directory.
.EXAMPLE
PS C:\>$result = New-AADApplication -appname "SignMeeting"  -authorizations "signmeeting_ews"
A consent request will be sent in 30 seconds in your browser.
You must log into an administrator account of your organization and grant the necessary permissions.
PS C:\>$result
Name                           Value
----                           -----
clientId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
objectId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
spId                           xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
name                           SignMeeting
tenantId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
clientSecret                   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
.NOTES 
 VERSION:1.10.10
#>

   [CmdletBinding()] 
   param(
      [PSCredential] $Credential,
      [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
      [string] $tenantId,
      [Parameter(Mandatory = $true)]
      [string] $appName,
      [Parameter(Mandatory = $true)]
      [ValidateSet('signcom_m365','signmeeting_ews', 'signmeeting_m365', 'm365_room', 'm365_user', 'powerbi', 'briva_calendar_ews')]
      [string[]] $authorizations,
      [string] $LogFile,
      [bool] $multiTenants = $false
   )
   $date = Get-Date
   LogWrite("$date : create new AAD application with name `"$appName`"")
   try {
      $consentRedirectUri = "http://localhost:23456/consent/redirect"
      [String[]] $replyUrls = @($consentRedirectUri)
      $app = New-AADApplication-CommonsUtils  -credential $Credential -tenantId $tenantId -appName $appName `
         -replyUrls $replyUrls `
         -generatePassword $true -AvailableToOtherTenants $multiTenants
      $requiredResourcesAccess = New-Object System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.RequiredResourceAccess]
      for ($i = 0; $i -lt $authorizations.length; $i++)
      {
          $authorizations[$i] = ($authorizations[$i]).ToLower();
      }
      $hasDelegatedPermission = $false;
      if ($authorizations.Contains("signcom_m365")) {
         $permissions = "Files.Read.All|Sites.Read.All|User.Read"
         $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions $permissions -requiredApplicationPermissions $permissions
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("signmeeting_ews")) {
         $requiredPermissions = GetRequiredPermissions -appid "00000002-0000-0ff1-ce00-000000000000" `
            -requiredApplicationPermissions "full_access_as_app"
         $requiredResourcesAccess.Add($requiredPermissions)
         $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions "EWS.AccessAsUser.All|User.Read"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("briva_calendar_ews")) {
        $requiredPermissions = GetRequiredPermissions -appid "00000002-0000-0ff1-ce00-000000000000" `
           -requiredApplicationPermissions "full_access_as_app"
        $requiredResourcesAccess.Add($requiredPermissions)
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
           -requiredDelegatedPermissions "EWS.AccessAsUser.All|User.Read"
        $requiredResourcesAccess.Add($requiredPermissions)
        $hasDelegatedPermission = $true;
     }
      if ($authorizations.Contains("signmeeting_m365")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredApplicationPermissions "Place.Read.All|User.Read.All|Calendars.ReadWrite"
         $requiredResourcesAccess.Add($requiredPermissions)
      }
      if ($authorizations.Contains("m365_room")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredApplicationPermissions "Calendars.Read|User.Read.All"
         $requiredResourcesAccess.Add($requiredPermissions)
      }
      if ($authorizations.Contains("m365_user")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredDelegatedPermissions "Directory.AccessAsUser.All|Presence.Read.All"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("powerbi")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Power BI Service" `
        -requiredDelegatedPermissions "App.Read.All|Content.Create|Dataset.ReadWrite.All|Report.ReadWrite.All"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      Set-AzureADApplication -ObjectId $app.ObjectId -RequiredResourceAccess $requiredResourcesAccess
    #   $app.clientSecret = [System.Web.HttpUtility]::UrlEncode($app.clientSecret)
      Set-Content -Path ".\$appName.json" -Value ($app | ConvertTo-Json -Depth 5)
      $hasDelegatedPermission = $true
      if ($hasDelegatedPermission) 
      {
        Write-Host "A consent request will be sent in 50 seconds in your browser.`
        You must log into an administrator account of your organization and grant the necessary permissions."
        Start-Sleep 50
        $request = "https://login.microsoftonline.com/" + $app.tenantId + "/adminconsent" + `
        "?client_id=" + $app.ClientId + "&redirect_uri=" + $consentRedirectUri
        Start-Process $request
        Start-ConsentRedirectServer
      }
      Write-Host("Application created")
      $app
   }
   catch {
      LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
      throw $_.Exception
   }
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUBJYzEQW+Z5gNIfpNs38Me63G
# xf+gggP3MIID8zCCAtugAwIBAgIQU+aMBKUEyptN+HUd2J/3njANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MTIyNzE0MzMxMFoXDTIzMTIyNzE0NTMxMFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMFQ7fHX
# 7YvspoV/7c/FH0u8/teRt8SKYdTd3mv+MOv+8NSbKHtTr+4/MB+JVLwsBX3Kd4Vi
# +uza9wpwtEn3oYThrgMNCLuP3wNcSh/5Nu2CCOgmqYhgL0gXMYMPV1E7hGmjaC/z
# Zi0m5hruC8xq+OpynYsR3meuc6a5gqZ8oZtcwUpwtmf4uaA0pl3xOC5DGc+SROFR
# Arz69o2mXMxB0JOnf9JP8FScPeaAoyDYvKw/ZsiTP9tK+89lV4Dpk+NlqFzZOa1K
# GDbUcR8Ji85ENUC8Su/6Ox8u80AcwD/lu3xX4kmSiqR/ik3xV8y0nQiu+K2soDzL
# AWktRgOt1xUJ/tUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTwYNb1GiJFbW5XeM06wu6JTXweHzANBgkqhkiG9w0BAQsFAAOCAQEAILtQ
# rK0LUB57tFNS5q/LAaiC/EFgXOSAjrF3rF+BG2Vfz0Mr63Iy4TeF9rOAplZv6adb
# 8RtVkuVZn8dxK3B7Uh4kaDAZaNNk8qLNugQDenxlEh0I1ZMFhEiUVLFHnzcFweyC
# Kn3SzKM3YqbHB6gc4DHDUMRKAvhnX6QhyWg5V2+gJO52bz3jy4DDN++Zd4a4wiMJ
# MFZPf1rgqsXXK8k1nw41zCU1CMt7XPJLcNiPpigXKBh08p0Eob3LFSmdB1M9Dz+w
# IGU3+eJRCtcpCYMzJPISGaO3TBNDiO9y1vp5urj47LLFpkdbb7jMTilvVGJPLueH
# nINidBGAXG9rbK2MgDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFPmjASlBMqbTfh1Hdif954wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFNJSgFy6pHhRCv6R6BcOD7Fv9STbMA0GCSqGSIb3DQEBAQUABIIBALw/KIEf
# opxr98eeXj90c2mPa82KNAPLC58NkEWMuA8x8fOQ81tuJq0w1dHER1D2viy9DZvC
# CeNAXqvGDKlnMbb78zgmRJVYSUevbzC9JLyl9LPz2u/IIOrnImZcn4hYST6YIocz
# xwAgB+ZoFy6eEixGp+Op+/P4y2wMXpZBQTIqQq4fyG1rYBNi9eoNRpOI/tD9c+Tk
# cbyIp/3XCqDvWYtzaPlkKCyxMVzlDNevbCVhN3aP0sWSxhZdnDh6b4sUk5MNHe5f
# dOdP/DSS/96sdpWbrf56dUWrvPAR65HFilG0o0F0TP0GYvmvWz7awuNWSYZOol2/
# 1floOOEqZpMlzbs=
# SIG # End signature block
