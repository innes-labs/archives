Function Remove-AADApplication {
<# 
.SYNOPSIS
This function removes a Azure Active Directory application.  
.DESCRIPTION
This function removes a Azure Active Directory application.  
.PARAMETER Credential
Exchange credential (admin profile) used to remove the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the Exchange credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been removed. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
The name of the Azure Active Directory application.
.OUTPUTS
Nothing
.EXAMPLE
PS C:\>Remove-AADApplication -appname "SignMeeting"
 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName
)

$date = Get-Date
LogWrite("$date : delete AAD application with name `"$appName`"")

Remove-AADApplication-CommonsUtils -credential $Credential -tenantId $tenantId -appName $appName 
LogWrite("Application removed")

}
# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUGNKiDNmaEp5ARUC1u5SFjcqj
# JBagggP3MIID8zCCAtugAwIBAgIQU+aMBKUEyptN+HUd2J/3njANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MTIyNzE0MzMxMFoXDTIzMTIyNzE0NTMxMFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMFQ7fHX
# 7YvspoV/7c/FH0u8/teRt8SKYdTd3mv+MOv+8NSbKHtTr+4/MB+JVLwsBX3Kd4Vi
# +uza9wpwtEn3oYThrgMNCLuP3wNcSh/5Nu2CCOgmqYhgL0gXMYMPV1E7hGmjaC/z
# Zi0m5hruC8xq+OpynYsR3meuc6a5gqZ8oZtcwUpwtmf4uaA0pl3xOC5DGc+SROFR
# Arz69o2mXMxB0JOnf9JP8FScPeaAoyDYvKw/ZsiTP9tK+89lV4Dpk+NlqFzZOa1K
# GDbUcR8Ji85ENUC8Su/6Ox8u80AcwD/lu3xX4kmSiqR/ik3xV8y0nQiu+K2soDzL
# AWktRgOt1xUJ/tUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTwYNb1GiJFbW5XeM06wu6JTXweHzANBgkqhkiG9w0BAQsFAAOCAQEAILtQ
# rK0LUB57tFNS5q/LAaiC/EFgXOSAjrF3rF+BG2Vfz0Mr63Iy4TeF9rOAplZv6adb
# 8RtVkuVZn8dxK3B7Uh4kaDAZaNNk8qLNugQDenxlEh0I1ZMFhEiUVLFHnzcFweyC
# Kn3SzKM3YqbHB6gc4DHDUMRKAvhnX6QhyWg5V2+gJO52bz3jy4DDN++Zd4a4wiMJ
# MFZPf1rgqsXXK8k1nw41zCU1CMt7XPJLcNiPpigXKBh08p0Eob3LFSmdB1M9Dz+w
# IGU3+eJRCtcpCYMzJPISGaO3TBNDiO9y1vp5urj47LLFpkdbb7jMTilvVGJPLueH
# nINidBGAXG9rbK2MgDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFPmjASlBMqbTfh1Hdif954wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFLx70aBBAemhzBI57NTsD3NPEAwvMA0GCSqGSIb3DQEBAQUABIIBADf2tcHo
# Iesf5JnKrwDOPRubu0uiT7s9+lpHsnrsdCVV5qygbSVNB0MZsgnpoGMZD3C3kC8E
# Cf46qylfQAwGUHixpmUyaVjbctLJWwT8vdnXK9UpIcEFsCeW+62pfabx+yMRewOD
# edLeU+nRrG/gvyiBDLll1Kl2dy1Km1HvEI3JXrYqU/DiqArczYWUc0o+7uwNpW8Q
# 15UdgEO1S0+YIFTWIOSdMZjFOqqiY7aMohiRsWKS/O/ms4jyi5aXtR2mFJedm6kh
# x9D6eSyQKOCzTLwUmUJ4Wt9l1Q+U2aBRePTXNTpI/Btkhtr+Kj/gteuAq+U4dFqb
# jxq4QDJkYdl1OGc=
# SIG # End signature block
