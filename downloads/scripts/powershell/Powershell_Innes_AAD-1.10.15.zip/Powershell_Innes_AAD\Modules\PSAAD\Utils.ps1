# Powershell utilities  
# 
#
# VERSION 1.10.10
#
if ($UtilsLoaded)
{
    return
}
$UtilsLoaded = 1

if ($LogFile -eq "none")
{
    $LogFile = $null
}

# Accept all certificates for http connection.
add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[Net.ServicePointManager]::SecurityProtocol = "tls12, tls11, tls"
Function LogWrite {
    Param ([string]$logstring)
    if ($LogFile -eq "none") {
        return
    }
    if ($verbose) {
        Write-Host $logstring
    }
    Write-Verbose $logstring
    if ($LogFile)
    {
        Add-content -Encoding UTF8 $LogFile -value $logstring
    }
}

Function LogArray{
    Param([System.Collections.ArrayList] $array)
    foreach ($str in $array)
    {
        LogWrite $str
    }
}
Function ArrayToString{
    Param([System.Collections.ArrayList] $array)
    $result = ""
    foreach ($str in $array)
    {
        $result += $str + "`r`n"
    }
    return $result
}

function InitCredential {
    $credential=@{ 
        basicAuthValue = ""
        certificate = ""
    }
    if ($urlLogin -and $urlPassword) {
        $pair = "$($urlLogin):$($urlPassword)"
        $encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($pair))
        $credential.basicAuthValue = "Basic $encodedCreds"
    }
    elseif (!$doNotGetCertificate) {
        # Get stored certificate
        try {
            $credential.certificate = Get-PncCertificate
        }
        catch { 
            LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
            LogWrite($_.Exception.InnerException.Message)
            throw $_.Exception
        }
    }
    return $credential
}
function MakeRequest {
    Param (
        [string]$Method,
        [string]$ContentType,
        [string]$Uri,
        [string]$Body,
        [string]$Infile,
        $Headers = @{}
    )
    try {
        $Cmd="Invoke-WebRequest -UseBasicParsing -Method `$method -Content `$ContentType -Uri `$Uri"
        $newHeaders = $Headers
        $credential = InitCredential
        if ($credential.certificate) {
            $Cmd += " -Certificate `$credential.certificate -Headers `$Headers"
        } elseif ($credential.basicAuthValue) {
            if ($Headers) {
                $newHeaders.Add("Authorization", $credential.basicAuthValue) | Out-Null
            } else {
                $newHeaders = @{Authorization = $credential.basicAuthValue}
            }
            $Cmd += " -Headers `$newHeaders"
        }
        else {
            throw "no authentication"
        }
        if ($Body) {
            $Cmd += " -Body `$Body"
        } elseif ($Infile) {
            $Cmd += " -InFile `$Infile"
        }
        $ExecutedRequest = Invoke-Expression $Cmd
        return $ExecutedRequest
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        LogWrite($_.Exception.InnerException.Message)
        throw $_.Exception
    }
}
Function Parsedate {
    Param ([string]$stringdate)
    $string = $stringDate
    $index = $string.IndexOf('T');
    if ($index -gt 0)
    {
        $string = $string.Substring(0, $index);
    }
    $date = $null;
    try{
        $date=[DateTime]::ParseExact($string, "yyyy-M-d", $null)
        return $date
    }
    catch{}
    try {
        $date=[DateTime]::ParseExact($string, "yyyy-M-dd", $null)
        return $date
    }
    catch { }
    try {
        $date=[DateTime]::ParseExact($string, "yyyy-MM-dd", $null)
        return $date
    }
    catch {}
    try {
        $date=[DateTime]::ParseExact($string, "yyyy-MM-d", $null)
        return $date
    }
    catch { }
    try {
        $date=[DateTime]::ParseExact($string, "yyyy-MM", $null)
        return $date
    }
    catch { }
    try {
        $date=[DateTime]::ParseExact($string, "yyyy-M", $null)
        return $date
    }
    catch { }
    throw "Can't parse date `"$string`""
}
function WriteXml ([xml]$xml)
{
    $StringWriter = New-Object System.IO.StringWriter;
    $XmlWriter = New-Object System.Xml.XmlTextWriter $StringWriter;
    $XmlWriter.Formatting = "indented";
    $xml.WriteTo($XmlWriter);
    $XmlWriter.Flush();
    $StringWriter.Flush();
    return $StringWriter.ToString();
}
Function ServerGetLicense {
    Param ([string]$psn)
    $Body = @{
        target = "nsIAppliLicenses.list"
    }
    $JsonBody = $Body | ConvertTo-Json
    try {
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    $LicensesObject = $ExecutedRequest | ConvertFrom-Json
    $license = $LicensesObject.licenses.$psn
    return $license
}
Function ServerSearchLicenses {
    Param ([string]$psn, [string]$psnPrefix, [string]$expired)
    $Body = @{
        target = "nsIAppliLicenses.list"
    }
    $JsonBody = $Body | ConvertTo-Json
    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    $LicensesObject = $ExecutedRequest | ConvertFrom-Json
    [System.Collections.ArrayList]$licenseArray = @()
    $license = $LicensesObject.licenses.$psn
    if ($psn -and $license)
    {
        $licenseArray.Add($license) | Out-Null
    }
    if ($psnPrefix -or ($expired -eq 1))
    {
        foreach ($prop in $LicensesObject.licenses.PsObject.Properties)
        {
            $license = $prop.Value
            if (($license.expired -eq 1 ) -or ($psnPrefix -and ($license.psn.StartsWith($psnPrefix) -eq 1)))
            {
                $licenseArray.Add($license) | Out-Null
            }
        }
    }
    return $licenseArray
}
# Retrieve the core PSN of licenses
Function GetCorePsn() {
    $Body = @{
        target = "nsIAppliLicenses.psn"
    }
    $JsonBody = $Body | ConvertTo-Json
    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    $corePsn = $ExecutedRequest | ConvertFrom-Json
    return $corePsn
}
Function AppiGetLicense {
    Param ([string]$appi, [string]$psn)
    $Body = @{
        target = "nsIAppliAppis.get"
    }
    [System.Collections.ArrayList]$argsArray = @()
    $argsArray.Add($appi) | Out-Null
    $Body | Add-Member -MemberType NoteProperty -Name args -Value $argsArray | Out-Null
    $JsonBody = $Body | ConvertTo-Json

    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    $appiObject = $ExecutedRequest | ConvertFrom-Json
    $license = $appiObject.licenses.$psn
    return $license
}
Function AppiGet {
    Param ([string]$appi)
    $Body = @{
        target = "nsIAppliAppis.get"
        args = @($appi)
    }
    $JsonBody = $Body | ConvertTo-Json
    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    $appiObject = $ExecutedRequest | ConvertFrom-Json
    return $appiObject
}

Function AppiSearchLicenses {
    Param ([string]$appi,[string]$psn, [string]$psnPrefix, [string]$expired)
    $Body = @{
        target = "nsIAppliAppis.get"
    }
    [System.Collections.ArrayList]$argsArray = @()
    $argsArray.Add($appi) | Out-Null
    $Body | Add-Member -MemberType NoteProperty -Name args -Value $argsArray | Out-Null
    $JsonBody = $Body | ConvertTo-Json

    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    $appiObject = $ExecutedRequest | ConvertFrom-Json
    [System.Collections.ArrayList]$psnArray = @()
    $license = $appiObject.licenses.$psn
    if ($psn -and $license)
    {
        $psnArray.Add($psn) | Out-Null

    }
    if ($psnPrefix -or ($expired -eq 1))
    {
        foreach ($prop in $appiObject.licenses.PsObject.Properties)
        {
            $psn = $prop.Name
            $license = $prop.Value
            if (($license.expired -eq 1 ) -or ($psn.StartsWith($psnPrefix) -eq 1))
            {
                $psnArray.Add($psn) | Out-Null
            }
        }
    }
    return ,$psnArray
}
function Lock()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [int] $timeout = 60,
        [string] $type = "upload"

    )
    $Headers = @{
        Depth="0"
        Timeout= "Second-" + $timeout
        "X-HTTP-METHOD-OVERRIDE"= "LOCK"
    }
    $provider="Indus Tools 10.10.0 indus@innes.fr"
    $uri = $baseUri + $uri
    $Body = "<D:lockinfo xmlns:D=`"DAV:`"><D:locktype><D:" +
     $type + "/></D:locktype><D:lockscope><D:exclusive/></D:lockscope><D:owner><D:href>" + 
     $provider + "</D:href></D:owner></D:lockinfo>"
    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'text/xml' -Uri $uri   -Body $Body -Headers $Headers
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
    [xml]$result = [xml]$ExecutedRequest
    [System.Xml.XmlElement] $root = $result.get_DocumentElement()
    $token = $root.lockdiscovery.activelock.locktoken
    return $token.InnerText
    
}
function LockUpload()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [int] $timeout = 60
    )
    return Lock $baseUri $relUri $timeout "upload"
}
function LockWrite()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [int] $timeout = 60
    )
    return Lock $baseUri $relUri $timeout "write"
}
function LockTransaction()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [int] $timeout = 60
    )
    return Lock $baseUri $relUri $timeout "transaction"
}
function Unlock()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [string] $token
    )
    $Headers = @{
        "Lock-Token"="<" + $token + ">"
        "X-HTTP-METHOD-OVERRIDE"= "UNLOCK"
    }
    $uri = $baseUri + $uri
    try {
        $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'text/xml' -Uri $uri   -Headers $Headers
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
}
function PutFileWithToken()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [string] $token,
        [string] $filePath,
        [bool] $archive = 0
    )
    $Headers = @{
        IF="<" + $uri + ">(<" + $token + ">)"
        Overwrite="T"
        "X-HTTP-METHOD-OVERRIDE"= "PUT"
    }
    if ($archive -eq $True)
    {
        $Headers.Add("X-UNARCHIVE", "1")
    }
    $uri = $baseUri + $uri
    try {
            $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/octet-stream' -Uri $uri -Infile $filePath -Headers $Headers
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
}
function PutWithToken()
{
    param (
        [string] $baseUri,
        [string] $relUri,
        [string] $token,
        [string] $body,
        [bool] $archive = 0
    )
    $Headers = @{
        IF="<" + $uri + ">(<" + $token + ">)"
        Overwrite="T"
        "X-HTTP-METHOD-OVERRIDE"= "PUT"
    }
    if ($archive -eq $True)
    {
        $Headers.Add("X-UNARCHIVE", "1")
    }
    $uri = $baseUri + $uri
    try {
            $ExecutedRequest = MakeRequest -Method 'POST' -ContentType 'application/octet-stream' -Uri $uri   -Body $body -Headers $Headers
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw "Exception during request"
    }
}
Function StringHash{
    param ([String] $String, $HashName = "MD5") 
    $StringBuilder = New-Object System.Text.StringBuilder
    [System.Security.Cryptography.HashAlgorithm]::Create($HashName).ComputeHash([System.Text.Encoding]::UTF8.GetBytes($String)) | % {
        [Void]$StringBuilder.Append($_.ToString("x2"))
    }
    return $StringBuilder.ToString()
}
Function GeneratePassword {
    param (
        $numberLowercase = 4,
        $numberUppercase = 3,
        $numberSpecial = 3
    )
    for ($i = 0; $i -lt $numberLowercase; $i++) {
        $min += Get-Random -InputObject a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z
    }
    for ($i = 0; $i -lt $numberUppercase; $i++) {
        $maj += Get-Random -InputObject A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z
    }
    $nombre = Get-Random -Minimum 10 -Maximum 99
    for ($i = 0; $i -lt $numberSpecial; $i++) {
        $caracspec += Get-Random -InputObject $, !, %, *, _, -, +, =, ?, [, ], :, "@", "&", "#", "|", "(", ")", "{", "}", ";", ",", "."
    }
    $password = $min+$caracspec+$maj+$nombre
    $length = $password.length
    for ( $i = 0 ; $i -lt $length ; $i++ ){
        $newpos = (( $i + (Get-Random -Maximum $length -Minimum 0 ))%$length)
        $tmp = $password[$i]
        $password = ($password.Remove($i,1)).Insert($i,$password[$newpos])
        $password = ($password.Remove($newpos,1)).Insert($newpos,$tmp)
    }
    return $password
}
function ArrayToHash($array)
{
    $hash = @{}
    foreach ($a in $array)
    {
        $hash.Add($a, $a) | Out-Null
    }
    return $hash
}
Function ReplaceInFile {
    Param ([string]$file, [string]$old, [string]$new)
    LogWrite("Replace: file = $file old=$old new=$new")
    If ((Test-Path "$file") -ne $True) {
        LogWrite( "Replace: file '" + $file + "' not found.")
    }
    else {
        If ($debug) {
            (Get-Content -path $file -Raw) -replace "$old","$new"
        }
        ((Get-Content -path $file -Raw) -replace "$old","$new") | Set-Content -Path $file
    }
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUsMAzzxIrvMSWDwTGLpDg5o5R
# 2GagggP3MIID8zCCAtugAwIBAgIQU+aMBKUEyptN+HUd2J/3njANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MTIyNzE0MzMxMFoXDTIzMTIyNzE0NTMxMFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMFQ7fHX
# 7YvspoV/7c/FH0u8/teRt8SKYdTd3mv+MOv+8NSbKHtTr+4/MB+JVLwsBX3Kd4Vi
# +uza9wpwtEn3oYThrgMNCLuP3wNcSh/5Nu2CCOgmqYhgL0gXMYMPV1E7hGmjaC/z
# Zi0m5hruC8xq+OpynYsR3meuc6a5gqZ8oZtcwUpwtmf4uaA0pl3xOC5DGc+SROFR
# Arz69o2mXMxB0JOnf9JP8FScPeaAoyDYvKw/ZsiTP9tK+89lV4Dpk+NlqFzZOa1K
# GDbUcR8Ji85ENUC8Su/6Ox8u80AcwD/lu3xX4kmSiqR/ik3xV8y0nQiu+K2soDzL
# AWktRgOt1xUJ/tUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTwYNb1GiJFbW5XeM06wu6JTXweHzANBgkqhkiG9w0BAQsFAAOCAQEAILtQ
# rK0LUB57tFNS5q/LAaiC/EFgXOSAjrF3rF+BG2Vfz0Mr63Iy4TeF9rOAplZv6adb
# 8RtVkuVZn8dxK3B7Uh4kaDAZaNNk8qLNugQDenxlEh0I1ZMFhEiUVLFHnzcFweyC
# Kn3SzKM3YqbHB6gc4DHDUMRKAvhnX6QhyWg5V2+gJO52bz3jy4DDN++Zd4a4wiMJ
# MFZPf1rgqsXXK8k1nw41zCU1CMt7XPJLcNiPpigXKBh08p0Eob3LFSmdB1M9Dz+w
# IGU3+eJRCtcpCYMzJPISGaO3TBNDiO9y1vp5urj47LLFpkdbb7jMTilvVGJPLueH
# nINidBGAXG9rbK2MgDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFPmjASlBMqbTfh1Hdif954wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFM0JJMaVPeBqZ6AYsg1EDZokFiBoMA0GCSqGSIb3DQEBAQUABIIBAIzoMTqL
# GE9CAbB7O9mBjrN53zxihvEIwtFvKJOgawAYp0TbB0APOImydroxwj3I8Xz+tFiU
# HoFQxdu/2CJXeGiY/7CdOb+U/kIpck2TLMYXN9E6YYuN/2oC78VFyrJ89LM7X3D+
# 4zka4uG1T3McguQA713UEGZzjLpvpk7cmXbiyS0uFy0f0jUydoDSVc6BFoHHGjDO
# 0mJNbm0hYdgqgfaWuAkcpE05gjqKUC1sgixV1qzVU3YoGZL7Wh1XoVA1tl4EueRU
# 4G9ZmGgAWQaz4fTCnaJADuV5faPZWeIE/Gp6Q3soJV3ziVMN8o+cmv6bdgctnvjA
# sYqhdo4L6tJt5gs=
# SIG # End signature block
