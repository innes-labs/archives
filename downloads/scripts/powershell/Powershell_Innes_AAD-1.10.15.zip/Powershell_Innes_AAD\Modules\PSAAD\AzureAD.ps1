Function New-AADApplication-CommonsUtils  {
<#
.SYNOPSIS
This function creates the Azure AD application for the sample in the provided Azure AD tenant 
.DESCRIPTION
This function creates the Azure AD application for the sample in the provided Azure AD tenant 
.PARAMETER Credential
The credential of the Azure AD user used to create the application. if absent, a dialog is displayed to connect to Azure AD 
.PARAMETER tenantId
The Active Directory Tenant. This is a GUID which represents the "Directory ID" of the AzureAD tenant
into which you want to create the apps. Look it up in the Azure portal in the "Properties" of the Azure AD
.PARAMETER appName
The name of the application 
.PARAMETER homePage 
The home page of the application
.PARAMETER replyUrls
The list of redirect Urls of the application
.PARAMETER logoutUrl
The logout Url of the application
.PARAMETER delegatedPermissions
delegated permissions (separated by "|") for the "Microsoft Graph" application
.PARAMETER applicationPermissions
application permissions (separated by '|') for "Microsoft Graph" application
.PARAMETER certificatePath
The file path of the certificate used by application (use only if the parameter GeneratePassword is $false)
.PARAMETER certificate
The certificate used by application (use only if the parameter GeneratePassword is $false)
.PARAMETER GeneratePassword
The function generate the secret key of the application 
.OUTPUTS
The object that describe the application created. This object is already dumped in the file names "<appName>.json"
Its contains the following properties:
name : the application name
tenantId : the tenant id
clientId : the client id of application
objectId : the object id of application
clientSecret: the client secret generated (present only if parameter GeneratePassword is $true)
spId : the service pricipal id of application

#> 
[CmdletBinding()]
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName,
    [string] $homePage,
    [string[]] $replyUrls,
    [string] $logoutUrl,
    [string] $certificatePath,
    [string] $delegatedPermissions,
    [string] $applicationPermissions,
    [bool] $AvailableToOtherTenants = $false,
    [bool] $GeneratePassword = $false,
    [System.Security.Cryptography.X509Certificates.X509Certificate2] $certificate

)
# Pre-requisites
try {
    if ((Get-Module -ListAvailable -Name "AzureAD") -eq $null) { 
        Install-Module "AzureAD" -Scope CurrentUser 
    } 
    Import-Module AzureAD
    if (!$Credential -and $TenantId) {
        $creds = Connect-AzureAD -TenantId $tenantId
    }
    else {
        if (!$TenantId) {
            $creds = Connect-AzureAD -Credential $Credential
        }
        else {
            $creds = Connect-AzureAD -TenantId $tenantId -Credential $Credential
        }
    }

    if (!$tenantId) {
        $tenantId = $creds.Tenant.Id
    }

    $tenant = Get-AzureADTenantDetail
    $tenantName = ($tenant.VerifiedDomains | Where { $_._Default -eq $True }).Name

    # Get the user running the script
    $user = Get-AzureADUser -ObjectId $creds.Account.Id

    # Create the client AAD application
    LogWrite( "Creating the AAD application ($appName)")
    $clientAadApplication = $null
    if ($homePage) {
    $clientAadApplication = New-AzureADApplication -DisplayName $appName `
        -Homepage $homePage `
        -ReplyUrls $replyUrls `
        -LogoutUrl $logoutUrl `
        -PublicClient $False `
        -AvailableToOtherTenants  $AvailableToOtherTenants 
    }
    else {
        $clientAadApplication = New-AzureADApplication -DisplayName $appName `
        -ReplyUrls $replyUrls `
        -LogoutUrl $logoutUrl `
        -PublicClient $False `
        -AvailableToOtherTenants  $AvailableToOtherTenants 
    }
    LogWrite( "Creating the client application ($appName)")
    $password = $null
    if ($GeneratePassword) {
        $password = New-AzureADApplicationPasswordCredential -ObjectId $clientAadApplication.ObjectId -EndDate (Get-Date).AddYears(10)
    }
    else {
        if ($certificatePath) {
            $certificate = Import-Certificate -FilePath $certificatePath -CertStoreLocation cert:\CurrentUser\My
        }
        $certSubject = $null
        if (!$certificate) {
            # Generate a certificate

            $certSubject = $appName + "Cert"
            $certificate = New-SelfSignedCertificate -Subject CN=$subject `
                -CertStoreLocation "Cert:\CurrentUser\My" `
                -KeyExportPolicy Exportable `
                -KeySpec Signature
        }
        $certKeyId = [Guid]::NewGuid()
        $certSubject = $certificate.Subject
        $certBase64Value = [System.Convert]::ToBase64String($certificate.GetRawCertData())
        $certBase64Thumbprint = [System.Convert]::ToBase64String($certificate.GetCertHash())

        # Add a Azure Key Credentials from the certificate for the daemon application
        $clientKeyCredentials = New-AzureADApplicationKeyCredential -ObjectId $clientAadApplication.ObjectId `
            -CustomKeyIdentifier $certBase64Thumbprint `
            -Type AsymmetricX509Cert `
            -Usage Verify `
            -Value $certBase64Value `
            -StartDate $certificate.NotBefore `
            -EndDate $certificate.NotAfter
    }

    $currentAppId = $clientAadApplication.AppId
    $clientServicePrincipal = New-AzureADServicePrincipal -AppId $currentAppId -Tags { WindowsAzureActiveDirectoryIntegratedApp }

    # add the user running the script as an app owner if needed
    $owner = Get-AzureADApplicationOwner -ObjectId $clientAadApplication.ObjectId
    if ($owner -eq $null) { 
        Add-AzureADApplicationOwner -ObjectId $clientAadApplication.ObjectId -RefObjectId $user.ObjectId
        LogWrite( "'$($user.UserPrincipalName)' added as an application owner to app '$($clientServicePrincipal.DisplayName)'")
    }

    LogWrite( "Done creating the client application ($appName)")

    # URL of the AAD application in the Azure portal
    # Future? $clientPortalUrl = "https://portal.azure.com/#@"+$tenantName+"/blade/Microsoft_AAD_RegisteredApps/ApplicationMenuBlade/Overview/appId/"+$clientAadApplication.AppId+"/objectId/"+$clientAadApplication.ObjectId+"/isMSAApp/"
    $clientPortalUrl = "https://portal.azure.com/#blade/Microsoft_AAD_RegisteredApps/ApplicationMenuBlade/CallAnAPI/appId/" + $clientAadApplication.AppId + "/objectId/" + $clientAadApplication.ObjectId + "/isMSAApp/"
    # Add-Content -Value "<tr><td>client</td><td>$currentAppId</td><td><a href='$clientPortalUrl'>$appName</a></td></tr>" -Path createdApps.html
    if ($applicationPermissions -or $delegatedPermissions) {
        $requiredResourcesAccess = New-Object System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.RequiredResourceAccess]
        # Add Required Resources Access (from 'client' to 'Microsoft Graph')
        LogWrite( "Getting access from 'client' to 'Microsoft Graph'")
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredApplicationPermissions $applicationPermissions `
            -requiredDelegatedPermissions $delegatedPermissions;
        $requiredResourcesAccess.Add($requiredPermissions)
        Set-AzureADApplication -ObjectId $clientAadApplication.ObjectId -RequiredResourceAccess $requiredResourcesAccess
        LogWrite( "Granted permissions.")
    }

    $app = @{
        tenantId = $tenantId
        name     = $appName
        clientId = $clientAadApplication.AppId
        objectId = $clientAadApplication.ObjectId
        spId     = $clientServicePrincipal.ObjectId
    }
    if ($GeneratePassword) {
        $app.Add("clientSecret", $password.value);
    }
    return $app
} catch 
{
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}
}


Function Start-ConsentRedirectServer {
    <#
    .SYNOPSIS
    This function starts an HTTP server used to display the redirect URI of consent request 
    .PARAMETER baseUri
    The base URI of the server
    .PARAMETER redirectUri
    The relative redirect URI of consent request
    .PARAMETER tenantId
#> 
[CmdletBinding()]
param(
    [string] $baseUri = "http://localhost:23456/",
    [string] $redirectUri = "/consent/redirect"
);
    $http = [System.Net.HttpListener]::new() 
    # Hostname and port to listen on
    $http.Prefixes.Add($baseUri)
    # Start the Http Server 
    $http.Start()
    while ($http.IsListening) {
        $context = $http.GetContext()
        if ($context.Request.HttpMethod -eq 'GET' -and $context.Request.RawUrl.StartsWith($redirectUri)) {

            [string]$html = "<h1>Success of the consent request</h1>" 
            $buffer = [System.Text.Encoding]::UTF8.GetBytes($html) # convert htmtl to bytes
            $context.Response.ContentLength64 = $buffer.Length
            $context.Response.OutputStream.Write($buffer, 0, $buffer.Length) #stream to broswer
            $context.Response.OutputStream.Close() # close the response
            LogWrite( "show consent")
            Start-Sleep -Seconds 5
            break;
        }
    }
}
# Export-ModuleMember -Function Start-ConsentRedirectServer

# Adds the requiredAccesses (expressed as a pipe separated string) to the requiredAccess structure
# The exposed permissions are in the $exposedPermissions collection, and the type of permission (Scope | Role) is 
# described in $permissionType
Function AddResourcePermission($requiredAccess, `
        $exposedPermissions, [string]$requiredAccesses, [string]$permissionType) {
    foreach ($permission in $requiredAccesses.Trim().Split("|")) {
        foreach ($exposedPermission in $exposedPermissions) {
            if ($exposedPermission.Value -eq $permission) {
                $resourceAccess = New-Object Microsoft.Open.AzureAD.Model.ResourceAccess
                $resourceAccess.Type = $permissionType # Scope = Delegated permissions | Role = Application permissions
                $resourceAccess.Id = $exposedPermission.Id # Read directory data
                $requiredAccess.ResourceAccess.Add($resourceAccess)
            }
        }
    }
}

#
# Exemple: GetRequiredPermissions "Microsoft Graph"  "Graph.Read|User.Read"
# See also: http://stackoverflow.com/questions/42164581/how-to-configure-a-new-azure-ad-application-through-powershell
Function GetRequiredPermissions([string] $applicationDisplayName, [string] $requiredDelegatedPermissions, [string]$requiredApplicationPermissions, $servicePrincipal, $appid) {
    # If we are passed the service principal we use it directly, otherwise we find it from the display name (which might not be unique)
    if ($servicePrincipal) {
        $sp = $servicePrincipal
    }
    else {
        if ($appid)
        {
            $sp = Get-AzureADServicePrincipal -Filter "AppId eq '$appid'"
        }
        else {
            $sp = Get-AzureADServicePrincipal -Filter "DisplayName eq '$applicationDisplayName'"
        }
    }
    $appid = $sp.AppId
    $requiredAccess = New-Object Microsoft.Open.AzureAD.Model.RequiredResourceAccess
    $requiredAccess.ResourceAppId = $appid 
    $requiredAccess.ResourceAccess = New-Object System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.ResourceAccess]

    # $sp.Oauth2Permissions | Select Id,AdminConsentDisplayName,Value: To see the list of all the Delegated permissions for the application:
    if ($requiredDelegatedPermissions) {
        AddResourcePermission $requiredAccess -exposedPermissions $sp.Oauth2Permissions -requiredAccesses $requiredDelegatedPermissions -permissionType "Scope"
    }

    # $sp.AppRoles | Select Id,AdminConsentDisplayName,Value: To see the list of all the Application permissions for the application
    if ($requiredApplicationPermissions) {
        AddResourcePermission $requiredAccess -exposedPermissions $sp.AppRoles -requiredAccesses $requiredApplicationPermissions -permissionType "Role"
    }
    return $requiredAccess
}


Function Remove-AADApplication-CommonsUtils {
    <#
    .SYNOPSIS
    This function creates the Azure AD application for the sample in the provided Azure AD tenant 
    .DESCRIPTION
    This function creates the Azure AD application for the sample in the provided Azure AD tenant 
    .PARAMETER Credential
    The credential of the Azure AD user used to create the application. if absent, a dialog is displayed to connect to Azure AD 
    .PARAMETER tenantId
    The Active Directory Tenant. This is a GUID which represents the "Directory ID" of the AzureAD tenant
    into which you want to create the apps. Look it up in the Azure portal in the "Properties" of the Azure AD
    .PARAMETER appName
    The name of the application to be removed
#> 
[CmdletBinding()]
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName
)
# Pre-requisites
try {
    if ((Get-Module -ListAvailable -Name "AzureAD") -eq $null) { 
        Install-Module "AzureAD" -Scope CurrentUser 
    } 
    Import-Module AzureAD
    if (!$Credential -and $TenantId) {
        $creds = Connect-AzureAD -TenantId $tenantId
    }
    else {
        if (!$TenantId) {
            $creds = Connect-AzureAD -Credential $Credential
        }
        else {
            $creds = Connect-AzureAD -TenantId $tenantId -Credential $Credential
        }
    }
    $filter = "DisplayName eq '" + $appName + "'"
    $app = Get-AzureADApplication -Filter $filter
    if ($app) {
        Remove-AzureADApplication -ObjectId $app.objectId
    }
    else  {
        throw "Application '$appName' does not exist"
    }
} catch 
{
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU5gzehT0XmlbKxUbpBqFB3+VT
# ehegggP3MIID8zCCAtugAwIBAgIQU+aMBKUEyptN+HUd2J/3njANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MTIyNzE0MzMxMFoXDTIzMTIyNzE0NTMxMFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMFQ7fHX
# 7YvspoV/7c/FH0u8/teRt8SKYdTd3mv+MOv+8NSbKHtTr+4/MB+JVLwsBX3Kd4Vi
# +uza9wpwtEn3oYThrgMNCLuP3wNcSh/5Nu2CCOgmqYhgL0gXMYMPV1E7hGmjaC/z
# Zi0m5hruC8xq+OpynYsR3meuc6a5gqZ8oZtcwUpwtmf4uaA0pl3xOC5DGc+SROFR
# Arz69o2mXMxB0JOnf9JP8FScPeaAoyDYvKw/ZsiTP9tK+89lV4Dpk+NlqFzZOa1K
# GDbUcR8Ji85ENUC8Su/6Ox8u80AcwD/lu3xX4kmSiqR/ik3xV8y0nQiu+K2soDzL
# AWktRgOt1xUJ/tUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTwYNb1GiJFbW5XeM06wu6JTXweHzANBgkqhkiG9w0BAQsFAAOCAQEAILtQ
# rK0LUB57tFNS5q/LAaiC/EFgXOSAjrF3rF+BG2Vfz0Mr63Iy4TeF9rOAplZv6adb
# 8RtVkuVZn8dxK3B7Uh4kaDAZaNNk8qLNugQDenxlEh0I1ZMFhEiUVLFHnzcFweyC
# Kn3SzKM3YqbHB6gc4DHDUMRKAvhnX6QhyWg5V2+gJO52bz3jy4DDN++Zd4a4wiMJ
# MFZPf1rgqsXXK8k1nw41zCU1CMt7XPJLcNiPpigXKBh08p0Eob3LFSmdB1M9Dz+w
# IGU3+eJRCtcpCYMzJPISGaO3TBNDiO9y1vp5urj47LLFpkdbb7jMTilvVGJPLueH
# nINidBGAXG9rbK2MgDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFPmjASlBMqbTfh1Hdif954wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFDtd3T6EC9o9CM8hRDUbn9LcR5+0MA0GCSqGSIb3DQEBAQUABIIBABheQ00B
# xfRq5FHoN6HWL1AKyZZlfXOtNsxmXkolyM4OaX2vFJsISQU2TOmvmmCEiaPYqAOx
# Kfq0ar/Xdwd8X76vGpeTWZyx/PYdtxjwKkoKTVnqllv5QuJbRJTZ3xSpaOY6PtJ5
# skPAJoyiyyRn164y9N4yf2FNbSXpYNZ5W08nxm40YhVR4XCXadMQEWIZhZEtF5S4
# O0T1rrzglwwgBBGYpJ6Te+3Xwiyd+JO7ywQINApWSCqd3GMYJRQ7CGmiLJVRfbf0
# JsI3n7Li8VUbWBsX7pMOykTaHCHHm52SNaHyqAYU2DLkdBimQwBDbGd5Gu0b88Dp
# ANcGyyzMi8yT9NA=
# SIG # End signature block
