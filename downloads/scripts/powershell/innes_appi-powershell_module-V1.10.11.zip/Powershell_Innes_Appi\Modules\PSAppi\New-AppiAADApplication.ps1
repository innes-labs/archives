Function New-AppiAADApplication {
<# 
.SYNOPSIS
This function creates a Azure Active Directory application.  
.DESCRIPTION
This function creates a Azure Active Directory application.  
.PARAMETER Credential
Exchange credential (admin profile) used to create the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the Exchange credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been created. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
Name of the Azure Active Directory application.
.PARAMETER authorizations
Authorization type:
- "onedrive" (default value): to access to OneDrive resources
- "ews": to access to Exchange resources.
.PARAMETER logFile
Log file path
.OUTPUTS
The result is an object that is describing the created Azure Active Directory application. 
It contains the following properties:
- name : Azure Active directory application name
- tenantId : Azure Active directory's tenant id
- clientId : Azure Active directory's application (client) Id
- objectId : Azure Active directory's application object id
- clientSecret: Azure Active directory's client secret
- spId : Azure Active directory's application service principal id
These object properties are flushed automatically in the "<appName>.json" file in the current directory.
.EXAMPLE
PS C:\>$result = New-AppiAADApplication -appname "SignMeeting"  -authorizations "ews"
A consent request will be sent in 30 seconds in your browser.
You must log into an administrator account of your organization and grant the necessary permissions.
PS C:\>$result
Name                           Value
----                           -----
clientId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
objectId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
spId                           xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
name                           SignMeeting
tenantId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
clientSecret                   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
.NOTES 
 VERSION:1.10.10
#>

   [CmdletBinding()] 
   param(
      [PSCredential] $Credential,
      [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
      [string] $tenantId,
      [Parameter(Mandatory = $true)]
      [string] $appName,
      [Parameter()]
      [ValidateSet('onedrive','ews')]
      [string[]] $authorizations = "onedrive",
      [string] $LogFile
   )
   $date = Get-Date
   LogWrite("$date : create new AAD application with name `"$appName`"")
   try {
      $consentRedirectUri = "http://localhost:23456/consent/redirect"
      [String[]] $replyUrls = @($consentRedirectUri)
      $app = New-AADApplication -credential $Credential -tenantId $tenantId -appName $appName `
         -replyUrls $replyUrls `
         -generatePassword $true -delegatedPermissions $permissions -applicationPermissions $permissions
      $requiredResourcesAccess = New-Object System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.RequiredResourceAccess]
      if ($authorizations.Contains("onedrive")) {
         $permissions = "Files.ReadWrite.All|Sites.ReadWrite.All|User.Read"
         $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions $permissions -applicationPermissions $permissions
         $requiredResourcesAccess.Add($requiredPermissions)
      }
      if ($authorizations.Contains("ews")) {
         $requiredPermissions = GetRequiredPermissions -appid "00000002-0000-0ff1-ce00-000000000000" `
            -requiredApplicationPermissions "full_access_as_app"
         $requiredResourcesAccess.Add($requiredPermissions)
         $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions "EWS.AccessAsUser.All|User.Read"
         $requiredResourcesAccess.Add($requiredPermissions)
      }
      Set-AzureADApplication -ObjectId $app.ObjectId -RequiredResourceAccess $requiredResourcesAccess
      $app.clientSecret = [System.Web.HttpUtility]::UrlEncode($app.clientSecret)
      Set-Content -Path ".\$appName.json" -Value ($app | ConvertTo-Json -Depth 5)
      Write-Host "A consent request will be sent in 30 seconds in your browser.`
You must log into an administrator account of your organization and grant the necessary permissions."
      Start-Sleep 30
      $request = "https://login.microsoftonline.com/" + $app.tenantId + "/adminconsent" + `
         "?client_id=" + $app.ClientId + "&redirect_uri=" + $consentRedirectUri
      Start-Process $request
      Start-ConsentRedirectServer
      LogWrite("Application created")
      $app
   }
   catch {
      LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
      throw $_.Exception
   }
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU2RVxDuZgKuBxiQNQ2pTBGOlT
# KsSgggP3MIID8zCCAtugAwIBAgIQO1Z7XwQetqZOfywREvXBhzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MTAyMDA4MzUzN1oXDTIxMTAyMDA4NTUzN1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAM5jckVp
# r7Fcw72W2Nj3l6NMas3LxYnHr1tGtJviamkFX5s5YMfAqBTuV8b5JgNhEKvsQPkL
# lYJOfOFIv0gxGJIsqjATCeP754Le5bG4kTqI1rpomAQQuxjb1JoZLGdkN7Noye8Q
# UYvti5xYsZ7d9AC9T4F6rG20KCVgLKAWNtmdUhvnNteMJVFQGVwSB3vclnzAg7N2
# CiFXgBCF9BavRhCVfaElMrVx3rXd2USkk4TjZ1f/yr94Bpls4MrcHX3LXI4q7Oz8
# zlHsR2h5zaOxsJJf+zZeSUbbwzJzSKc5o/ESc/2qViVO5ZOLdn/kT2SRQlTPohbE
# 8TDVtFtnAQSo5dUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQEHDe6aLhYcGPUZdnQxfs4ewo6rjANBgkqhkiG9w0BAQsFAAOCAQEALwyj
# U2p2HcSa+7kjjPHFci5IJybc7HWJc+ytDCeN37TctnxzWr7ubl304virT6HBGPnZ
# YJ4MClPxq78nyLwR+scbYE5IgxsjMNEY+tSOIVOFuohHkv3WM8c9d0r7WQqTxs3S
# DVk08wzLmYV9qU36+KURGFCV7m3DrMx3gUyWV2v1JJiv4elzXGFx2Je7L8IH7pSo
# MuxbfgiL91VrpoWQbsaS0yrlqFsfEuuLHZZJdKD+iJG4qPxMlzoF1bZdSrF8W4KO
# b3R2bnOl5IxCDj1qrECSslGaI6aZwK5u6gRPXlnqdwdJq5yqeZ8gF6T6eRzoZV6u
# OupKI2pl+a8kHSl/UTGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEDtWe18EHramTn8sERL1wYcwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFBInJPAiX+nVVolKBgqLRfPWbKgZMA0GCSqGSIb3DQEBAQUABIIBAEMzSf6V
# Jxu3e7l48Q0d+tyZ4LJ3HvRWuDJPVsfOvSsNOYJGnyWlRmnrjCIeex4HjHlVTBQ2
# dCVuutJG2nC32RcgbApIJV16iWOFwTZWmxOeU7pIy/Lmi9+O71pdFkVa0irl90Bk
# ZJQUZWH+BdGW7M4iUFLsa4KpddppdRrkQ2XeojyE8/ntyGrhfdV2ItfRvCkfXqz5
# vtcvb1j+kQ25azyPlCMpRZpQVf2AZiMU9RfHJWvVrZ6Gru1+Z5UPp3p1GwjbXJ8r
# 0B5HwsVfD1Z4e6U+2MkR3ZIP5OUvM247gk9jeG/Rgv35WnJy5MZZw0P0YYQ4xioi
# 2zPPhhY7vzGgkh8=
# SIG # End signature block
