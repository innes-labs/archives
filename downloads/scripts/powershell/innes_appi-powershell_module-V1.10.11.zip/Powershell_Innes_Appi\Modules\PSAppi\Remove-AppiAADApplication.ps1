Function Remove-AppiAADApplication {
<# 
.SYNOPSIS
This function removes a Azure Active Directory application.  
.DESCRIPTION
This function removes a Azure Active Directory application.  
.PARAMETER Credential
Exchange credential (admin profile) used to remove the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the Exchange credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been removed. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
The name of the Azure Active Directory application.
.OUTPUTS
Nothing
.EXAMPLE
PS C:\>Remove-AppiAADApplication -appname "SignMeeting"
 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName
)

$date = Get-Date
LogWrite("$date : delete AAD application with name `"$appName`"")

Remove-AADApplication -credential $Credential -tenantId $tenantId -appName $appName 
LogWrite("Application removed")

}
# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUcWwNO40nL4rgtat0bRD9D16r
# Kw+gggP3MIID8zCCAtugAwIBAgIQO1Z7XwQetqZOfywREvXBhzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MTAyMDA4MzUzN1oXDTIxMTAyMDA4NTUzN1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAM5jckVp
# r7Fcw72W2Nj3l6NMas3LxYnHr1tGtJviamkFX5s5YMfAqBTuV8b5JgNhEKvsQPkL
# lYJOfOFIv0gxGJIsqjATCeP754Le5bG4kTqI1rpomAQQuxjb1JoZLGdkN7Noye8Q
# UYvti5xYsZ7d9AC9T4F6rG20KCVgLKAWNtmdUhvnNteMJVFQGVwSB3vclnzAg7N2
# CiFXgBCF9BavRhCVfaElMrVx3rXd2USkk4TjZ1f/yr94Bpls4MrcHX3LXI4q7Oz8
# zlHsR2h5zaOxsJJf+zZeSUbbwzJzSKc5o/ESc/2qViVO5ZOLdn/kT2SRQlTPohbE
# 8TDVtFtnAQSo5dUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQEHDe6aLhYcGPUZdnQxfs4ewo6rjANBgkqhkiG9w0BAQsFAAOCAQEALwyj
# U2p2HcSa+7kjjPHFci5IJybc7HWJc+ytDCeN37TctnxzWr7ubl304virT6HBGPnZ
# YJ4MClPxq78nyLwR+scbYE5IgxsjMNEY+tSOIVOFuohHkv3WM8c9d0r7WQqTxs3S
# DVk08wzLmYV9qU36+KURGFCV7m3DrMx3gUyWV2v1JJiv4elzXGFx2Je7L8IH7pSo
# MuxbfgiL91VrpoWQbsaS0yrlqFsfEuuLHZZJdKD+iJG4qPxMlzoF1bZdSrF8W4KO
# b3R2bnOl5IxCDj1qrECSslGaI6aZwK5u6gRPXlnqdwdJq5yqeZ8gF6T6eRzoZV6u
# OupKI2pl+a8kHSl/UTGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEDtWe18EHramTn8sERL1wYcwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFFpGUtkmVRQlwk1u1z6OGao+d6aCMA0GCSqGSIb3DQEBAQUABIIBABgGbyzk
# bSemsK+mvboNz97lwwIOhz+LCL4UNvo5TyRvwm2wo3TG0hEhFwebPV3OyReI0bbq
# t0KuQAOmDEsxOPJQJd8rDmQ5uTRcg6JBEYNUGnjOOhzV5prQvEL+7o+xlFquk4IQ
# mr/IKHbkNjmXUlKZmiQfDED2aKlqz0ckyUlKQIJtZk/7u3EtH5qnV7F4pHSo7VIx
# BRpTYlKrhNTJ7gH6B82X1XMqecB3te515YhGibkXo+jSpPDRvGk5+uJ0ul0g10rX
# 1etmOAj6lDoEG/K4Uw65ZWVTC+6VfA9J/gTLVxGZH86mks4PlXNKR8VDIJ4zJvhW
# GV+Zz6Grsp8fgxQ=
# SIG # End signature block
