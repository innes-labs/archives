Function Remove-AADApplication {
<# 
.SYNOPSIS
This function removes a Azure Active Directory application.  
.DESCRIPTION
This function removes a Azure Active Directory application.  
.PARAMETER Credential
Exchange credential (admin profile) used to remove the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the Exchange credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been removed. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
The name of the Azure Active Directory application.
.OUTPUTS
Nothing
.EXAMPLE
PS C:\>Remove-AADApplication -appname "SignMeeting"
 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName
)

$date = Get-Date
LogWrite("$date : delete AAD application with name `"$appName`"")

Remove-AADApplication-CommonsUtils -credential $Credential -tenantId $tenantId -appName $appName 
LogWrite("Application removed")

}
# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUGNKiDNmaEp5ARUC1u5SFjcqj
# JBagggP3MIID8zCCAtugAwIBAgIQYXLdSNEwpJpLfVNijV6H8TANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIz
# MDUxNjE1MjczOVoXDTI0MDUxNjE1NDczOVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAK/bwyqw
# rz8HFW/ewMA58uKNLNDykKKGVpdon3WI1BK7IcF5lBu7qDEoskaqAVZFpXctdXOr
# NomAZ9ukBHjiNbpGFjMeJpglX5VGpp3TA/9ezU7xPAu/T1OrWUHAQVisIJU0Eauo
# 461PMnpnOUr88x8+7aXNfsXUYRKvZsm4k3WJ25VuL2vUHD6NXynVDob//4kt1mL3
# 8oeI5/nX6VR+8jCybwZN4KBZIEssTNzERA5boWDR38wpbxSVxF12ctVmnsM68BTI
# ouRwlrr4CdhIUrnEE9XvyqU/T0xr7Pn/NNP6K5/gUecvX9kl1s2oUm9D8K4rEJLq
# 8Rg0eeyDkAyX2t0CAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTkMVAcqNQD//syeAlhmcRJujeaUDANBgkqhkiG9w0BAQsFAAOCAQEATvmD
# g+S+ZYX0zo7LcfZqAQeF/jXJCEwXnsAexiX8+IKslp54cZD5x66hK+PjdXb11WYq
# x6ps2kNQUXtfTuRFfLvgKkcfXHfQoyteK0S5X9HrXlmkW8g09VGsu0xKu56xFjXL
# BFsa/VPDGO5j0wjunod0OWMt9Jjq5ihPeWzF+iYbQtK7aYB/SZ5Qk/ELRwjmY+Us
# +in6UGhuwUvenhwo1kkOrQK3tTXJI4LgyJYn/qh2zXqqgL9kRoomOyLyHWkt+avf
# LGOb7gPngJx3REIz4ym2bddhFV3qGst65G5mxtjMe8+SPaabxIA5pv8R7U7VJhni
# zD9ZB6MZ+e706CTHXzGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEGFy3UjRMKSaS31TYo1eh/EwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFLx70aBBAemhzBI57NTsD3NPEAwvMA0GCSqGSIb3DQEBAQUABIIBABR/YNUf
# z2N3Pl3Ge58ktcW3JQJvflvABZyIkQs0tYuPIIakxXjzZGRV8MguWjEfRZV32zvY
# eBtyOZKS/GfQhGwS/UkZZMU1qQ1phQA5asHK0/rzxM0SjczaMklFVuROsJRpkRl/
# mKgSoU6Xd1MQ7QPFFXo4dfkFYRueTATUVXkvimW9vJU8fNK055DLmLEu0xlinWp0
# faoXWnb5E0hcwx8VyIjKOyUfJSOdTWahQou8F4Ic+vFzkilTqmoL7KgbfcBGHg24
# /77f9tGGMcIxZIITEjgNijzxXRUKfx++PeEM3ZQX1gO5diMThQ3PLRvjrhA4uvd5
# oGvY8ldpFN1poQw=
# SIG # End signature block
