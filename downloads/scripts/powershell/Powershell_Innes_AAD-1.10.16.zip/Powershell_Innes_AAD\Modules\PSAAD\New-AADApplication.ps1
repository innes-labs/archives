Function New-AADApplication {
<# 
.SYNOPSIS
This function creates a Azure Active Directory application.  
.DESCRIPTION
This function creates a Azure Active Directory application.  
.PARAMETER Credential
Credential (admin profile) used to create the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been created. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
Name of the Azure Active Directory application.
.PARAMETER authorizations
Authorization type:
- "signcom_m365" : to access to M365 files and folders resources and Web sites for SignCom application
- "url_launcher_m365" : to access to M365 Web sites for URL launcher application
- "signmeeting_ews": to access to MS-Exchange room mailbox resources for SignMeeting MS-Exchange application
- "signmeeting_m365": to access to M365 room mailbox resources for SignMeeting-M365 application
- "briva_calendar_ews": to access to MS-Exchange room mailbox resources for Briva Calendar EWS application
- "m365_room": to access to M365 room mailbox resource for SBL10e m365_room application
- "m365_user": to access to M365 user presence resource for SBL10e m365_user application
- "powerbi": to access to Power BI report
.PARAMETER logFile
Log file path
.OUTPUTS
The result is an object that is describing the created Azure Active Directory application. 
It contains the following properties:
- name : Azure Active directory application name
- tenantId : Azure Active directory's tenant id
- clientId : Azure Active directory's application (client) Id
- objectId : Azure Active directory's application object id
- clientSecret: Azure Active directory's client secret
- spId : Azure Active directory's application service principal id
These object properties are flushed automatically in the "<appName>.json" file in the current directory.
.EXAMPLE
PS C:\>$result = New-AADApplication -appname "SignMeeting"  -authorizations "signmeeting_ews"
A consent request will be sent in 30 seconds in your browser.
You must log into an administrator account of your organization and grant the necessary permissions.
PS C:\>$result
Name                           Value
----                           -----
clientId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
objectId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
spId                           xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
name                           SignMeeting
tenantId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
clientSecret                   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
.NOTES 
 VERSION:1.10.10
#>

   [CmdletBinding()] 
   param(
      [PSCredential] $Credential,
      [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
      [string] $tenantId,
      [Parameter(Mandatory = $true)]
      [string] $appName,
      [Parameter(Mandatory = $true)]
      [ValidateSet('signcom_m365', 'url_launcher_m365', 'signmeeting_ews', 'signmeeting_m365', 'm365_room', 'm365_user', 'powerbi', 'briva_calendar_ews')]
      [string[]] $authorizations,
      [string] $LogFile,
      [bool] $multiTenants = $false
   )
   $date = Get-Date
   LogWrite("$date : create new AAD application with name `"$appName`"")
   try {
      $consentRedirectUri = "http://localhost:23456/consent/redirect"
      [String[]] $replyUrls = @($consentRedirectUri)
      $app = New-AADApplication-CommonsUtils  -credential $Credential -tenantId $tenantId -appName $appName `
         -replyUrls $replyUrls `
         -generatePassword $true -AvailableToOtherTenants $multiTenants
      $requiredResourcesAccess = New-Object System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.RequiredResourceAccess]
      for ($i = 0; $i -lt $authorizations.length; $i++)
      {
          $authorizations[$i] = ($authorizations[$i]).ToLower();
      }
      $hasDelegatedPermission = $false;
      if ($authorizations.Contains("signcom_m365") -or $authorizations.Contains("url_launcher_m365")) {
         $permissions = "Files.Read.All|Sites.Read.All|User.Read"
         $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions $permissions -requiredApplicationPermissions $permissions
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("signmeeting_ews")) {
         $requiredPermissions = GetRequiredPermissions -appid "00000002-0000-0ff1-ce00-000000000000" `
            -requiredApplicationPermissions "full_access_as_app"
         $requiredResourcesAccess.Add($requiredPermissions)
         $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions "EWS.AccessAsUser.All|User.Read"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("briva_calendar_ews")) {
        $requiredPermissions = GetRequiredPermissions -appid "00000002-0000-0ff1-ce00-000000000000" `
           -requiredApplicationPermissions "full_access_as_app"
        $requiredResourcesAccess.Add($requiredPermissions)
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
           -requiredDelegatedPermissions "EWS.AccessAsUser.All|User.Read"
        $requiredResourcesAccess.Add($requiredPermissions)
        $hasDelegatedPermission = $true;
     }
      if ($authorizations.Contains("signmeeting_m365")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredApplicationPermissions "Place.Read.All|User.Read.All|Calendars.ReadWrite"
         $requiredResourcesAccess.Add($requiredPermissions)
      }
      if ($authorizations.Contains("m365_room")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredApplicationPermissions "Calendars.Read|User.Read.All"
         $requiredResourcesAccess.Add($requiredPermissions)
      }
      if ($authorizations.Contains("m365_user")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredDelegatedPermissions "Directory.AccessAsUser.All|Presence.Read.All"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("powerbi")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Power BI Service" `
        -requiredDelegatedPermissions "App.Read.All|Content.Create|Dataset.ReadWrite.All|Report.ReadWrite.All"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      Set-AzureADApplication -ObjectId $app.ObjectId -RequiredResourceAccess $requiredResourcesAccess
    #   $app.clientSecret = [System.Web.HttpUtility]::UrlEncode($app.clientSecret)
      Set-Content -Path ".\$appName.json" -Value ($app | ConvertTo-Json -Depth 5)
      $hasDelegatedPermission = $true
      if ($hasDelegatedPermission) 
      {
        Write-Host "A consent request will be sent in 50 seconds in your browser.`
        You must log into an administrator account of your organization and grant the necessary permissions."
        Start-Sleep 50
        $request = "https://login.microsoftonline.com/" + $app.tenantId + "/adminconsent" + `
        "?client_id=" + $app.ClientId + "&redirect_uri=" + $consentRedirectUri
        Start-Process $request
        Start-ConsentRedirectServer
      }
      Write-Host("Application created")
      $app
   }
   catch {
      LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
      throw $_.Exception
   }
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUVn9QsI0RFQYRgVbk6SSeWj3G
# WNSgggP3MIID8zCCAtugAwIBAgIQYXLdSNEwpJpLfVNijV6H8TANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIz
# MDUxNjE1MjczOVoXDTI0MDUxNjE1NDczOVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAK/bwyqw
# rz8HFW/ewMA58uKNLNDykKKGVpdon3WI1BK7IcF5lBu7qDEoskaqAVZFpXctdXOr
# NomAZ9ukBHjiNbpGFjMeJpglX5VGpp3TA/9ezU7xPAu/T1OrWUHAQVisIJU0Eauo
# 461PMnpnOUr88x8+7aXNfsXUYRKvZsm4k3WJ25VuL2vUHD6NXynVDob//4kt1mL3
# 8oeI5/nX6VR+8jCybwZN4KBZIEssTNzERA5boWDR38wpbxSVxF12ctVmnsM68BTI
# ouRwlrr4CdhIUrnEE9XvyqU/T0xr7Pn/NNP6K5/gUecvX9kl1s2oUm9D8K4rEJLq
# 8Rg0eeyDkAyX2t0CAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTkMVAcqNQD//syeAlhmcRJujeaUDANBgkqhkiG9w0BAQsFAAOCAQEATvmD
# g+S+ZYX0zo7LcfZqAQeF/jXJCEwXnsAexiX8+IKslp54cZD5x66hK+PjdXb11WYq
# x6ps2kNQUXtfTuRFfLvgKkcfXHfQoyteK0S5X9HrXlmkW8g09VGsu0xKu56xFjXL
# BFsa/VPDGO5j0wjunod0OWMt9Jjq5ihPeWzF+iYbQtK7aYB/SZ5Qk/ELRwjmY+Us
# +in6UGhuwUvenhwo1kkOrQK3tTXJI4LgyJYn/qh2zXqqgL9kRoomOyLyHWkt+avf
# LGOb7gPngJx3REIz4ym2bddhFV3qGst65G5mxtjMe8+SPaabxIA5pv8R7U7VJhni
# zD9ZB6MZ+e706CTHXzGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEGFy3UjRMKSaS31TYo1eh/EwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFIZVkiLA3sQEl314XGF2+0NnXGSYMA0GCSqGSIb3DQEBAQUABIIBABxp6TJZ
# DE5qM6NkzdLYoh80BS+VAuu2mnarZpmWP2NG7+yE55KTXfO5UJUpl1xghJLS95Pd
# V81TwVNlZVTKWZOrC2XHX+W2lkdfiKOGAk33z+ATXdBL9OXNw0S5ctWYzVA9+DnW
# vEKRLZoy5lQ+qUWt3IHfRXuFtS1WyZnslz63rdZORfHqZ0ymX+QDAZFAn/31drlY
# zy/DspK7jALt/6lv1fE/6D5dzAqsp+YWaKcWhjxL7ee8SWFNuapm60BGk2Faoahr
# 9R0JwxbLL1idQuWLWrUNnGbSmThuWjWOkHnJMx9gOuv6ngQ8N9/06HCTwRS1foDb
# MpEUjh2pOBvG2Ag=
# SIG # End signature block
