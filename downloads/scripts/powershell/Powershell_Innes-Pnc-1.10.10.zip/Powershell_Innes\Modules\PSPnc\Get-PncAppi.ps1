Function Get-PncAppi {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve all installed APPIs
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve all installed APPIs
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS 
The powershell object that describes all installed APPIs.
Example of object formated in JSON :
{
    "urn:innes:system-app#playzilla":  {
        "nbValidTokens":  0,
        "versions":  {
            "4.10.19":  {
                ...
            }
            ...
        }
         "domains":  {
            "domain1":  {
                "nbValidTokens":  0
            }
          },
        "hiddenDomains":  false,
        "id":  "urn:innes:system-app#playzilla",
        "hiddenLicenses":  false,
        "licenses":  {
             "PSN00690-00000 CD5":  {
                 "label":  "playzilla",
                 "valid":  false,
                  "license":  "xxxx - xxxx - xxxx - xxxx - xxxxx",
                 "domain":  "domain1",
                 "hiddenDomain":  false
             },
              ...
           }
        }
    }
    ...
}
.EXAMPLE
Get-PncAppi -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve appis for server `"$server`"")

 

$Body = @{
    target = "nsIAppliAppis.list"
}
$JsonBody = $Body | ConvertTo-Json
Start-Sleep -m $SleepDurationBeforeCommand

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}

$AppisObject = $ExecutedRequest | ConvertFrom-Json
LogWrite($AppisObject | ConvertTo-Json -Depth 5)
$AppisObject
}




# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUrJgCksewjfjG9QCCprdO/i21
# SgOgggP3MIID8zCCAtugAwIBAgIQbjJn9+EembRHkSI54vW1kDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MDYxNTIxMDQxMVoXDTIxMDYxNTIxMjQxMVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMkLknOb
# gzuOct1REel+1YdZhKrssnRqS4ckl0g3CKwRWqFBoLfLSPsfUZZlkP6ZSBnCG2GR
# 0m/894NizxWtfC/iVWCrDkGDYmyryEMNt4vYjWz6Om80HdgtQuAOPkLtOpBW5w2A
# 9DTXRoJ281i34Zo+jklCJUIUZmBnZ9Rj62ypgdt1J3KDKz1b5G0iGlqhYFkCL4Oo
# oO105hcGtGzVfaBPGQDBH+RMZQRuwmrcQGUZK/44S+Iyabb0xdz7ynY/L1aky+Vu
# Eo6jS5sOUWha1c15ypqrZwUvPs4SOaduONnLLho79MruWfyUq71O9MvLybg3NZXZ
# nEQtMg1moPZNf3UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQWaf+95kU3tj7YNirXKqWk7v2uTzANBgkqhkiG9w0BAQsFAAOCAQEALypb
# JpyJ1MsXs/keY9t39RwM+gOSZvr79JlqAddrssVj0HDh2mUcklndTzwz0UkUK/zn
# 20hUySTZpzw/y3Ov022OmA0ccAlhffX72KsL2oJL/ncz7voxBqc9iIq9QNYgEa12
# KindV+VbTuoD0jBmr05fvBgg89P90qwXsZBmzbVmOuxFoudF9r5MH8H6WDFOYAXo
# 8jle3JKcVdzQNazjeOJQismwoyaOeuu9VY8xIC2oeEuE4dJV/rBbJ5f4GaLln/Ht
# 5vsZ5BXxx6YJ+BgFxI01YDgF9VHqnjrOca7klX3xfjb72Cf4e1xf54i/51hq3pQg
# pWwPjKnCGEnTUEg2/zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEG4yZ/fhHpm0R5EiOeL1tZAwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFNCGLCoWirK8ajHCWNFegYK6aiHcMA0GCSqGSIb3DQEBAQUABIIBAEyX+E0F
# 0dylS1NgQfX7crtQiHpW85Vxgf6bFvXbfDD251X4N+6r1cYtqeXUOZPWnPR1yw/r
# 1079XEqGPgfDQM3oBgApOH1Zy3u5v1JydivXcdz1HcYUB5bb/mCzPHPhR0W4UHse
# vFogB7jKOsVUhVyj8BY/M8LnAecKyFbnRNKD8B8RIePzryaNRWw5LNLG8I5G8bA6
# u5DaO3fzoLN5B4I9lyYjRZK+Qv2su1/1xXvh2L3tTwTdhA63rSNsinbmEex96k/3
# djVtQSuPAsrvLcM6eKo6WSLfa3+AslFpY/7yyMfmbQQdybz4rQ8ioN1e8aq8YS3e
# QDgaUPbSHMIfvkU=
# SIG # End signature block
