# Load utilities
Function Get-PncVersion {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve its version.
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve its version.
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The string version.
.EXAMPLE
Get-PncVersion -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()] 
param(

    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
        [string] $UrlPort,
        [string] $UrlLogin,
        [string] $UrlPassword,
    [string] $LogFile
)

$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"

$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve the Plugncast version for server `"$server`"")


$Body = @{
    target = "nsIPref.getCharPref"
    args = @("extensions.lastAppVersion")
}
$JsonBody = $Body | ConvertTo-Json

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}

$VersionObject = $ExecutedRequest | ConvertFrom-Json


LogWrite($VersionObject | ConvertTo-Json -Depth 5)
$VersionObject
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU+R3+b+SHmCMQbRUxmyScWmSw
# JQKgggP3MIID8zCCAtugAwIBAgIQbjJn9+EembRHkSI54vW1kDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MDYxNTIxMDQxMVoXDTIxMDYxNTIxMjQxMVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMkLknOb
# gzuOct1REel+1YdZhKrssnRqS4ckl0g3CKwRWqFBoLfLSPsfUZZlkP6ZSBnCG2GR
# 0m/894NizxWtfC/iVWCrDkGDYmyryEMNt4vYjWz6Om80HdgtQuAOPkLtOpBW5w2A
# 9DTXRoJ281i34Zo+jklCJUIUZmBnZ9Rj62ypgdt1J3KDKz1b5G0iGlqhYFkCL4Oo
# oO105hcGtGzVfaBPGQDBH+RMZQRuwmrcQGUZK/44S+Iyabb0xdz7ynY/L1aky+Vu
# Eo6jS5sOUWha1c15ypqrZwUvPs4SOaduONnLLho79MruWfyUq71O9MvLybg3NZXZ
# nEQtMg1moPZNf3UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQWaf+95kU3tj7YNirXKqWk7v2uTzANBgkqhkiG9w0BAQsFAAOCAQEALypb
# JpyJ1MsXs/keY9t39RwM+gOSZvr79JlqAddrssVj0HDh2mUcklndTzwz0UkUK/zn
# 20hUySTZpzw/y3Ov022OmA0ccAlhffX72KsL2oJL/ncz7voxBqc9iIq9QNYgEa12
# KindV+VbTuoD0jBmr05fvBgg89P90qwXsZBmzbVmOuxFoudF9r5MH8H6WDFOYAXo
# 8jle3JKcVdzQNazjeOJQismwoyaOeuu9VY8xIC2oeEuE4dJV/rBbJ5f4GaLln/Ht
# 5vsZ5BXxx6YJ+BgFxI01YDgF9VHqnjrOca7klX3xfjb72Cf4e1xf54i/51hq3pQg
# pWwPjKnCGEnTUEg2/zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEG4yZ/fhHpm0R5EiOeL1tZAwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFPWFmIj88Uhjfd4joMKYU/QCLkFtMA0GCSqGSIb3DQEBAQUABIIBAICpNYMr
# OrTVDKtSn6rtGosUdPtDkz8AHmZJjcWugqi4bWI7BDgH0h/kADWdlDZFtQzEUFlW
# 9fETPuHIrO6E9rslCa6JN0WbQGhX17NytRtpdAKuHGU68DrcUcTedkupwE6nxuIn
# i6G9oVwqghoOXLoWOb22cwt4gIhGX2pLz38ip9iaXAKXJ7YIyQDnu4gJaxWy7E03
# AMoRfwEAor0/ZNbzzf4ykXLCwfM2YzfqmcJ8RYhiqDSq8mvTjnHfeuz2/aGjtkBx
# OUKdtVDXcCxcyia64cx259OH5qn8mD/HaOVxZuvha9ivBKW5MUtNGs0kdcdy7KqQ
# pVVw0wQM1kakDcg=
# SIG # End signature block
