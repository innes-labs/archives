Function Get-PncDomainsAndTargets {
<#
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve domains and targets of each domain.
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve domains and targets of each domain.
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell object describing the domains and its targets
Example of object formated in JSON :
{
     "countDomain":  1,
     "countTarget":  2,
     "domains":  [
         {
             "Name":  "domain1",
             "countTarget":  2,
             "targets":  [
                 {
                     "label":  "target 1",
                     "targetId":  "30-9c-23-1e-d8-1b",
                     "modelFamily":  "nt_iaxx-1",
                     "middlewareFamily":  "gekkota-4",
                     "targetIdType":  "mac",
                      "info":  {
                          "date-status":  "2019-05-15T09:18:26.598Z",
                          "mac":  "30-9c-23-1e-d8-1b",
                          "hostname":  "innes-sw36",
                          "uuid":  "00000000-0000-0000-0001-309c231ed81b",
                          "modelName":  "nt_ia32",
                          "modelNumber":  "4.10.10",
                          "serialNumber":  "",
                              "middleware":  "gekkota-4",
                           "ip-addresses":  [
                                {
                                    "origin":  "auto",
                                        "value":  "fc00::d47a:b234:cee4:1a3/64",
                                    "if-type":  "LAN"
                                },
                                ...
                           ]
                     }
                 }
                 ...
             ]
         }
          ...
}
.EXAMPLE
Get-PncDomainsAndTargets -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION: 1.10.10
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost = $(throw "Please enter the Plugncast G3 host (IP or DNS domain"),
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"

# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve configuration for Plugncast G3 server `"$server`"")

 
 

# Configuration object
$configObject = [PSCustomObject]@{
    countDomain = 0;
    countTarget = 0;
}
[System.Collections.ArrayList]$domainsArray = @()

# List domain Ids
$Body = @{
    target = "nsIAppliDomains.listIds"
}
$JsonBody = $Body | ConvertTo-Json
Start-Sleep -m $SleepDurationBeforeCommand

function Storage {
    param (
        [string] $total,
        [string] $used
    )
    $t = [int64]$total
    $u = [int64]$used

    switch ($t) {
        { $_ -gt 1tb } 
        { "{0:n2}/{1:n2} Tio" -f ($u/1tb),($_ / 1tb); break }
        { $_ -gt 1gb } 
        { "{0:n2}/{1:n2} Gio" -f ($u/1gb),($_ / 1gb); break }
        { $_ -gt 1mb } 
        { "{0:n2}/{1:n2} Mio" -f ($u/1mb),($_ / 1mb); break }
        { $_ -gt 1kb } 
        { "{0:n2}/{1:n2} Kio" -f ($u/1kb),($_ / 1kb); break }
        default  
        { "{0}/{1} o" -f $u,$_; break }
    }      

}
function RetrieveStatus {
    param (
        [System.Xml.XmlElement] $status,
        [PSCustomObject] $info
    )
    foreach ($child in $status.ChildNodes) {
        $name = $child.ToString()
        $value = $child.InnerText
        if ($name -eq "date-status" ) {
            $info | Add-Member -MemberType NoteProperty -Name $name -Value $value | Out-Null
        }
        elseif ($name -eq "device-status" ) {
            $device = $child.device;
            $info |  Add-Member -MemberType NoteProperty -Name "mac" -Value $device.mac | Out-Null | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "hostname" -Value $device.hostname | Out-Null | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "uuid" -Value $device.uuid | Out-Null | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "modelName" -Value $device.modelName | Out-Null | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "modelNumber" -Value $device.modelNumber | Out-Null | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "serialNumber" -Value $device.serialNumber | Out-Null | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "middleware" -Value $device.middleware | Out-Null | Out-Null
            [System.Collections.ArrayList]$ips = @()
            $ip_addresses = $device."ip-addresses"
            foreach ($ip in $ip_addresses.ChildNodes) {
                $ips.Add(@{
                    "if-type" = $ip."if-type"
                    origin = $ip.origin
                    value = $ip.value
                }) | Out-Null
            }
            $info | Add-Member -MemberType NoteProperty -Name "ip-addresses" -Value $ips | Out-Null
            $status = $child.status
            $storage = $status.storage
            $str = Storage $storage.total.InnerText $storage.used.InnerText
            $info |  Add-Member -MemberType NoteProperty -Name "storage" -Value $str | Out-Null | Out-Null
            $launcher = $status.launcher
            $info |  Add-Member -MemberType NoteProperty -Name "state" -Value $launcher.state | Out-Null | Out-Null
            $powermanager = $launcher."power-manager"
            if ($powermanager)
            {
                $level = $powermanager.level
                $info |  Add-Member -MemberType NoteProperty -Name "power-manager-level" -Value $powermanager.level | Out-Null | Out-Null
            }

        }
        
    }
    
}
try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}
$DomainsJson = $ExecutedRequest | ConvertFrom-Json
$configObject.countDomain = $DomainsJson.Length
foreach ($domain in $DomainsJson) {
    $domainObject = [PSCustomObject]@{
        Name = $domain
    }
    [System.Collections.ArrayList]$targetsArray = @()
    $Body = "declare namespace targets = `"ns.innes.plugncast.cms.targets`";targets:getAll()"
    try {
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/xquery' -Uri $BaseServerUri".domains/"$domain"/.db/cmsdb"   -Body $Body
        [xml]$result = [xml]$ExecutedRequest
        [System.Xml.XmlElement] $root = $result.get_DocumentElement()
        foreach ($targetNode in $root.ChildNodes) {
            $target = @{}
            foreach ($child in $targetNode.ChildNodes) {
                $name = $child.ToString()
                $value = $child.InnerText
                if ($name -eq "modelFamily" ) {
                    $target.Add("modelFamily", $value) | Out-Null
                }
                elseif ($name -eq "targetIdType" ) {
                    $target.Add("targetIdType", $value) | Out-Null
                }
                elseif ($name -eq "targetId" ) {
                    $target.Add("targetId", $value) | Out-Null
                }     
                elseif ($name -eq "label" ) {
                    $target.Add("label", $value) | Out-Null
                }      
                elseif ($name -eq "middlewareFamily" ) {
                    $target.Add("middlewareFamily", $value) | Out-Null
                }      
            }
            if ($target.Count -ne 0)
            {
                $targetsArray.Add([PSCustomObject]$target) | Out-Null
                $configObject.countTarget++
            }
        }
        $domainObject | Add-Member -MemberType NoteProperty -Name countTarget -Value $targetsArray.Count | Out-Null
        if ($targetsArray.Count -gt 0)
        {
            $domainObject | Add-Member -MemberType NoteProperty -Name targets -Value $targetsArray | Out-Null
        }
        

    }
    catch {
        LogWrite( "Exception during request" )
        LogWrite( ($_.Exception).ToString().Trim() )
        LogWrite( ($_.Exception.Message).ToString().Trim() )
        throw "Exception during request"
    } 
    $Body = "declare namespace pncf = `"ns.innes.plugncast.frontals`";pncf:getRegisteredDevicesWithStatus()"
    try {
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/xquery' -Uri $BaseServerUri".domains/"$domain"/.db/frontalsdb"   -Body $Body
        [xml]$result = [xml]$ExecutedRequest
        #$str = WriteXml $result
        [System.Xml.XmlElement] $root = $result.get_DocumentElement()

        foreach ($target in $root.ChildNodes) {
            $targetInfo = [PSCustomObject]@{}
            $id = $null
            foreach ($child in $target.ChildNodes) {
                $name = $child.ToString()
                $value = $child.InnerText
                if ($name -eq "id") {
                    $id = $value
                }
                elseif ($name -eq "phantom") {
                    $targetInfo | Add-Member -MemberType NoteProperty -Name $name -Value $value | Out-Null
                }
                elseif ($name -eq "registered") {
                    $targetInfo | Add-Member -MemberType NoteProperty -Name $name -Value $value | Out-Null
                }
                elseif ($name -eq "status") {
                    RetrieveStatus $child $targetInfo
                }
            }
            foreach ($target in $targetsArray) {
                if ($target.targetId -eq $id)
                {
                    if (!$target.info) {
                        $target | Add-Member -MemberType NoteProperty -Name info -Value $targetInfo | Out-Null
                    }
                }
            }
        }
    }
    catch {
        LogWrite( "Exception during request" )
        LogWrite( ($_.Exception).ToString().Trim() )
        LogWrite( ($_.Exception.Message).ToString().Trim() )
        throw "Exception during request"
    } 
    $domainsArray.Add($domainObject) | Out-Null
}
$configObject | Add-Member -MemberType NoteProperty -Name domains -Value $domainsArray | Out-Null
LogWrite($configObject | ConvertTo-Json -Depth 10)
$configObject
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU6W2eRnrMeyENCMlnZQiNhDFT
# UpWgggP3MIID8zCCAtugAwIBAgIQbjJn9+EembRHkSI54vW1kDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MDYxNTIxMDQxMVoXDTIxMDYxNTIxMjQxMVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMkLknOb
# gzuOct1REel+1YdZhKrssnRqS4ckl0g3CKwRWqFBoLfLSPsfUZZlkP6ZSBnCG2GR
# 0m/894NizxWtfC/iVWCrDkGDYmyryEMNt4vYjWz6Om80HdgtQuAOPkLtOpBW5w2A
# 9DTXRoJ281i34Zo+jklCJUIUZmBnZ9Rj62ypgdt1J3KDKz1b5G0iGlqhYFkCL4Oo
# oO105hcGtGzVfaBPGQDBH+RMZQRuwmrcQGUZK/44S+Iyabb0xdz7ynY/L1aky+Vu
# Eo6jS5sOUWha1c15ypqrZwUvPs4SOaduONnLLho79MruWfyUq71O9MvLybg3NZXZ
# nEQtMg1moPZNf3UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQWaf+95kU3tj7YNirXKqWk7v2uTzANBgkqhkiG9w0BAQsFAAOCAQEALypb
# JpyJ1MsXs/keY9t39RwM+gOSZvr79JlqAddrssVj0HDh2mUcklndTzwz0UkUK/zn
# 20hUySTZpzw/y3Ov022OmA0ccAlhffX72KsL2oJL/ncz7voxBqc9iIq9QNYgEa12
# KindV+VbTuoD0jBmr05fvBgg89P90qwXsZBmzbVmOuxFoudF9r5MH8H6WDFOYAXo
# 8jle3JKcVdzQNazjeOJQismwoyaOeuu9VY8xIC2oeEuE4dJV/rBbJ5f4GaLln/Ht
# 5vsZ5BXxx6YJ+BgFxI01YDgF9VHqnjrOca7klX3xfjb72Cf4e1xf54i/51hq3pQg
# pWwPjKnCGEnTUEg2/zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEG4yZ/fhHpm0R5EiOeL1tZAwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFFKop/u+zTY9/0NhuKRHK8EOYHBRMA0GCSqGSIb3DQEBAQUABIIBALb2URgS
# ru9rLRTw6+P7l1yyjCyNkt7DqPxMQ+udFZbrHRb2vbXg2YGre4kJX53lpw7QU+Me
# HYc9GdE1H4LYRhm0OgLCQXvXmL7n0ceKU0Lhh7k+TdmiPUBJErpnoLr4RXo6gQHU
# QVp5Hhknlb3LGiqZtrkkOz5NjfOClUP3oANL/SPwZEF9UMmEICbnvUp3AVh8PjE5
# oqKeyznwsaUpI2IYeUiE0VXaxdNE63P9mjFxVZwN/jfoz52EYc7GMylxhjaoFpw2
# +mdM0br4XX5USL3tWD/h25lP9xAkRF18FNeu4HpLgZMrf0GQMGhXW9PhbDB+Tz3F
# xXsxs83uTQqDOlo=
# SIG # End signature block
