Function Get-PncAppiDomainAssociation {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the domains of an APPI
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the domains of an APPI
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER appi
The name of appi (playzilla) or identificator of appi (urn:innes:system-app#playzilla)
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell object that describes the domains of the APPI
Example of object formated in JSON :
{
    "nbDomains":  1,
    "domains":  [
                    {
                        "name":  "domain1",
                        "version":  null,
                        "nbLicenses":  9,
                        "licenses":  [ ... ]
                    }
    ]
}
.EXAMPLE
Get-PncAppiDomainAssociation -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [Parameter(Mandatory=$true)]
    [string] $appi,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$urn = "urn:innes:system-app#"
if (!$appi.StartsWith($urn))
{
    $appi = $urn + $appi
}

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve domains of APPI `"$appi`" for server `"$server`"")

 

$Body = @{
    target = "nsIAppliAppis.get"
}
[System.Collections.ArrayList]$argsArray = @()
$argsArray.Add($appi) | Out-Null
$Body | Add-Member -MemberType NoteProperty -Name args -Value $argsArray | Out-Null
$JsonBody = $Body | ConvertTo-Json

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}
$appiObject = $ExecutedRequest | ConvertFrom-Json
$result = [PSCustomObject]@{
    nbDomains = 0
}
$unsetDomain = "@unset@"
$domainsLicensesMap = [PSCustomObject]@{}
foreach ($prop in $appiObject.licenses.PsObject.Properties)
{
    $psn = $prop.Name;
    $license = $prop.Value
    $domain = $license.domain
    $l = [PSCustomObject]@{
        psn = $psn
        expired = $license.expired
        label = $license.label
        valid = $license.valid
        license = $license.license
    }
    if ($license.PSObject.Properties['expireDate'])
    {
        $l  | Add-Member -MemberType NoteProperty -Name expireDate -Value $license.expireDate | Out-Null
    }
    if (!$domain)
    {
        $domain = $unsetDomain
    }
    $d = $domainsLicensesMap.$domain
    if (!$d)
    {
        $d = [PSCustomObject]@{nbLicenses = 1}
        [System.Collections.ArrayList]$licenses = @()
        $licenses.Add($l) | Out-Null
        $d | Add-Member -MemberType NoteProperty -Name licenses -Value $licenses | Out-Null
        $domainsLicensesMap | Add-Member -MemberType NoteProperty -Name $domain -Value $d | Out-Null
    }
    else {
        $d.nbLicenses++
        $d.licenses.Add($l) | Out-Null
    }
}
$domainsVersionsMap = [PSCustomObject]@{}
foreach ($prop in $appiObject.versions.PsObject.Properties)
{
    $version = $prop.Name;
    $obj = $prop.Value
    foreach ($domain in $obj.domains) {
        $d = $domainsVersionsMap.$domain
        if (!$d) {
            $d = [PSCustomObject]@{}
            [System.Collections.ArrayList]$versions = @()
            $versions.Add($version) | Out-Null
            $d | Add-Member -MemberType NoteProperty -Name versions -Value $versions | Out-Null
            $domainsVersionsMap | Add-Member -MemberType NoteProperty -Name $domain -Value $d | Out-Null
        }
        else {
            $d.versions.Add($l) | Out-Null
        }
    }
}
[System.Collections.ArrayList]$domainArray = @()
foreach ($prop in $appiObject.domains.PsObject.Properties)
{
        $result.nbDomains += 1
        $name = $prop.Name
        $domain = $prop.Value
        $d = [PSCustomObject]@{
            name = $name
            version = $domain.version
        }
        if ($domainsLicensesMap.$name)
        {
            $d | Add-Member -MemberType NoteProperty -Name nbLicenses -Value $domainsLicensesMap.$name.nbLicenses | Out-Null
            $d | Add-Member -MemberType NoteProperty -Name licenses -Value $domainsLicensesMap.$name.licenses | Out-Null
        }
        else {
            $d | Add-Member -MemberType NoteProperty -Name nbLicenses -Value 0 | Out-Null
        }
        $domainArray.Add($d) | Out-Null
}
$result | Add-Member -MemberType NoteProperty -Name domains -Value $domainArray | Out-Null
if ($domainsLicensesMap.$unsetDomain)
{
    $result | Add-Member -MemberType NoteProperty -Name nbUnusedLicenses -Value $domainsLicensesMap.$unsetDomain.nbLicenses | Out-Null
    $result | Add-Member -MemberType NoteProperty -Name unusedLicenses -Value $domainsLicensesMap.$unsetDomain.licenses | Out-Null
}
else {
    $result | Add-Member -MemberType NoteProperty -Name nbUnusedLicenses -Value 0 | Out-Null
}
LogWrite($result | ConvertTo-Json -Depth 5)
$result 
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUb8c9OvYxQmbZ33WvKj+U8lNs
# VjigggP3MIID8zCCAtugAwIBAgIQbjJn9+EembRHkSI54vW1kDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MDYxNTIxMDQxMVoXDTIxMDYxNTIxMjQxMVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMkLknOb
# gzuOct1REel+1YdZhKrssnRqS4ckl0g3CKwRWqFBoLfLSPsfUZZlkP6ZSBnCG2GR
# 0m/894NizxWtfC/iVWCrDkGDYmyryEMNt4vYjWz6Om80HdgtQuAOPkLtOpBW5w2A
# 9DTXRoJ281i34Zo+jklCJUIUZmBnZ9Rj62ypgdt1J3KDKz1b5G0iGlqhYFkCL4Oo
# oO105hcGtGzVfaBPGQDBH+RMZQRuwmrcQGUZK/44S+Iyabb0xdz7ynY/L1aky+Vu
# Eo6jS5sOUWha1c15ypqrZwUvPs4SOaduONnLLho79MruWfyUq71O9MvLybg3NZXZ
# nEQtMg1moPZNf3UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQWaf+95kU3tj7YNirXKqWk7v2uTzANBgkqhkiG9w0BAQsFAAOCAQEALypb
# JpyJ1MsXs/keY9t39RwM+gOSZvr79JlqAddrssVj0HDh2mUcklndTzwz0UkUK/zn
# 20hUySTZpzw/y3Ov022OmA0ccAlhffX72KsL2oJL/ncz7voxBqc9iIq9QNYgEa12
# KindV+VbTuoD0jBmr05fvBgg89P90qwXsZBmzbVmOuxFoudF9r5MH8H6WDFOYAXo
# 8jle3JKcVdzQNazjeOJQismwoyaOeuu9VY8xIC2oeEuE4dJV/rBbJ5f4GaLln/Ht
# 5vsZ5BXxx6YJ+BgFxI01YDgF9VHqnjrOca7klX3xfjb72Cf4e1xf54i/51hq3pQg
# pWwPjKnCGEnTUEg2/zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEG4yZ/fhHpm0R5EiOeL1tZAwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFPHG4BTYkBUwXGkUwOpAS1r5RYD6MA0GCSqGSIb3DQEBAQUABIIBAK1lKO/b
# HRo5q+iJ8o0CDHjQ8DlZmeNzJvEJJt84kwhMsNr51bGPUVCr2beA3O2s+36by4w8
# a5EwyiQ0jFV05Dh4K2oFw4ip+wgZ6zQWgUMwatt+YbkbXgtp0aSfW7ca741fWqH2
# vJ4d5aOH1N1Y5Si+DMnMa0KmsC825xprxWFGqWn07MhPojHipJK5uFBGXyMQ3nSP
# nHmL0ucBALvinzkDQAIA3RBaVbIJbluuHWddyw5rWHsqxzTVLADYfE2Cr3fZz5TB
# 74tRyV9PZHKTxJc24QW0nAk2Qrs/UCeOrLSYTbvcoTogwxfXAL5p1Fd1qKKYeKCD
# jBpKgfwXdN+g+tA=
# SIG # End signature block
