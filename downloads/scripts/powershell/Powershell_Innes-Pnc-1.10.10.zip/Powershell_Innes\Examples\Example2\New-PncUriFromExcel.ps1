<#
.SYNOPSIS
   PlugnCast : .URI generator from MS-Excel
.DESCRIPTION
  Requires the installation of the PSExcel Powershell module:
  Launch a Powershell console with administrator user and type
   > Install-Module -Name PSExcel

  MS-Excel format : 
  id	name	scheme	address	    port	thumbnail
  1	    TF1	    udp://	225.1.1.1	1234	./assets/tf1.png
.PARAMETER excelFileList
The list of MS-Excel file path (absolute or relative) describing the .URI files to generate.
.PARAMETER outputDirectory
The directory containing the generated URI files (default "./output")
.EXAMPLE
New-UriFromExcel.ps1 channels.xlsx
#>
 
[CmdletBinding()]
Param
(
    [string[]] $excelFileList = "./channels.xlsx",
    [string] $outputDirectory = "./output"
)

Begin
{
    $verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
    Import-Module PSPnc   
    Import-Module PSExcel
    function Write-UriFile {
        param (
            [Parameter(Mandatory = $True, ValueFromPipeline = $true)]
            [Object[]] $in,

            [Parameter(Mandatory = $true)]
            [String] $filename
        ) 
        process {
                
            $_filename1 = $filename.Split([IO.Path]::GetInvalidFileNameChars()) -join '_'
            $_filename = "./output/" + $_filename1 + ".uri"
            add-content -path $_filename $in
        }
    }
    function New-UriFromExcelFile($path){
        $datas = Import-XLSX -RowStart 1  -Path $path
        foreach($data in $datas ){
            $uri =  "{0}{1}:{2}" -f $data.scheme, $data.address, $data.port
            $thumbnail = $data.thumbnail
            if ($thumbnail.Contains("/"))
            {
                $thumbnail = $thumbnail.Replace("/", "`\");
            }
            if ($thumbnail.StartsWith("."))
            {
                $thumbnail = [string] (Get-Location) + "\" + $thumbnail
            }
            $tokens= @{IMG= $img; CATEGORY= 'IPTV'; TITLE=$data.name ; URI=$uri}
            New-PncUri -uri $uri -thumbnail $thumbnail -title $data.name -category 'IPTV' -vb:$verbose `
               | Write-UriFile -filename $data.name 
        }
    }     
}


Process
{
    foreach($n in $excelFileList){
        $PSDefaultParameterValues['*:Encoding'] = 'utf8'
        if (Test-Path $outputDirectory) {
            Remove-Item -Path $outputDirectory/*.uri -Force
        }
        else {
            New-Item -ItemType Directory -Force -Path $outputDirectory
        }
        $path = (resolve-path $n).Path
        Write-Verbose "Converting $path"
        New-UriFromExcelFile -path $path
        Write-Verbose "End of Job"
    }
}
End
{
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUkSVFMt0iKwQeD/ZqASggJ56x
# x3+gggP3MIID8zCCAtugAwIBAgIQbjJn9+EembRHkSI54vW1kDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MDYxNTIxMDQxMVoXDTIxMDYxNTIxMjQxMVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMkLknOb
# gzuOct1REel+1YdZhKrssnRqS4ckl0g3CKwRWqFBoLfLSPsfUZZlkP6ZSBnCG2GR
# 0m/894NizxWtfC/iVWCrDkGDYmyryEMNt4vYjWz6Om80HdgtQuAOPkLtOpBW5w2A
# 9DTXRoJ281i34Zo+jklCJUIUZmBnZ9Rj62ypgdt1J3KDKz1b5G0iGlqhYFkCL4Oo
# oO105hcGtGzVfaBPGQDBH+RMZQRuwmrcQGUZK/44S+Iyabb0xdz7ynY/L1aky+Vu
# Eo6jS5sOUWha1c15ypqrZwUvPs4SOaduONnLLho79MruWfyUq71O9MvLybg3NZXZ
# nEQtMg1moPZNf3UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQWaf+95kU3tj7YNirXKqWk7v2uTzANBgkqhkiG9w0BAQsFAAOCAQEALypb
# JpyJ1MsXs/keY9t39RwM+gOSZvr79JlqAddrssVj0HDh2mUcklndTzwz0UkUK/zn
# 20hUySTZpzw/y3Ov022OmA0ccAlhffX72KsL2oJL/ncz7voxBqc9iIq9QNYgEa12
# KindV+VbTuoD0jBmr05fvBgg89P90qwXsZBmzbVmOuxFoudF9r5MH8H6WDFOYAXo
# 8jle3JKcVdzQNazjeOJQismwoyaOeuu9VY8xIC2oeEuE4dJV/rBbJ5f4GaLln/Ht
# 5vsZ5BXxx6YJ+BgFxI01YDgF9VHqnjrOca7klX3xfjb72Cf4e1xf54i/51hq3pQg
# pWwPjKnCGEnTUEg2/zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEG4yZ/fhHpm0R5EiOeL1tZAwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFJtYJ6UjC2d+lYzWgTS+MXb5/PLLMA0GCSqGSIb3DQEBAQUABIIBAGAP019D
# RN/+ptPt8yjOZKzitVAC2B2qWXUuQR+blQDtkWAdzbt9WFBFn8KV+9WG9b8MXEkt
# 1Oh8RNEDqt0ns3byH8wuFOpOFu3eJbzxbRv+HQC7tqJyY7nWTI7MvJratG22oHYx
# Nqe7MeUp5DqUjyxorvIvD1+PTI1vXA4/Ixl9Ra+7YtAbBKSAVl3G1NHJhjitFQoL
# 6cZM7kewjnJwYPT/d9Vetpi4hOGl9oM6SJiCB2e9Z5L3agMytcgg6rcD/A4mPEJT
# IiIwyk69GVL3XLA9eVm4zy7gu/Zr9ieFWr+DqLT3ESzn1BK0zeDRm+6u/fq8tooO
# 4CvxJ/r7mhiu+7I=
# SIG # End signature block
