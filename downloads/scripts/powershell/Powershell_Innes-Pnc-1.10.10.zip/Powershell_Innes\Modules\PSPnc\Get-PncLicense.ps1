Function Get-PncLicense {
<#
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the Plugncast server licenses.
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the Plugncast server licenses.
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell object describing license.
Example of object formated in JSON :
{
    "mail":  "mail@domain.com",
    "psn":  "PSN00780-00000 CD9",
    "licenses":  {
         "numberDevices":  "unlimited",
         "numberDomains":  51,
         "valid":  true,
         "licenses":  {
            "PSN00160-00180 CD7":  {
                  "psn":  "PSN00160-00000 CD7",
                 "isCore":  false,
                 "numberDevices":  "unlimited",
                  "numberDomains":  10,
                 "label":  "plugncast domain",
                 "valid":  true,
                 "license":  "xxxx - xxxx - xxxx - xxxx - xxxxx",
                 "expired":  false
            }
        }
    }
}
.EXAMPLE
Get-PncVersion -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION: 1.10.10
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost = $(throw "Please enter the Plugncast G3 host (IP or DNS domain"),
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"

# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name
$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve the Plugncast licenses for server `"$server`"")

$Body = @{
    target = "nsIAppliLicenses.list"
}
$JsonBody = $Body | ConvertTo-Json
Start-Sleep -m $SleepDurationBeforeCommand

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}

$LicensesObject = $ExecutedRequest | ConvertFrom-Json

$Body = @{
    target = "nsIAppliLicenses.mail"
}
$JsonBody = $Body | ConvertTo-Json
try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}
$mail = $ExecutedRequest | ConvertFrom-Json
$Body = @{
    target = "nsIAppliLicenses.psn"
}
$JsonBody = $Body | ConvertTo-Json
try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}
$psn = $ExecutedRequest | ConvertFrom-Json
$resultObject=[PSCustomObject]@{
    mail= $mail;
    psn = $psn;
    licenses = $LicensesObject
}
LogWrite($resultObject | ConvertTo-Json -Depth 5)
$resultObject

}


# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUxTdTUTj/lKTIZl5zr1dtWm4b
# kMmgggP3MIID8zCCAtugAwIBAgIQbjJn9+EembRHkSI54vW1kDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MDYxNTIxMDQxMVoXDTIxMDYxNTIxMjQxMVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMkLknOb
# gzuOct1REel+1YdZhKrssnRqS4ckl0g3CKwRWqFBoLfLSPsfUZZlkP6ZSBnCG2GR
# 0m/894NizxWtfC/iVWCrDkGDYmyryEMNt4vYjWz6Om80HdgtQuAOPkLtOpBW5w2A
# 9DTXRoJ281i34Zo+jklCJUIUZmBnZ9Rj62ypgdt1J3KDKz1b5G0iGlqhYFkCL4Oo
# oO105hcGtGzVfaBPGQDBH+RMZQRuwmrcQGUZK/44S+Iyabb0xdz7ynY/L1aky+Vu
# Eo6jS5sOUWha1c15ypqrZwUvPs4SOaduONnLLho79MruWfyUq71O9MvLybg3NZXZ
# nEQtMg1moPZNf3UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQWaf+95kU3tj7YNirXKqWk7v2uTzANBgkqhkiG9w0BAQsFAAOCAQEALypb
# JpyJ1MsXs/keY9t39RwM+gOSZvr79JlqAddrssVj0HDh2mUcklndTzwz0UkUK/zn
# 20hUySTZpzw/y3Ov022OmA0ccAlhffX72KsL2oJL/ncz7voxBqc9iIq9QNYgEa12
# KindV+VbTuoD0jBmr05fvBgg89P90qwXsZBmzbVmOuxFoudF9r5MH8H6WDFOYAXo
# 8jle3JKcVdzQNazjeOJQismwoyaOeuu9VY8xIC2oeEuE4dJV/rBbJ5f4GaLln/Ht
# 5vsZ5BXxx6YJ+BgFxI01YDgF9VHqnjrOca7klX3xfjb72Cf4e1xf54i/51hq3pQg
# pWwPjKnCGEnTUEg2/zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEG4yZ/fhHpm0R5EiOeL1tZAwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFNiMSOxWu6NO/AH+dGnzAQDFTcySMA0GCSqGSIb3DQEBAQUABIIBABj/TUhr
# Cf202yIlVB0+YmmgxezxGt3Df6q4r9vrxetSX3R4CEqSwfraEksbTJ0nyi3Z9zpJ
# ckmodm2Hbc0XWM93H0GzE+Fkmb6scIjz9Yf1PuSRJirf/ItjZBN/8wfuKDd8sosB
# Ct8ie/m6P5RQ3TRIM+lRzgKPDvmetWM32plFcHT1ceCdJ69q+lkzlp4N5EI8p4aR
# brw14EBJHTQtnum7fQqFkj6iaxCposGLqVgz6zEXokNFq8wK00Zz83zh95Y+ohLY
# tOGO/f4OIb8GJVMIIJBInenT0+v7KAl4Gkeuf/i6SRpUu988syCdMv4bBQvaZVBa
# MMW1ma9+V4LlAFM=
# SIG # End signature block
