Function Get-PncContentModelInstalled {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the installed models
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the installed models
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER domainList
The list of domains involved in the installation. Use "all" for all domains (default)
.PARAMETER lang
The description language of the model ("en-US", "fr-FR", ...). "x-default" by default
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell array of installed models.
Example of object formated in JSON :
[
    {
        "domain":  "domain1"
        "models":  [
            {
               "title":  "title 1",
               "version":  "1.20.10",
               "format":  "16/9",
               "description":  "Description 1",
               "category":  "Category 1",
               "file":  "model1.mask.maff"
            }
        ],
    },
    {
        "domain":  "domain2"
        "models":  [
            {
                 "title":  "title 2",
                "version":  "1.10.12",
                 "format":  "16/9",
                 "description":  "Description 2",
                 "category":  "Category 2",
                 "file":  "model2.mask.maff"
             },
             ...
        ],
    }
]
.EXAMPLE
Get-PncContentModelInstalled -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
Retrieve all models installed
.EXAMPLE
Get-PncContentModelInstalled -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin -domainList domain1
Retrieve models installed on domain "domain1"
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [string[]] $domainList = "all",
    [string] $lang = "x-default",
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
$ServerUri = "https://$Server"

# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve models for server `"$server`"")

 
# List of domains
$configObject = Get-PncDomainsAndTargets $server -logFile "none" -UrlLogin $UrlLogin -UrlPassword $UrlPassword
function GetModels {
    param (
        [string] $domain
    )
    $Body = "<D:propfind xmlns:D=`"DAV:`" xmlns:ias=`"ns.innes.appli.server`"><D:prop><D:getcontenttype/></D:prop><D:prop><D:getcontentlength/></D:prop><D:prop><D:getlastmodified/></D:prop><D:prop><D:getetag/></D:prop><D:prop><D:id/></D:prop><D:prop><D:resourcetype/></D:prop><D:prop><D:owner/></D:prop><D:prop><D:current-user-privilege-set/></D:prop><D:prop><ias:hidden-resources/></D:prop></D:propfind>"
    $Headers = @{
        DEPTH = "1"
        "X-HTTP-METHOD-OVERRIDE" = "PROPFIND"
    }
    Start-Sleep -m $SleepDurationBeforeCommand
    $BaseUri = "/.plugncast/.domains/" + $domain
    try {
        $Uri = $ServerUri + $BaseUri + "/.domain-repository/.models/.medias/"
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'text/xml' -Uri $Uri   -Body $Body -Headers $Headers
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw $_.Exception
    }
    [xml]$result = [xml]$ExecutedRequest
    [System.Xml.XmlElement] $root = $result.get_DocumentElement()
    [System.Collections.ArrayList]$uris =@();
    foreach ($response in $root.ChildNodes) {
        foreach ($child in $response.ChildNodes) {
            $name = $child.ToString()
            $value = $child.InnerText
            if ($name -eq "href")
            {
                if ($value.EndsWith(".mask.maff") -or $value.EndsWith(".mask.uri"))
                {
                    $value = $value.Substring($BaseUri.Length+1);
                    $uris.Add($value) | Out-Null
                }
            }
        }
    }
    $Body = "declare namespace im = `"ns.innes.metadata`";im:getDescriptions(("
    for ($i = 0; $i -lt $uris.Count; $i++)
    {
        $Body += "`"" + $uris[$i] + "`""
        if ($i -ne $uris.Count -1)
        {
            $Body += ","
        }
    }
    $Body += "))"
    try {
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/xquery' -Uri $BaseServerUri".domains/"$domain"/.db/metadatadb"   -Body $Body
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw $_.Exception
    }
    $enc = [System.Text.Encoding]::UTF8
    $bytes = $enc.GetBytes($ExecutedRequest.Content)
    $content = $enc.GetString($bytes)
    [xml]$result = [xml]$content
    [System.Xml.XmlElement] $root = $result.get_DocumentElement()

    [PSCustomObject]$Namespace = @{rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
     xmp="http://ns.adobe.com/xap/1.0/"
     xmpMM="http://ns.adobe.com/xap/1.0/mm/"
      stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#"
      xmpGImg="http://ns.adobe.com/xap/1.0/g/img/"
      dc="http://purl.org/dc/elements/1.1/"
      Iptc4xmpExt="http://iptc.org/std/Iptc4xmpExt/2008-02-29/"
      im="ns.innes.metadata"
      xml="http://www.w3.org/XML/1998/namespace"
      xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/"}
    $ns = New-Object System.Xml.XmlNamespaceManager($result.NameTable)
    foreach ($key in $Namespace.keys) {
        $ns.AddNamespace($key, $Namespace[$key])
    }
    [System.Collections.ArrayList]$models =@()
    foreach ($description in $root.ChildNodes) {
        $file = $description.about
        $index = $file.LastIndexOf("/");
        $file = $file.Substring($index + 1);
        $metadata = $description.EmbeddedMetadata
        $res = $metadata.SelectSingleNode("im:category//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
        $category = $res.InnerText
        $res = $metadata.SelectSingleNode("dc:title//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
        if ($res) {
            $title = $res.InnerText
        }
        else {
            $title = ""
        }
        $res = $metadata.SelectSingleNode("dc:description//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
        if ($res) {
            $description = $res.InnerText
        }
        else {
            $description = ""
        }
        if ($metadata.videoDisplayAspectRatioCategory) {
            $format = $metadata.videoDisplayAspectRatioCategory
        }
        else {
            $format = ""
        }
        $metadatas = @{
            file = $file
            version     = $metadata.VersionID
            format      = $format
            category    = $category
            title       = $title
            description = $description
        }
        $models.Add($metadatas) | Out-Null
    }
    return ,$models
}
[System.Collections.ArrayList]$domainModels =@()
foreach ($domain in $configObject.domains) {
    if (($domainList -eq "all") -or ($domainList -contains $domain.Name)) {
        $models = GetModels $domain.Name
        if ($models.Count -ne 0)
        {
            [PSCustomObject]$obj = @{
                domain = $domain.Name
                models = $models
            }
            $domainModels.Add($obj) | Out-Null
        }
    }
}
LogWrite(,$domainModels | ConvertTo-Json -Depth 5)
,$domainModels
}






# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU2zgBYG0ym7Q8nDNgTX3AKLpv
# DTmgggP3MIID8zCCAtugAwIBAgIQU/V6m/Alt7lMVarmvFCglzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MDYxNzEwMDIyNFoXDTIxMDYxNzEwMjIyNFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALfI/UTC
# OwdA3Kt/4f4bKaVXBKju2pU2a3eXquHDK7k98nigIIeblK9uByYwVX5C6TvBlIHl
# ZIi+q9Al4dGvvKdOzR5/hh1T1wvEgI/UuUfxEo+VO2ltycXJ++nl6KYDx+bj1GSs
# EG4/y4Bh94GD03Krr9xv2qpC2zHrqhXUFnIHp6IfWl3nkM5bnRtUm7Nj9UeaedAk
# uhL5SKTjpsrN4ePOwQodMFV3JJZacJiXlHMwoyziOEW0cGoHgCJ4yVkM8ZBmkTmQ
# avi22eRmp/mTuzOo9QAcz+N2CFX2zYNMSBuNekyAxleHxU7DzN1IJM63kkFenGZN
# 5lQbTWlN420UV8UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQWbiWvlbDA8RikmCU2TGfm4VpdeTANBgkqhkiG9w0BAQsFAAOCAQEAEKd/
# BplG/wTEr1U0vb1nEeNWNqEgGH+FygZsGyuESX4iv8LYtDcXtZvFiPcb3HuauAJo
# zVoUSlLDnWZnMibkzeiA7TFDyb62eo/qbKer0FfijzyGShE0WxKiypp6dDaOYVPC
# 6PfVgUamQ/Ym6K4LmbcbMluU9hxmK0F1lJqE1xCw/pW16D6sdWxJfeT65lubmTSG
# cpdBnVqhUTTs1wYtC2xPB8tdNnKsFW2CKlOQQikEF8zSZVX0f8KYhdBD5GDzWNTn
# CciNETjuNUMIB+8/MmPWBOJrvZLo8BoBKfpgONrtgUouCnzuUr1Dd+9nTW5hk+89
# 3n5qYp7r1bsVD3fm9zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFP1epvwJbe5TFWq5rxQoJcwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFL4S4DxHaYRZv2+3B4lErNg0cPPxMA0GCSqGSIb3DQEBAQUABIIBAKHHUuuz
# Vwt1xwqwBvNOwzajGuhlZ/eZNYcyYa+OaaGwI4spWTzclHTe7Q+QIfqZvaaTZmkg
# zHbMHBT7vfJ9NwmIz8xvm6sUdBWYiQ5T430bm474+RBtroQHva3MMLvE/0JzLBmI
# kmme+Pye5Eqb5LKHKvenNfGeoKrdbZqTPaEWdO9Sq9FhBNPQ/WNovmX/XtkKCTxs
# 8eZXLm8BazGZsuDZ4IUK/73hcXpTfNWD1LLMgS0xayTAIN/UUwedoahQcHP+shNa
# XYpC/xgrzeGg3OqJ2ZsQxAgRZnp6O/1WfI7UWNEI4+W0AUc/H6K4QLGmFHftIJWv
# OAUWjOdoy1f+Ra4=
# SIG # End signature block
