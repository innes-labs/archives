Function Get-PncDomainsAndTargets {
<#
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve domains and targets of each domain.
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve domains and targets of each domain.
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell object describing the domains and its targets
Example of object formated in JSON :
{
     "countDomain":  1,
     "countTarget":  2,
     "domains":  [
         {
             "Name":  "domain1",
             "countTarget":  2,
             "targets":  [
                 {
                     "label":  "target 1",
                     "targetId":  "30-9c-23-1e-d8-1b",
                     "modelFamily":  "nt_iaxx-1",
                     "middlewareFamily":  "gekkota-4",
                     "targetIdType":  "mac",
                      "info":  {
                          "date-status":  "2019-05-15T09:18:26.598Z",
                          "mac":  "30-9c-23-1e-d8-1b",
                          "hostname":  "innes-sw36",
                          "uuid":  "00000000-0000-0000-0001-309c231ed81b",
                          "modelName":  "nt_ia32",
                          "modelNumber":  "4.10.10",
                          "serialNumber":  "",
                              "middleware":  "gekkota-4",
                           "ip-addresses":  [
                                {
                                    "origin":  "auto",
                                        "value":  "fc00::d47a:b234:cee4:1a3/64",
                                    "if-type":  "LAN"
                                },
                                ...
                           ]
                     }
                 }
                 ...
             ]
         }
          ...
}
.EXAMPLE
Get-PncDomainsAndTargets -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION: 1.10.10
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost = $(throw "Please enter the Plugncast G3 host (IP or DNS domain"),
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"

# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve configuration for Plugncast G3 server `"$server`"")

 
 

# Configuration object
$configObject = [PSCustomObject]@{
    countDomain = 0;
    countTarget = 0;
}
[System.Collections.ArrayList]$domainsArray = @()

# List domain Ids
$Body = @{
    target = "nsIAppliDomains.listIds"
}
$JsonBody = $Body | ConvertTo-Json
Start-Sleep -m $SleepDurationBeforeCommand

function Storage {
    param (
        [string] $total,
        [string] $used
    )
    $t = [int64]$total
    $u = [int64]$used

    switch ($t) {
        { $_ -gt 1tb } 
        { "{0:n2}/{1:n2} Tio" -f ($u/1tb),($_ / 1tb); break }
        { $_ -gt 1gb } 
        { "{0:n2}/{1:n2} Gio" -f ($u/1gb),($_ / 1gb); break }
        { $_ -gt 1mb } 
        { "{0:n2}/{1:n2} Mio" -f ($u/1mb),($_ / 1mb); break }
        { $_ -gt 1kb } 
        { "{0:n2}/{1:n2} Kio" -f ($u/1kb),($_ / 1kb); break }
        default  
        { "{0}/{1} o" -f $u,$_; break }
    }      

}
function RetrieveStatus {
    param (
        [System.Xml.XmlElement] $status,
        [PSCustomObject] $info
    )
    foreach ($child in $status.ChildNodes) {
        $name = $child.ToString()
        $value = $child.InnerText
        if ($name -eq "date-status" ) {
            $info | Add-Member -MemberType NoteProperty -Name $name -Value $value | Out-Null
        }
        elseif ($name -eq "device-status" ) {
            $device = $child.device;
            $info |  Add-Member -MemberType NoteProperty -Name "mac" -Value $device.mac | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "hostname" -Value $device.hostname | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "uuid" -Value $device.uuid | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "modelName" -Value $device.modelName | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "modelNumber" -Value $device.modelNumber | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "serialNumber" -Value $device.serialNumber | Out-Null
            if ($device.middleware) {
                $info |  Add-Member -MemberType NoteProperty -Name "middleware" -Value $device.middleware | Out-Null
            }
            else {
                $info |  Add-Member -MemberType NoteProperty -Name "middleware" -Value "" | Out-Null
            }
            [System.Collections.ArrayList]$ips = @()
            $ip_addresses = $device."ip-addresses"
            foreach ($ip in $ip_addresses.ChildNodes) {
                $ips.Add(@{
                    "if-type" = $ip."if-type"
                    origin = $ip.origin
                    value = $ip.value
                }) | Out-Null
            }
            $info | Add-Member -MemberType NoteProperty -Name "ip-addresses" -Value $ips | Out-Null
            $status = $child.status
            $storage = $status.storage
            $str = Storage $storage.total.InnerText $storage.used.InnerText
            $info |  Add-Member -MemberType NoteProperty -Name "storage" -Value $str | Out-Null
            $launcher = $status.launcher
            $info |  Add-Member -MemberType NoteProperty -Name "state" -Value $launcher.state | Out-Null
            $powermanager = $launcher."power-manager"
            if ($powermanager)
            {
                $level = $powermanager.level
                $info |  Add-Member -MemberType NoteProperty -Name "power-manager-level" -Value $powermanager.level | Out-Null
            }

        }
        
    }
    
}
try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}
$DomainsJson = $ExecutedRequest | ConvertFrom-Json
$configObject.countDomain = $DomainsJson.Length
foreach ($domain in $DomainsJson) {
    $domainObject = [PSCustomObject]@{
        Name = $domain
    }
    [System.Collections.ArrayList]$targetsArray = @()
    $Body = "declare namespace targets = `"ns.innes.plugncast.cms.targets`";targets:getAll()"
    try {
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/xquery' -Uri $BaseServerUri".domains/"$domain"/.db/cmsdb"   -Body $Body
        [xml]$result = [xml]$ExecutedRequest
        [System.Xml.XmlElement] $root = $result.get_DocumentElement()
        foreach ($targetNode in $root.ChildNodes) {
            $target = @{}
            foreach ($child in $targetNode.ChildNodes) {
                $name = $child.ToString()
                $value = $child.InnerText
                if ($name -eq "modelFamily" ) {
                    $target.Add("modelFamily", $value) | Out-Null
                }
                elseif ($name -eq "targetIdType" ) {
                    $target.Add("targetIdType", $value) | Out-Null
                }
                elseif ($name -eq "targetId" ) {
                    $target.Add("targetId", $value) | Out-Null
                }     
                elseif ($name -eq "label" ) {
                    $target.Add("label", $value) | Out-Null
                }      
                elseif ($name -eq "middlewareFamily" ) {
                    $target.Add("middlewareFamily", $value) | Out-Null
                }      
            }
            if ($target.Count -ne 0)
            {
                $targetsArray.Add([PSCustomObject]$target) | Out-Null
                $configObject.countTarget++
            }
        }
        $domainObject | Add-Member -MemberType NoteProperty -Name countTarget -Value $targetsArray.Count | Out-Null
        if ($targetsArray.Count -gt 0)
        {
            $domainObject | Add-Member -MemberType NoteProperty -Name targets -Value $targetsArray | Out-Null
        }
        

    }
    catch {
        LogWrite( "Exception during request" )
        LogWrite( ($_.Exception).ToString().Trim() )
        LogWrite( ($_.Exception.Message).ToString().Trim() )
        throw "Exception during request"
    } 
    $Body = "declare namespace pncf = `"ns.innes.plugncast.frontals`";pncf:getRegisteredDevicesWithStatus()"
    try {
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/xquery' -Uri $BaseServerUri".domains/"$domain"/.db/frontalsdb"   -Body $Body
        [xml]$result = [xml]$ExecutedRequest
        #$str = WriteXml $result
        [System.Xml.XmlElement] $root = $result.get_DocumentElement()

        foreach ($target in $root.ChildNodes) {
            $targetInfo = [PSCustomObject]@{}
            $id = $null
            foreach ($child in $target.ChildNodes) {
                $name = $child.ToString()
                $value = $child.InnerText
                if ($name -eq "id") {
                    $id = $value
                }
                elseif ($name -eq "phantom") {
                    $targetInfo | Add-Member -MemberType NoteProperty -Name $name -Value $value | Out-Null
                }
                elseif ($name -eq "registered") {
                    $targetInfo | Add-Member -MemberType NoteProperty -Name $name -Value $value | Out-Null
                }
                elseif ($name -eq "status") {
                    RetrieveStatus $child $targetInfo
                }
            }
            foreach ($target in $targetsArray) {
                if ($target.targetId -eq $id)
                {
                    if (!$target.info) {
                        $target | Add-Member -MemberType NoteProperty -Name info -Value $targetInfo | Out-Null
                    }
                }
            }
        }
    }
    catch {
        LogWrite( "Exception during request" )
        LogWrite( ($_.Exception).ToString().Trim() )
        LogWrite( ($_.Exception.Message).ToString().Trim() )
        throw "Exception during request"
    } 
    $domainsArray.Add($domainObject) | Out-Null
}
$configObject | Add-Member -MemberType NoteProperty -Name domains -Value $domainsArray | Out-Null
LogWrite($configObject | ConvertTo-Json -Depth 10)
$configObject
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUYojjTolnU9cSQysUNkoQQC4a
# 3Q6gggP3MIID8zCCAtugAwIBAgIQU/V6m/Alt7lMVarmvFCglzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MDYxNzEwMDIyNFoXDTIxMDYxNzEwMjIyNFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALfI/UTC
# OwdA3Kt/4f4bKaVXBKju2pU2a3eXquHDK7k98nigIIeblK9uByYwVX5C6TvBlIHl
# ZIi+q9Al4dGvvKdOzR5/hh1T1wvEgI/UuUfxEo+VO2ltycXJ++nl6KYDx+bj1GSs
# EG4/y4Bh94GD03Krr9xv2qpC2zHrqhXUFnIHp6IfWl3nkM5bnRtUm7Nj9UeaedAk
# uhL5SKTjpsrN4ePOwQodMFV3JJZacJiXlHMwoyziOEW0cGoHgCJ4yVkM8ZBmkTmQ
# avi22eRmp/mTuzOo9QAcz+N2CFX2zYNMSBuNekyAxleHxU7DzN1IJM63kkFenGZN
# 5lQbTWlN420UV8UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQWbiWvlbDA8RikmCU2TGfm4VpdeTANBgkqhkiG9w0BAQsFAAOCAQEAEKd/
# BplG/wTEr1U0vb1nEeNWNqEgGH+FygZsGyuESX4iv8LYtDcXtZvFiPcb3HuauAJo
# zVoUSlLDnWZnMibkzeiA7TFDyb62eo/qbKer0FfijzyGShE0WxKiypp6dDaOYVPC
# 6PfVgUamQ/Ym6K4LmbcbMluU9hxmK0F1lJqE1xCw/pW16D6sdWxJfeT65lubmTSG
# cpdBnVqhUTTs1wYtC2xPB8tdNnKsFW2CKlOQQikEF8zSZVX0f8KYhdBD5GDzWNTn
# CciNETjuNUMIB+8/MmPWBOJrvZLo8BoBKfpgONrtgUouCnzuUr1Dd+9nTW5hk+89
# 3n5qYp7r1bsVD3fm9zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFP1epvwJbe5TFWq5rxQoJcwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFGISE/QGxei/e9QqWRWHVkwqfdoeMA0GCSqGSIb3DQEBAQUABIIBAHWchaWE
# jtRZS6UNtz3gfOxtNXO0d2dFuQxf8oXa070Aaf8oArlLdPbY+ZtRDCryd9VT31hK
# oDbY4c5Cqpu8LOIJ0ZCJxI21JoZi1tpAkU8XvotrYSySy7oON7BK/ZmwrMU0E7HH
# XVt9ujBb2j6qr/tUCitVG3mDKoxN7jAk2+PIlQK9vv0cKH5HFNzkHrzMPDeRmtO8
# FWILaxtFV3DVOM/2YtBp2OJRqfNze0LWaN64+YkUX5sdyZ6G/J66gwB+7r+XQaRd
# lokFn3cSs841YD016Otyrc/jqt2Ugvrmzuq/grPMwJLBh/9ic3flRPhg2BVVSRzZ
# 0XQCREQMN/XG2/Q=
# SIG # End signature block
