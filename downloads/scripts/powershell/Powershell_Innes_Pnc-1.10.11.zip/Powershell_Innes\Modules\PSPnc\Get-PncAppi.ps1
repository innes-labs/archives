Function Get-PncAppi {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve all installed APPIs
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve all installed APPIs
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS 
The powershell object that describes all installed APPIs.
Example of object formated in JSON :
{
    "urn:innes:system-app#playzilla":  {
        "nbValidTokens":  0,
        "versions":  {
            "4.10.19":  {
                ...
            }
            ...
        }
         "domains":  {
            "domain1":  {
                "nbValidTokens":  0
            }
          },
        "hiddenDomains":  false,
        "id":  "urn:innes:system-app#playzilla",
        "hiddenLicenses":  false,
        "licenses":  {
             "PSN00690-00000 CD5":  {
                 "label":  "playzilla",
                 "valid":  false,
                  "license":  "xxxx - xxxx - xxxx - xxxx - xxxxx",
                 "domain":  "domain1",
                 "hiddenDomain":  false
             },
              ...
           }
        }
    }
    ...
}
.EXAMPLE
Get-PncAppi -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve appis for server `"$server`"")

 

$Body = @{
    target = "nsIAppliAppis.list"
}
$JsonBody = $Body | ConvertTo-Json
Start-Sleep -m $SleepDurationBeforeCommand

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}

$AppisObject = $ExecutedRequest | ConvertFrom-Json
LogWrite($AppisObject | ConvertTo-Json -Depth 5)
$AppisObject
}




# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUrJgCksewjfjG9QCCprdO/i21
# SgOgggP3MIID8zCCAtugAwIBAgIQU/V6m/Alt7lMVarmvFCglzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MDYxNzEwMDIyNFoXDTIxMDYxNzEwMjIyNFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALfI/UTC
# OwdA3Kt/4f4bKaVXBKju2pU2a3eXquHDK7k98nigIIeblK9uByYwVX5C6TvBlIHl
# ZIi+q9Al4dGvvKdOzR5/hh1T1wvEgI/UuUfxEo+VO2ltycXJ++nl6KYDx+bj1GSs
# EG4/y4Bh94GD03Krr9xv2qpC2zHrqhXUFnIHp6IfWl3nkM5bnRtUm7Nj9UeaedAk
# uhL5SKTjpsrN4ePOwQodMFV3JJZacJiXlHMwoyziOEW0cGoHgCJ4yVkM8ZBmkTmQ
# avi22eRmp/mTuzOo9QAcz+N2CFX2zYNMSBuNekyAxleHxU7DzN1IJM63kkFenGZN
# 5lQbTWlN420UV8UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQWbiWvlbDA8RikmCU2TGfm4VpdeTANBgkqhkiG9w0BAQsFAAOCAQEAEKd/
# BplG/wTEr1U0vb1nEeNWNqEgGH+FygZsGyuESX4iv8LYtDcXtZvFiPcb3HuauAJo
# zVoUSlLDnWZnMibkzeiA7TFDyb62eo/qbKer0FfijzyGShE0WxKiypp6dDaOYVPC
# 6PfVgUamQ/Ym6K4LmbcbMluU9hxmK0F1lJqE1xCw/pW16D6sdWxJfeT65lubmTSG
# cpdBnVqhUTTs1wYtC2xPB8tdNnKsFW2CKlOQQikEF8zSZVX0f8KYhdBD5GDzWNTn
# CciNETjuNUMIB+8/MmPWBOJrvZLo8BoBKfpgONrtgUouCnzuUr1Dd+9nTW5hk+89
# 3n5qYp7r1bsVD3fm9zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFP1epvwJbe5TFWq5rxQoJcwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFNCGLCoWirK8ajHCWNFegYK6aiHcMA0GCSqGSIb3DQEBAQUABIIBAH1KO67m
# HczLnfR44uW8e24Refoyd5LARvixwSBqFM+cWcWQx5HAtG1g3439WQ/WSQEEyU2t
# i9Ew0fhO6KVDJXeUzJfPSiNJ6uToQsVj/lbYPgKksKwmUcQWzEccwfu5Hk+1I60I
# 2f1PoPtJE8+GZYNDoHTAqb/yY0p+DymT2lFYK5NRmZRlCcsG2rJkMZ8moPukIpkF
# 3q8Rj/wSeupcePvP4BidOmd9S5h+z1lfYrFkhj92t3OmSQXKqLE1+E8/nVSTn6se
# 5POoWOooI9ps4n4uKItZRNH+Iy5glV43JtsRoPL+v1yjrlewKo8kA4FuwckubP9o
# wii4Nfi8RNYD9o0=
# SIG # End signature block
