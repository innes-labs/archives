

Function New-PncUri {
<#
.SYNOPSIS
This function generates a Plugncast URI file
.DESCRIPTION
This function generates a Plugncast URI file
.PARAMETER uri
The uri of the media to play, it can be absolute path or relative
.PARAMETER title
The title of URI file
.PARAMETER fallback
The fallback media to play if the URI is not accessible
.PARAMETER thumbnail
The thumbnail associated with the media
.PARAMETER category
The category of the URI file
.PARAMETER mediatype
The type of the media which can be "iframe", "video", "audio", "image", "ebook", "animation" (default "video")
.EXAMPLE
New-PncUri -uri "udp://225.1.1.1:1234" -title "TF1" -thumbnail ".\assets\TF1.png" -category "IPTV"
.NOTES
VERSION:1.10.10
#>
 
[CmdletBinding()]
Param
(
    # Name of the file, can be absolute path or relative
    [Parameter(Mandatory=$true)]
    [string] $uri,
    [string] $title,
    [string] $fallback,
    [string] $thumbnail,
    [string] $category,
    [string] $mediatype = "video"
)
$strDoc=@'
<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:app="ns.innes.app" xmlns="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:ib="ns.innes.backoffice" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
	<x:xmpmeta x:xmptk="Adobe XMP Core 4.4.0-1" xmlns:x="adobe:ns:meta/">
		<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
			<rdf:Description rdf:about=""
					xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:xmpGImg="http://ns.adobe.com/xap/1.0/g/img/"
					xmlns:xmpMM="http://ns.adobe.com/xap/1.0/mm/" xmlns:dc="http://purl.org/dc/elements/1.1/" 
					xmlns:is="ns.innes.metadata" >
				<xmp:Thumbnails>
					<rdf:Alt>
						<rdf:li rdf:parseType="Resource">
							<xmpGImg:format>__FORMAT__</xmpGImg:format>
							<xmpGImg:width>__W__</xmpGImg:width>
							<xmpGImg:height>__H__</xmpGImg:height>
							<xmpGImg:image>__IMG__</xmpGImg:image>
						</rdf:li>
					 </rdf:Alt>
				</xmp:Thumbnails>
				<dc:title>
					<rdf:Alt>
						<rdf:li xml:lang="x-default">__TITLE__</rdf:li>
					</rdf:Alt>
				</dc:title>
				<is:category>
					<rdf:Bag>
						<rdf:li>
							<rdf:Alt>
								<rdf:li xml:lang="x-default">__CATEGORY__</rdf:li>
							</rdf:Alt>
						</rdf:li>
					</rdf:Bag>
				</is:category>
			</rdf:Description>
		</rdf:RDF>
	</x:xmpmeta>
	<rdf:Description xmlns:RDF="http://www.w3.org/1999/02/22-rdf-syntax-ns#" rdf:about="__URI__" rdf:type="uri" ib:mediatype="video">
		<app:condition/>
		<app:fallback active="false" src=""/>
	</rdf:Description>
</rdf:RDF>
'@
$xmlDoc = [System.Xml.XmlDocument] $strDoc
$ns = New-Object System.Xml.XmlNamespaceManager($xmlDoc.NameTable)
[PSCustomObject]$Namespace = @{rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
     x="adobe:ns:meta/"
     is="ns.innes.metadata"
     app="ns.innes.app"
     xmp="http://ns.adobe.com/xap/1.0/"
     xmpMM="http://ns.adobe.com/xap/1.0/mm/"
      stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#"
      xmpGImg="http://ns.adobe.com/xap/1.0/g/img/"
      dc="http://purl.org/dc/elements/1.1/"
      Iptc4xmpExt="http://iptc.org/std/Iptc4xmpExt/2008-02-29/"
      im="ns.innes.metadata"
      xml="http://www.w3.org/XML/1998/namespace"
      xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/"}
    foreach ($key in $Namespace.keys) {
        $ns.AddNamespace($key, $Namespace[$key])
    }
# $nodes = $xmlDoc.SelectNodes("//RDF/Description/", $ns)
$description = $xmlDoc.SelectSingleNode("/rdf:RDF/rdf:Description", $ns)
$description.SetAttribute("rdf:about", $uri);
if ($mediatype){
    $description.SetAttribute("ib:mediatype", $mediatype);
}
if ($fallback) {
    $n = $description.SelectSingleNode("app:fallback", $ns);
    $n.SetAttribute("src", $fallback)
    $n.SetAttribute("active", "true");
}
$xmpmeta = $xmlDoc.SelectSingleNode("//x:xmpmeta", $ns)
if ($thumbnail)
{
    $image  = New-Object -ComObject Wia.ImageFile
    $file = $thumbnail
    if ($thumbnail.StartsWith("."))
    {
        $file = [string] (Get-Location) + "\" +  $thumbnail
    }
    $image.loadfile($file)
    $node = $xmlDoc.SelectSingleNode("//xmp:Thumbnails/rdf:Alt/rdf:li", $ns)
    $n = $node.SelectSingleNode("xmpGImg:format", $ns);
    $n.InnerText = $image.FileExtension.ToUpper();
    $n = $node.SelectSingleNode("xmpGImg:width", $ns);
    $n.InnerText = [string] $image.width;
    $n = $node.SelectSingleNode("xmpGImg:height", $ns);
    $n.InnerText = [string] $image.height;
    $data = [convert]::ToBase64String((get-content $thumbnail -encoding byte -ErrorAction Stop))
    $n = $node.SelectSingleNode("xmpGImg:image", $ns);
    $n.InnerText = $data;
}
else {
    $node = $xmlDoc.SelectSingleNode("//xmp:Thumbnails", $ns)
    $node.ParentNode.RemoveChild($node);
}
if ($title) {
    $node = $xmlDoc.SelectSingleNode("//dc:title/rdf:Alt/rdf:li", $ns)
    $node.InnerText = $title
}
else {
    $node = $xmlDoc.SelectSingleNode("//dc:title", $ns);
    $node.ParentNode.RemoveChild($node);
}
if ($category) {
    $node = $xmlDoc.SelectSingleNode("//is:category/rdf:Bag/rdf:li/rdf:Alt/rdf:li", $ns)
    $node.InnerText = $category
}
else {
    $node = $xmlDoc.SelectSingleNode("//is:category", $ns);
    $node.ParentNode.RemoveChild($node);
}
$str = WriteXml $xmlDoc
$str
}
# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUwBPkPlyZugTv+fnpbvRrezUJ
# V2egggP3MIID8zCCAtugAwIBAgIQU/V6m/Alt7lMVarmvFCglzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MDYxNzEwMDIyNFoXDTIxMDYxNzEwMjIyNFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALfI/UTC
# OwdA3Kt/4f4bKaVXBKju2pU2a3eXquHDK7k98nigIIeblK9uByYwVX5C6TvBlIHl
# ZIi+q9Al4dGvvKdOzR5/hh1T1wvEgI/UuUfxEo+VO2ltycXJ++nl6KYDx+bj1GSs
# EG4/y4Bh94GD03Krr9xv2qpC2zHrqhXUFnIHp6IfWl3nkM5bnRtUm7Nj9UeaedAk
# uhL5SKTjpsrN4ePOwQodMFV3JJZacJiXlHMwoyziOEW0cGoHgCJ4yVkM8ZBmkTmQ
# avi22eRmp/mTuzOo9QAcz+N2CFX2zYNMSBuNekyAxleHxU7DzN1IJM63kkFenGZN
# 5lQbTWlN420UV8UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQWbiWvlbDA8RikmCU2TGfm4VpdeTANBgkqhkiG9w0BAQsFAAOCAQEAEKd/
# BplG/wTEr1U0vb1nEeNWNqEgGH+FygZsGyuESX4iv8LYtDcXtZvFiPcb3HuauAJo
# zVoUSlLDnWZnMibkzeiA7TFDyb62eo/qbKer0FfijzyGShE0WxKiypp6dDaOYVPC
# 6PfVgUamQ/Ym6K4LmbcbMluU9hxmK0F1lJqE1xCw/pW16D6sdWxJfeT65lubmTSG
# cpdBnVqhUTTs1wYtC2xPB8tdNnKsFW2CKlOQQikEF8zSZVX0f8KYhdBD5GDzWNTn
# CciNETjuNUMIB+8/MmPWBOJrvZLo8BoBKfpgONrtgUouCnzuUr1Dd+9nTW5hk+89
# 3n5qYp7r1bsVD3fm9zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFP1epvwJbe5TFWq5rxQoJcwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFIzS6uIqYMsNdTLg2hhcnjtCLkfYMA0GCSqGSIb3DQEBAQUABIIBAEgQ9jtX
# fnuNg4M7LpslRXxAP2+4r8I+0WwDimuCY0fUv+d5dyZQmbzoW+X/FowzP6INdMrt
# qgVWVqFzGIWCVK6DMOqYweTuSpWiWCLg/WsuITl3sVCGtZ0gY4KKqv6zWUlLAh7k
# X/4i+L1kwyvBx3vDA8fsmedQJ9mDsLa4VUQNMQEomEq/qJD6xIU7gEQZtw2eUVi8
# GUGObixO780OlX6XWbypSo7Dix8Czi2xnBdMFUEO4qWOVBugH2DZG8c7XQaodsaj
# Y97/qiwomIO9ELM42VSAXtm9V7lQ3nCUt6iz+ONXWSk/bP/Co9W+vBlAWvSIRTBc
# dH94L25NQEoM1NI=
# SIG # End signature block
