<#
.SYNOPSIS
This script permits to get many information from PlugnCast Server
.DESCRIPTION
This script permits to get many information from PlugnCast Server
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain). Example: "demo.plugncast.com", "localhost"
.PARAMETER urlPort
The Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used (default "superadmin")
.PARAMETER urlPassword
The password of authentication if the certificate is not used (default "superadmin")
.PARAMETER logFile
The path of log file (default "./Get-PncInformation.log")
.EXAMPLE
Get-PncInformation -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [string] $UrlLogin = "superadmin",
    [string] $UrlPassword = "superadmin",
    [string] $LogFile = "./Get-PncInformation.log"
)
# Import Pnc Module
Import-Module PSPnc
# Clear the log file of any previous try
If ($LogFile -and (Test-Path $LogFile) -eq $True) {
    Remove-Item -Path $LogFile
}
$verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
# Get all the information
$result = Get-PncVersion -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
$result = Get-PncDomainsAndTargets -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
$result = Get-PncLicense -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
$result = Get-PncAppi -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
$result = Get-PncAppiDomainAssociation -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -appi "playzilla" -logFile $LogFile -vb:$verbose
$result = Get-PncContentModelInstalled -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose


# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUoSUvCs/25NCv2AdSbnILkPgw
# 1EygggP3MIID8zCCAtugAwIBAgIQU/V6m/Alt7lMVarmvFCglzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MDYxNzEwMDIyNFoXDTIxMDYxNzEwMjIyNFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALfI/UTC
# OwdA3Kt/4f4bKaVXBKju2pU2a3eXquHDK7k98nigIIeblK9uByYwVX5C6TvBlIHl
# ZIi+q9Al4dGvvKdOzR5/hh1T1wvEgI/UuUfxEo+VO2ltycXJ++nl6KYDx+bj1GSs
# EG4/y4Bh94GD03Krr9xv2qpC2zHrqhXUFnIHp6IfWl3nkM5bnRtUm7Nj9UeaedAk
# uhL5SKTjpsrN4ePOwQodMFV3JJZacJiXlHMwoyziOEW0cGoHgCJ4yVkM8ZBmkTmQ
# avi22eRmp/mTuzOo9QAcz+N2CFX2zYNMSBuNekyAxleHxU7DzN1IJM63kkFenGZN
# 5lQbTWlN420UV8UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQWbiWvlbDA8RikmCU2TGfm4VpdeTANBgkqhkiG9w0BAQsFAAOCAQEAEKd/
# BplG/wTEr1U0vb1nEeNWNqEgGH+FygZsGyuESX4iv8LYtDcXtZvFiPcb3HuauAJo
# zVoUSlLDnWZnMibkzeiA7TFDyb62eo/qbKer0FfijzyGShE0WxKiypp6dDaOYVPC
# 6PfVgUamQ/Ym6K4LmbcbMluU9hxmK0F1lJqE1xCw/pW16D6sdWxJfeT65lubmTSG
# cpdBnVqhUTTs1wYtC2xPB8tdNnKsFW2CKlOQQikEF8zSZVX0f8KYhdBD5GDzWNTn
# CciNETjuNUMIB+8/MmPWBOJrvZLo8BoBKfpgONrtgUouCnzuUr1Dd+9nTW5hk+89
# 3n5qYp7r1bsVD3fm9zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFP1epvwJbe5TFWq5rxQoJcwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFLrqfzz9WdHBTL62j9sF0wagCxxaMA0GCSqGSIb3DQEBAQUABIIBACPjOLBi
# pqTzB37pAVAVl0bLH4pknLRubxSV3CWJpvzoNsEM/JuDRn8wnlAHwsbahGlDMp28
# pW080cn0AD7jwf0e4+86xmXfxzidaPjXhuIbOUGlD3rY4yMRnCyJWKuS6bxf1gdK
# gPTcrkM91mXVyVOadVrk3Hdj/g9R0zM8PItbpM2IwAx3FOLiYY9OxChBG4lLjTUa
# z/ZYU7Ah4CbuLT7u9wulmfS0x8ix/dOy2gimnNzytVj6+oXbwDp88oP2g74x/Vn1
# YoZWI0Y9CQOOOMsoECXm93uCEjqWW8QAmza6ouN8L8FDJlbuo9kggNvQASPIKZNY
# M2uOm6q5j6m6V5A=
# SIG # End signature block
