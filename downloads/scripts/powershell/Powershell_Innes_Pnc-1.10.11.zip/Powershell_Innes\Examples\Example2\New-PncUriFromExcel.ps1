<#
.SYNOPSIS
   PlugnCast : .URI generator from MS-Excel
.DESCRIPTION
  Requires the installation of the PSExcel Powershell module:
  Launch a Powershell console with administrator user and type
   > Install-Module -Name PSExcel

  MS-Excel format : 
  id	name	scheme	address	    port	thumbnail
  1	    TF1	    udp://	225.1.1.1	1234	./assets/tf1.png
.PARAMETER excelFileList
The list of MS-Excel file path (absolute or relative) describing the .URI files to generate.
.PARAMETER outputDirectory
The directory containing the generated URI files (default "./output")
.EXAMPLE
New-UriFromExcel.ps1 channels.xlsx
#>
 
[CmdletBinding()]
Param
(
    [string[]] $excelFileList = "./channels.xlsx",
    [string] $outputDirectory = "./output"
)

Begin
{
    $verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
    Import-Module PSPnc   
    Import-Module PSExcel
    function Write-UriFile {
        param (
            [Parameter(Mandatory = $True, ValueFromPipeline = $true)]
            [Object[]] $in,

            [Parameter(Mandatory = $true)]
            [String] $filename
        ) 
        process {
                
            $_filename1 = $filename.Split([IO.Path]::GetInvalidFileNameChars()) -join '_'
            $_filename = "./output/" + $_filename1 + ".uri"
            add-content -path $_filename $in
        }
    }
    function New-UriFromExcelFile($path){
        $datas = Import-XLSX -RowStart 1  -Path $path
        foreach($data in $datas ){
            $uri =  "{0}{1}:{2}" -f $data.scheme, $data.address, $data.port
            $thumbnail = $data.thumbnail
            if ($thumbnail.Contains("/"))
            {
                $thumbnail = $thumbnail.Replace("/", "`\");
            }
            if ($thumbnail.StartsWith("."))
            {
                $thumbnail = [string] (Get-Location) + "\" + $thumbnail
            }
            $tokens= @{IMG= $img; CATEGORY= 'IPTV'; TITLE=$data.name ; URI=$uri}
            New-PncUri -uri $uri -thumbnail $thumbnail -title $data.name -category 'IPTV' -vb:$verbose `
               | Write-UriFile -filename $data.name 
        }
    }     
}


Process
{
    foreach($n in $excelFileList){
        $PSDefaultParameterValues['*:Encoding'] = 'utf8'
        if (Test-Path $outputDirectory) {
            Remove-Item -Path $outputDirectory/*.uri -Force
        }
        else {
            New-Item -ItemType Directory -Force -Path $outputDirectory
        }
        $path = (resolve-path $n).Path
        Write-Verbose "Converting $path"
        New-UriFromExcelFile -path $path
        Write-Verbose "End of Job"
    }
}
End
{
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUkSVFMt0iKwQeD/ZqASggJ56x
# x3+gggP3MIID8zCCAtugAwIBAgIQU/V6m/Alt7lMVarmvFCglzANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MDYxNzEwMDIyNFoXDTIxMDYxNzEwMjIyNFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALfI/UTC
# OwdA3Kt/4f4bKaVXBKju2pU2a3eXquHDK7k98nigIIeblK9uByYwVX5C6TvBlIHl
# ZIi+q9Al4dGvvKdOzR5/hh1T1wvEgI/UuUfxEo+VO2ltycXJ++nl6KYDx+bj1GSs
# EG4/y4Bh94GD03Krr9xv2qpC2zHrqhXUFnIHp6IfWl3nkM5bnRtUm7Nj9UeaedAk
# uhL5SKTjpsrN4ePOwQodMFV3JJZacJiXlHMwoyziOEW0cGoHgCJ4yVkM8ZBmkTmQ
# avi22eRmp/mTuzOo9QAcz+N2CFX2zYNMSBuNekyAxleHxU7DzN1IJM63kkFenGZN
# 5lQbTWlN420UV8UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQWbiWvlbDA8RikmCU2TGfm4VpdeTANBgkqhkiG9w0BAQsFAAOCAQEAEKd/
# BplG/wTEr1U0vb1nEeNWNqEgGH+FygZsGyuESX4iv8LYtDcXtZvFiPcb3HuauAJo
# zVoUSlLDnWZnMibkzeiA7TFDyb62eo/qbKer0FfijzyGShE0WxKiypp6dDaOYVPC
# 6PfVgUamQ/Ym6K4LmbcbMluU9hxmK0F1lJqE1xCw/pW16D6sdWxJfeT65lubmTSG
# cpdBnVqhUTTs1wYtC2xPB8tdNnKsFW2CKlOQQikEF8zSZVX0f8KYhdBD5GDzWNTn
# CciNETjuNUMIB+8/MmPWBOJrvZLo8BoBKfpgONrtgUouCnzuUr1Dd+9nTW5hk+89
# 3n5qYp7r1bsVD3fm9zGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFP1epvwJbe5TFWq5rxQoJcwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFJtYJ6UjC2d+lYzWgTS+MXb5/PLLMA0GCSqGSIb3DQEBAQUABIIBALLKeO2d
# NqR/k3AGTwghpzIE9izylfrqpkcCGaAUB54GPHVAeAy9Qvilsr2EMeQ2MJ6t9fAr
# OjmEvEHfh4/NgRnxQsJRyCl5mJudNd3//19itsdfpP5CMBKiETQxJlZzoEpjXsKx
# nqx4DmXbBwWvOs6AvU2PpWSZszgI3eC7GlnffacPFeScsB4fi6heyc2+CU92GXdP
# cbiqUDkh1S8q4Uq7htNTSCiUCf/eg5+ae/RGidYRi5UpgcinXD62Lpy/vddJpAnz
# yiWoPi5aUJWYU0y19upmMob9WVc6xltrOHE0S2EHVySoce0VGQBPKafRbnNYqu9W
# Y/o5+dDYqM9lZsA=
# SIG # End signature block
