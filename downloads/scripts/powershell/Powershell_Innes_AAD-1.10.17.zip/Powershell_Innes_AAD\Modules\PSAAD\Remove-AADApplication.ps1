Function Remove-AADApplication {
<# 
.SYNOPSIS
This function removes a Azure Active Directory application.  
.DESCRIPTION
This function removes a Azure Active Directory application.  
.PARAMETER Credential
Exchange credential (admin profile) used to remove the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the Exchange credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been removed. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
The name of the Azure Active Directory application.
.OUTPUTS
Nothing
.EXAMPLE
PS C:\>Remove-AADApplication -appname "SignMeeting"
 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName
)

$date = Get-Date
LogWrite("$date : delete AAD application with name `"$appName`"")

Remove-AADApplication-CommonsUtils -credential $Credential -tenantId $tenantId -appName $appName 
LogWrite("Application removed")

}
# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUGNKiDNmaEp5ARUC1u5SFjcqj
# JBagggP3MIID8zCCAtugAwIBAgIQM4GAhUNd9btD8yRhX27pATANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIz
# MTExNjE2NDA0NloXDTI0MTExNjE3MDA0NlowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALwUcwjM
# HF8tM6RmUbucWQ7v2kwXdXT6ktKbQMc0t4wu00+DSLUrByuOOubZDt3Efk9DEIDM
# 1OYivrZZg6LjOdAYRi+4pWYvyZodB4U/WI6ilp5vHtoCGpdjB8DD4l08LQA71sZP
# 0bQIth+bf921hqSaMvk3XS1T1Oq7EOoqpjWUcoBQ9RToJ2scCjYp8KDWxFfn42eX
# IXyaiG07+/lS0s3LhcZJomz31LNhbY4Q6jk6uov721wpsbl2wS2NpfHS0Xi3jdIs
# 0Ak7WQFCV35eSFlexiSPlXy1teODJGQ7mYjiNkIzW3H7ksYk+q2ZklimT6UHvjDG
# P1uZOc0bpp7RR7ECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTyBkoiRYJ9JsDISYrT1I1Tn62NFzANBgkqhkiG9w0BAQsFAAOCAQEANb78
# 1PuIZwHIdH9TD7BSU3dz0q2cXRXOvo9qUsYNzTupF75fti5zMSkpOMXIuhpCBket
# /cm6r5IaFclMu9p2Mdoz1Oqj5d0bG3MCyPVNuEhjZTmFJMDPaD6HyxrTbbdlyaYl
# yaD/71NSVA4tNo6q1dD6xDvY0vaImVoSopHXGvzGTbp+WPLG2V6UVf7z5of/Hkph
# ZWKT0hmNoc2rzGbgIXO2KxcojGEA+IoIW0iheFgFeuecdG9JL8h2zPXAKJP83ide
# vjblcgLUgEjlmRr3shXPBNBNBdRAeYWRmnaNZPV/MFUKfbJFLXGT97pOKIP7AP68
# Ue2JGCgI76TxM38ONTGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEDOBgIVDXfW7Q/MkYV9u6QEwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFLx70aBBAemhzBI57NTsD3NPEAwvMA0GCSqGSIb3DQEBAQUABIIBAG0AADgP
# oyJY6JrTXLjqLbhnqJBSDll/jJqmMsSzvNgO++pk65SBIOKZa1edNzMuKP1g9LTv
# JxQ3aIuKQpWqr066NN8fQHpV+uDEXV/k/BEAFvfNIfuL0Sh4CZTZQUEn+pr5vpit
# VEpLnlxAI1mSHKyeF8HQ1JRrpbpOHCyJviDg2druqxRfrNBFYojg+OuaaQ9pIu/3
# 62OwL/HeFVEQtxTsVo8wZIxt0WmIPZZiO/aidCzlaiF8QFctgLp7jUgFtZnFcfm3
# 5ML18kwxI6LVODmkBwwP2ClTwnjdlZMKe7bbMkIX/29EvovB5yrzrS0u6Z4+WX5D
# XIEpjX4CCZhPsjY=
# SIG # End signature block
