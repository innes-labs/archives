Function New-AADApplication {
<# 
.SYNOPSIS
This function creates a Azure Active Directory application.  
.DESCRIPTION
This function creates a Azure Active Directory application.  
.PARAMETER Credential
Credential (admin profile) used to create the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been created. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
Name of the Azure Active Directory application.
.PARAMETER PublicClient
The application is a public client (false by default). 
In this mode, it is possible to obtain a user type connection with the pair (susername, password) only (without secret client). 
But then the application type premissions and the secret client are no longer generated; it is then no longer possible to connect in application mode.
Only autorization types "signcom_m365", "url_launcher_m365", "m365_user" and "powerbi"  are allowed for a public client.
.PARAMETER authorizations
Authorization type:
- "signcom_m365" : to access to M365 files and folders resources and Web sites for SignCom application
- "url_launcher_m365" : to access to M365 Web sites for URL launcher application
- "signmeeting_ews": to access to MS-Exchange room mailbox resources for SignMeeting MS-Exchange application
- "signmeeting_m365": to access to M365 room mailbox resources for SignMeeting-M365 application
- "briva_calendar_ews": to access to MS-Exchange room mailbox resources for Briva Calendar EWS application
- "m365_room": to access to M365 room mailbox resource for SBL10e m365_room application
- "m365_user": to access to M365 user presence resource for SBL10e m365_user application
- "powerbi": to access to Power BI report and Power BI dashboards
.PARAMETER logFile
Log file path
.OUTPUTS
The result is an object that is describing the created Azure Active Directory application. 
It contains the following properties:
- name : Azure Active directory application name
- tenantId : Azure Active directory's tenant id
- clientId : Azure Active directory's application (client) Id
- objectId : Azure Active directory's application object id
- clientSecret: Azure Active directory's client secret
- spId : Azure Active directory's application service principal id
These object properties are flushed automatically in the "<appName>.json" file in the current directory.
.EXAMPLE
PS C:\>$result = New-AADApplication -appname "SignMeeting"  -authorizations "signmeeting_ews"
A consent request will be sent in 30 seconds in your browser.
You must log into an administrator account of your organization and grant the necessary permissions.
PS C:\>$result
Name                           Value
----                           -----
clientId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
objectId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
spId                           xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
name                           SignMeeting
tenantId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
clientSecret                   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
.NOTES 
 VERSION:1.10.10
#>

   [CmdletBinding()] 
   param(
      [PSCredential] $Credential,
      [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
      [string] $tenantId,
      [Parameter(Mandatory = $true)]
      [string] $appName,
      [Parameter(Mandatory = $true)]
      [ValidateSet('signcom_m365', 'url_launcher_m365', 'signmeeting_ews', 'signmeeting_m365', 'm365_room', 'm365_user', 'powerbi', 'briva_calendar_ews')]
      [string[]] $authorizations,
      [string] $LogFile,
      [bool] $PublicClient = $False,
      [bool] $multiTenants = $false
   )
   $date = Get-Date
   LogWrite("$date : create new AAD application with name `"$appName`"")
   try {
      for ($i = 0; $i -lt $authorizations.length; $i++)
      {
          $authorizations[$i] = ($authorizations[$i]).ToLower();
      }
      if ($PublicClient -and 
          -not ($authorizations.Contains("signcom_m365") -or 
          $authorizations.Contains("url_launcher_m365") -or
          $authorizations.Contains("m365_user") -or
          $authorizations.Contains("powerbi")
          )) 
      {
        Write-Error("This authorization type are not allowed with PublicClient parameter")
        exit 1
      }
      $consentRedirectUri = "http://localhost:23456/consent/redirect"
      [String[]] $replyUrls = @($consentRedirectUri)
      $app = New-AADApplication-CommonsUtils  -credential $Credential -tenantId $tenantId -appName $appName `
         -replyUrls $replyUrls `
         -generatePassword (-not $PublicClient) -AvailableToOtherTenants $multiTenants -PublicClient $PublicClient
      $requiredResourcesAccess = New-Object System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.RequiredResourceAccess]
      $hasDelegatedPermission = $false;
      if ($authorizations.Contains("signcom_m365") -or $authorizations.Contains("url_launcher_m365")) {
         $permissions = "Files.Read.All|Sites.Read.All|User.Read"
         if ($PublicClient) {
            $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions $permissions
         } else {
           $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions $permissions -requiredApplicationPermissions $permissions
         }
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("signmeeting_ews")) {
         $requiredPermissions = GetRequiredPermissions -appid "00000002-0000-0ff1-ce00-000000000000" `
            -requiredApplicationPermissions "full_access_as_app"
         $requiredResourcesAccess.Add($requiredPermissions)
         $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions "EWS.AccessAsUser.All|User.Read"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("briva_calendar_ews")) {
        $requiredPermissions = GetRequiredPermissions -appid "00000002-0000-0ff1-ce00-000000000000" `
           -requiredApplicationPermissions "full_access_as_app"
        $requiredResourcesAccess.Add($requiredPermissions)
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
           -requiredDelegatedPermissions "EWS.AccessAsUser.All|User.Read"
        $requiredResourcesAccess.Add($requiredPermissions)
        $hasDelegatedPermission = $true;
     }
      if ($authorizations.Contains("signmeeting_m365")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredApplicationPermissions "Place.Read.All|User.Read.All|Calendars.ReadWrite"
         $requiredResourcesAccess.Add($requiredPermissions)
      }
      if ($authorizations.Contains("m365_room")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredApplicationPermissions "Calendars.Read|User.Read.All"
         $requiredResourcesAccess.Add($requiredPermissions)
      }
      if ($authorizations.Contains("m365_user")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredDelegatedPermissions "Directory.AccessAsUser.All|Presence.Read.All"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("powerbi")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Power BI Service" `
        -requiredDelegatedPermissions "App.Read.All|Content.Create|Dataset.ReadWrite.All|Report.ReadWrite.All|Dashboard.ReadWrite.All"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      Set-AzureADApplication -ObjectId $app.ObjectId -RequiredResourceAccess $requiredResourcesAccess
    #   $app.clientSecret = [System.Web.HttpUtility]::UrlEncode($app.clientSecret)
      Set-Content -Path ".\$appName.json" -Value ($app | ConvertTo-Json -Depth 5)
      $hasDelegatedPermission = $true
      if ($hasDelegatedPermission) 
      {
        Write-Host "A consent request will be sent in 50 seconds in your browser.`
        You must log into an administrator account of your organization and grant the necessary permissions."
        Start-Sleep 50
        $request = "https://login.microsoftonline.com/" + $app.tenantId + "/adminconsent" + `
        "?client_id=" + $app.ClientId + "&redirect_uri=" + $consentRedirectUri
        Start-Process $request
        Start-ConsentRedirectServer
      }
      Write-Host("Application created")
      $app
   }
   catch {
      LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
      throw $_.Exception
   }
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUlMRRRgE+xTflOXnS34mPkFCu
# FG6gggP3MIID8zCCAtugAwIBAgIQM4GAhUNd9btD8yRhX27pATANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIz
# MTExNjE2NDA0NloXDTI0MTExNjE3MDA0NlowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALwUcwjM
# HF8tM6RmUbucWQ7v2kwXdXT6ktKbQMc0t4wu00+DSLUrByuOOubZDt3Efk9DEIDM
# 1OYivrZZg6LjOdAYRi+4pWYvyZodB4U/WI6ilp5vHtoCGpdjB8DD4l08LQA71sZP
# 0bQIth+bf921hqSaMvk3XS1T1Oq7EOoqpjWUcoBQ9RToJ2scCjYp8KDWxFfn42eX
# IXyaiG07+/lS0s3LhcZJomz31LNhbY4Q6jk6uov721wpsbl2wS2NpfHS0Xi3jdIs
# 0Ak7WQFCV35eSFlexiSPlXy1teODJGQ7mYjiNkIzW3H7ksYk+q2ZklimT6UHvjDG
# P1uZOc0bpp7RR7ECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTyBkoiRYJ9JsDISYrT1I1Tn62NFzANBgkqhkiG9w0BAQsFAAOCAQEANb78
# 1PuIZwHIdH9TD7BSU3dz0q2cXRXOvo9qUsYNzTupF75fti5zMSkpOMXIuhpCBket
# /cm6r5IaFclMu9p2Mdoz1Oqj5d0bG3MCyPVNuEhjZTmFJMDPaD6HyxrTbbdlyaYl
# yaD/71NSVA4tNo6q1dD6xDvY0vaImVoSopHXGvzGTbp+WPLG2V6UVf7z5of/Hkph
# ZWKT0hmNoc2rzGbgIXO2KxcojGEA+IoIW0iheFgFeuecdG9JL8h2zPXAKJP83ide
# vjblcgLUgEjlmRr3shXPBNBNBdRAeYWRmnaNZPV/MFUKfbJFLXGT97pOKIP7AP68
# Ue2JGCgI76TxM38ONTGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEDOBgIVDXfW7Q/MkYV9u6QEwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFAqs/skVGeVnB6y34hXJhT8qeb0eMA0GCSqGSIb3DQEBAQUABIIBABpPpNvC
# WyQS8hG81SRH2fNK7r9JRjN5ZgF/JtOkI342I7Hvk3+vfgAnLsDUHemmegjJe144
# o3rISXt4WaSQXMSedvIujsr6PdgkcakAEbXr+6GUVEl/U8gzUmP/nLQjuHxAB66v
# jcbe9Rrbn0HvPPiw5xt/zMke/Nu6U+6V1pLSAPFsmnnyDjo9vyB0xkLz+sVSYfQi
# J38iAxkDyuWfoyocqbWqZ3CH9erbVXi0NAvzyewoZ3H2JuOQTEUmky3zyz+WFVtf
# SctGdj+NyK60m7qay3aAQ8bceuoHgne483yAYuSa6XigqZHAjEn8AESd9V1lgXBa
# hWiUvRWftgycFws=
# SIG # End signature block
