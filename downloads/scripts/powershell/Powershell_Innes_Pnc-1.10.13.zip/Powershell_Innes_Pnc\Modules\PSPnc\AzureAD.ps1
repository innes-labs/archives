Function New-AADApplication {
<#
.SYNOPSIS
This function creates the Azure AD application for the sample in the provided Azure AD tenant 
.DESCRIPTION
This function creates the Azure AD application for the sample in the provided Azure AD tenant 
.PARAMETER Credential
The credential of the Azure AD user used to create the application. if absent, a dialog is displayed to connect to Azure AD 
.PARAMETER tenantId
The Active Directory Tenant. This is a GUID which represents the "Directory ID" of the AzureAD tenant
into which you want to create the apps. Look it up in the Azure portal in the "Properties" of the Azure AD
.PARAMETER appName
The name of the application 
.PARAMETER homePage 
The home page of the application
.PARAMETER replyUrls
The list of redirect Urls of the application
.PARAMETER logoutUrl
The logout Url of the application
.PARAMETER delegatedPermissions
delegated permissions (separated by "|") for the "Microsoft Graph" application
.PARAMETER applicationPermissions
application permissions (separated by '|') for "Microsoft Graph" application
.PARAMETER certificatePath
The file path of the certificate used by application (use only if the parameter GeneratePassword is $false)
.PARAMETER certificate
The certificate used by application (use only if the parameter GeneratePassword is $false)
.PARAMETER GeneratePassword
The function generate the secret key of the application 
.OUTPUTS
The object that describe the application created. This object is already dumped in the file names "<appName>.json"
Its contains the following properties:
name : the application name
tenantId : the tenant id
clientId : the client id of application
objectId : the object id of application
clientSecret: the client secret generated (present only if parameter GeneratePassword is $true)
spId : the service pricipal id of application

#> 
[CmdletBinding()]
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName,
    [string] $homePage,
    [string[]] $replyUrls,
    [string] $logoutUrl,
    [string] $certificatePath,
    [string] $delegatedPermissions,
    [string] $applicationPermissions,
    [bool] $AvailableToOtherTenants = $false,
    [bool] $GeneratePassword = $false,
    [System.Security.Cryptography.X509Certificates.X509Certificate2] $certificate

)
# Pre-requisites
try {
    if ((Get-Module -ListAvailable -Name "AzureAD") -eq $null) { 
        Install-Module "AzureAD" -Scope CurrentUser 
    } 
    Import-Module AzureAD
    if (!$Credential -and $TenantId) {
        $creds = Connect-AzureAD -TenantId $tenantId
    }
    else {
        if (!$TenantId) {
            $creds = Connect-AzureAD -Credential $Credential
        }
        else {
            $creds = Connect-AzureAD -TenantId $tenantId -Credential $Credential
        }
    }

    if (!$tenantId) {
        $tenantId = $creds.Tenant.Id
    }

    $tenant = Get-AzureADTenantDetail
    $tenantName = ($tenant.VerifiedDomains | Where { $_._Default -eq $True }).Name

    # Get the user running the script
    $user = Get-AzureADUser -ObjectId $creds.Account.Id

    # Create the client AAD application
    LogWrite( "Creating the AAD application ($appName)")
    $clientAadApplication = $null
    if ($homePage) {
    $clientAadApplication = New-AzureADApplication -DisplayName $appName `
        -Homepage $homePage `
        -ReplyUrls $replyUrls `
        -LogoutUrl $logoutUrl `
        -IdentifierUris "https://$tenantName/$appName" `
        -PublicClient $False `
        -AvailableToOtherTenants  $AvailableToOtherTenants 
    }
    else {
        $clientAadApplication = New-AzureADApplication -DisplayName $appName `
        -ReplyUrls $replyUrls `
        -LogoutUrl $logoutUrl `
        -IdentifierUris "https://$tenantName/$appName" `
        -PublicClient $False `
        -AvailableToOtherTenants  $AvailableToOtherTenants 
    }
    LogWrite( "Creating the client application ($appName)")
    $password = $null
    if ($GeneratePassword) {
        $password = New-AzureADApplicationPasswordCredential -ObjectId $clientAadApplication.ObjectId -EndDate (Get-Date).AddYears(10)
    }
    else {
        if ($certificatePath) {
            $certificate = Import-Certificate -FilePath $certificatePath -CertStoreLocation cert:\CurrentUser\My
        }
        $certSubject = $null
        if (!$certificate) {
            # Generate a certificate

            $certSubject = $appName + "Cert"
            $certificate = New-SelfSignedCertificate -Subject CN=$subject `
                -CertStoreLocation "Cert:\CurrentUser\My" `
                -KeyExportPolicy Exportable `
                -KeySpec Signature
        }
        $certKeyId = [Guid]::NewGuid()
        $certSubject = $certificate.Subject
        $certBase64Value = [System.Convert]::ToBase64String($certificate.GetRawCertData())
        $certBase64Thumbprint = [System.Convert]::ToBase64String($certificate.GetCertHash())

        # Add a Azure Key Credentials from the certificate for the daemon application
        $clientKeyCredentials = New-AzureADApplicationKeyCredential -ObjectId $clientAadApplication.ObjectId `
            -CustomKeyIdentifier $certBase64Thumbprint `
            -Type AsymmetricX509Cert `
            -Usage Verify `
            -Value $certBase64Value `
            -StartDate $certificate.NotBefore `
            -EndDate $certificate.NotAfter
    }

    $currentAppId = $clientAadApplication.AppId
    $clientServicePrincipal = New-AzureADServicePrincipal -AppId $currentAppId -Tags { WindowsAzureActiveDirectoryIntegratedApp }

    # add the user running the script as an app owner if needed
    $owner = Get-AzureADApplicationOwner -ObjectId $clientAadApplication.ObjectId
    if ($owner -eq $null) { 
        Add-AzureADApplicationOwner -ObjectId $clientAadApplication.ObjectId -RefObjectId $user.ObjectId
        LogWrite( "'$($user.UserPrincipalName)' added as an application owner to app '$($clientServicePrincipal.DisplayName)'")
    }

    LogWrite( "Done creating the client application ($appName)")

    # URL of the AAD application in the Azure portal
    # Future? $clientPortalUrl = "https://portal.azure.com/#@"+$tenantName+"/blade/Microsoft_AAD_RegisteredApps/ApplicationMenuBlade/Overview/appId/"+$clientAadApplication.AppId+"/objectId/"+$clientAadApplication.ObjectId+"/isMSAApp/"
    $clientPortalUrl = "https://portal.azure.com/#blade/Microsoft_AAD_RegisteredApps/ApplicationMenuBlade/CallAnAPI/appId/" + $clientAadApplication.AppId + "/objectId/" + $clientAadApplication.ObjectId + "/isMSAApp/"
    # Add-Content -Value "<tr><td>client</td><td>$currentAppId</td><td><a href='$clientPortalUrl'>$appName</a></td></tr>" -Path createdApps.html
    if ($applicationPermissions -or $delegatedPermissions) {
        $requiredResourcesAccess = New-Object System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.RequiredResourceAccess]
        # Add Required Resources Access (from 'client' to 'Microsoft Graph')
        LogWrite( "Getting access from 'client' to 'Microsoft Graph'")
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredApplicationPermissions $applicationPermissions `
            -requiredDelegatedPermissions $delegatedPermissions;
        $requiredResourcesAccess.Add($requiredPermissions)
        Set-AzureADApplication -ObjectId $clientAadApplication.ObjectId -RequiredResourceAccess $requiredResourcesAccess
        LogWrite( "Granted permissions.")
    }

    $app = @{
        tenantId = $tenantId
        name     = $appName
        clientId = $clientAadApplication.AppId
        objectId = $clientAadApplication.ObjectId
        spId     = $clientServicePrincipal.ObjectId
    }
    if ($GeneratePassword) {
        $app.Add("clientSecret", $password.value);
    }
    return $app
} catch 
{
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}
}
# Export-ModuleMember -Function New-AADApplication


Function Start-ConsentRedirectServer {
    <#
    .SYNOPSIS
    This function starts an HTTP server used to display the redirect URI of consent request 
    .PARAMETER baseUri
    The base URI of the server
    .PARAMETER redirectUri
    The relative redirect URI of consent request
    .PARAMETER tenantId
#> 
[CmdletBinding()]
param(
    [string] $baseUri = "http://localhost:23456/",
    [string] $redirectUri = "/consent/redirect"
);
    $http = [System.Net.HttpListener]::new() 
    # Hostname and port to listen on
    $http.Prefixes.Add($baseUri)
    # Start the Http Server 
    $http.Start()
    while ($http.IsListening) {
        $context = $http.GetContext()
        if ($context.Request.HttpMethod -eq 'GET' -and $context.Request.RawUrl.StartsWith($redirectUri)) {

            [string]$html = "<h1>Success of the consent request</h1>" 
            $buffer = [System.Text.Encoding]::UTF8.GetBytes($html) # convert htmtl to bytes
            $context.Response.ContentLength64 = $buffer.Length
            $context.Response.OutputStream.Write($buffer, 0, $buffer.Length) #stream to broswer
            $context.Response.OutputStream.Close() # close the response
            LogWrite( "show consent")
            Start-Sleep -Seconds 5
            break;
        }
    }
}
# Export-ModuleMember -Function Start-ConsentRedirectServer

# Adds the requiredAccesses (expressed as a pipe separated string) to the requiredAccess structure
# The exposed permissions are in the $exposedPermissions collection, and the type of permission (Scope | Role) is 
# described in $permissionType
Function AddResourcePermission($requiredAccess, `
        $exposedPermissions, [string]$requiredAccesses, [string]$permissionType) {
    foreach ($permission in $requiredAccesses.Trim().Split("|")) {
        foreach ($exposedPermission in $exposedPermissions) {
            if ($exposedPermission.Value -eq $permission) {
                $resourceAccess = New-Object Microsoft.Open.AzureAD.Model.ResourceAccess
                $resourceAccess.Type = $permissionType # Scope = Delegated permissions | Role = Application permissions
                $resourceAccess.Id = $exposedPermission.Id # Read directory data
                $requiredAccess.ResourceAccess.Add($resourceAccess)
            }
        }
    }
}

#
# Exemple: GetRequiredPermissions "Microsoft Graph"  "Graph.Read|User.Read"
# See also: http://stackoverflow.com/questions/42164581/how-to-configure-a-new-azure-ad-application-through-powershell
Function GetRequiredPermissions([string] $applicationDisplayName, [string] $requiredDelegatedPermissions, [string]$requiredApplicationPermissions, $servicePrincipal, $appid) {
    # If we are passed the service principal we use it directly, otherwise we find it from the display name (which might not be unique)
    if ($servicePrincipal) {
        $sp = $servicePrincipal
    }
    else {
        if ($appid)
        {
            $sp = Get-AzureADServicePrincipal -Filter "AppId eq '$appid'"
        }
        else {
            $sp = Get-AzureADServicePrincipal -Filter "DisplayName eq '$applicationDisplayName'"
        }
    }
    $appid = $sp.AppId
    $requiredAccess = New-Object Microsoft.Open.AzureAD.Model.RequiredResourceAccess
    $requiredAccess.ResourceAppId = $appid 
    $requiredAccess.ResourceAccess = New-Object System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.ResourceAccess]

    # $sp.Oauth2Permissions | Select Id,AdminConsentDisplayName,Value: To see the list of all the Delegated permissions for the application:
    if ($requiredDelegatedPermissions) {
        AddResourcePermission $requiredAccess -exposedPermissions $sp.Oauth2Permissions -requiredAccesses $requiredDelegatedPermissions -permissionType "Scope"
    }

    # $sp.AppRoles | Select Id,AdminConsentDisplayName,Value: To see the list of all the Application permissions for the application
    if ($requiredApplicationPermissions) {
        AddResourcePermission $requiredAccess -exposedPermissions $sp.AppRoles -requiredAccesses $requiredApplicationPermissions -permissionType "Role"
    }
    return $requiredAccess
}


Function UpdateLine([string] $line, [string] $value) {
    $index = $line.IndexOf('=')
    $delimiter = ';'
    if ($index -eq -1) {
        $index = $line.IndexOf(':')
        $delimiter = ','
    }
    if ($index -ige 0) {
        $line = $line.Substring(0, $index + 1) + " " + '"' + $value + '"' + $delimiter
    }
    return $line
}

Function UpdateTextFile([string] $configFilePath, [System.Collections.HashTable] $dictionary) {
    $lines = Get-Content $configFilePath
    $index = 0
    while ($index -lt $lines.Length) {
        $line = $lines[$index]
        foreach ($key in $dictionary.Keys) {
            if ($line.Contains($key)) {
                $lines[$index] = UpdateLine $line $dictionary[$key]
            }
        }
        $index++
    }

    Set-Content -Path $configFilePath -Value $lines -Force
}


Function Remove-AADApplication {
    <#
    .SYNOPSIS
    This function creates the Azure AD application for the sample in the provided Azure AD tenant 
    .DESCRIPTION
    This function creates the Azure AD application for the sample in the provided Azure AD tenant 
    .PARAMETER Credential
    The credential of the Azure AD user used to create the application. if absent, a dialog is displayed to connect to Azure AD 
    .PARAMETER tenantId
    The Active Directory Tenant. This is a GUID which represents the "Directory ID" of the AzureAD tenant
    into which you want to create the apps. Look it up in the Azure portal in the "Properties" of the Azure AD
    .PARAMETER appName
    The name of the application to be removed
#> 
[CmdletBinding()]
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName
)
# Pre-requisites
try {
    if ((Get-Module -ListAvailable -Name "AzureAD") -eq $null) { 
        Install-Module "AzureAD" -Scope CurrentUser 
    } 
    Import-Module AzureAD
    if (!$Credential -and $TenantId) {
        $creds = Connect-AzureAD -TenantId $tenantId
    }
    else {
        if (!$TenantId) {
            $creds = Connect-AzureAD -Credential $Credential
        }
        else {
            $creds = Connect-AzureAD -TenantId $tenantId -Credential $Credential
        }
    }
    $filter = "DisplayName eq '" + $appName + "'"
    $app = Get-AzureADApplication -Filter $filter
    Remove-AzureADApplication -ObjectId $app.objectId
} catch 
{
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}
}
# Export-ModuleMember -Function Remove-AADApplication

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUfIOmoLtXC19vKVjPNZMB6fp3
# prmgggP3MIID8zCCAtugAwIBAgIQLpa10zB5fZZJdGQByDwH8TANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDExOTExNDYzNVoXDTIyMDExOTEyMDYzNVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALVmo+DF
# MsiYOkxwtmdX/SAyAsA+fe+qAcX05GsJt0VCPjMjfAjZ+wTGEceWhkFjQkFQuMu5
# +nQW02Le4yHCoHXQA5heGajzGReTdJKrTNVu+7m7qjVqtgasvCwkIRzTqQmUx+to
# S+7fLZ2f7TmBs76fYYkgOIlkk60UO36awEfVFeSLR+9IP6rZM6nptkmeMwVd0zil
# HH1attsnntzG30n0cjdmx+wh37ZU/zHvT+pxVa9hr0TN3vp5oIlhJ71Q0fEVAo5p
# h4nzvYT7FtOhjoLjMJxVXkt1eeMiju2/EpJfiSPy144XHqOHJEJmA5vspOe7+1R8
# HMW2bveTJxKC0BUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTvlQFKuWkZlTC6h0TwG1amC06HDDANBgkqhkiG9w0BAQsFAAOCAQEAMJEZ
# j6x5YsTmy5qgYIw94wWShMtN5AWqWPiscstJF8fVvFSZTxu1hLKW7peF6Q5hESep
# GG24M24q0bGOzU8ol3/Vez74UIU3k+S/GuTrso1vyf3CsDRoxoS3wsLh3eS+Bwxh
# kAqUhf/Ta4QAF5CqntDBCS2sS6zNDWuo6w7lLBw1VtV/EN78Ji8OGjEkOkD8830p
# uIN1NqV21CPt/TaoFmVlJZPOLRBKiGQehEnDFszZx/u2dCOSKf90NYvbnOAtDuZe
# Z1KUtTk45XDnv28rlfRv3OQvQv+GrHzlGtCkzed0Fo/PpCIYUY6jH6ae5b9AiBuc
# ANLlFRySKSBcVrWOSjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEC6WtdMweX2WSXRkAcg8B/EwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFHo3LrrWIB+/aI/CoNODQyi+uqOFMA0GCSqGSIb3DQEBAQUABIIBAGwveyOI
# SD4lcEVtPUgtI4RUA15A5d6M5V65Y1aT6uHpqvjwu4vAs91nCQ3V9XMYQoe6KWVa
# 58wbWKWoTUxu6xAs9IHrs9ZpqjyGSXMeB6RZdHIERYWjFg60slvIWU/+4f5LNG2y
# /0UUq9LqToPWK9Y0WZiLk9T+FUEMr9QbRPFAI7o3yno6Qukq38m/p/IPxHarX1jc
# VSCQb5trWCLAxzhsU0z2xHCknSLxGtoECzc54uXihWxaf8i3OMe408A12yrt7iDZ
# AKe81TOSeXNgjOv9wa5TAnXmQIDQ7CIWiYBnjE6TGWOpI/RY1Gn7QeZdd0ixcTnz
# IICLt7TtCu9gnTQ=
# SIG # End signature block
