﻿<#
.SYNOPSIS
This script permits to write an inventory of PNC informations to an Excel file.
.DESCRIPTION
This script permits to write an inventory of PNC informations to an Excel file.
The result is saved in the Excel file in a worksheet bearing today's date. If the tab already exists it is replaced.
Warning, this script file must be encoded in UTF8 with BOM so that the accented characters are correctly displayed in the Excel file

The user can modify the following script variables (at the start):
- $servers which defines the array of objects associated with the servers to query.
   Each object must at least contain the property "ip" or "host" which gives the address (or domain) of the Plugncast server. 
   It can also contain the properties:
    - port that defines the HTTPS port of server,
    - username that defines the authentication user,
    - password that defines the authentication password.
    (otherwise the default values will be: 443, "superadmin", "superadmin").
    Each object can contain other properties which are not used by the function and which are returned unchanged.
- $header which defines the array of columns names. it must contain the name associated with the fields
    - 'ip' (the 'login', 'password' and 'port' fields are not displayed),
    - to the added free fields
    - to the fields added by the Get-PncInventory function:
        - pncVersion: version of the Plugncast server,
        - nbDomain: number of domains,
        - domainNames: domain names separated by newlines,
        - licenseMail : the mail used with license,
        - nbLicenseDomain: number of valid licenses of domain,
        - nbLicensePlayzillaValid: number of valid license of playzilla,
        - nbLicensePlayzillaWithDomain: number of valid license of playzilla with domain associated,
        - nbLicensePlayzillaWithoutDomain: number of valid license of playzilla without domain associated,
        - nbLicensePlayzillaInvalid: number of invalid license of playzilla.
.PARAMETER excelFilePath
The path of the excel file path. The default value is ".\Inventory-INNES_PlugnCast.xlsx"
.PARAMETER logFile
The path of log file
.EXAMPLE
PS C:\install directory>.\Write-PncInventoryToExcel -excelFilePath ".\output.xlsx"
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$false)]
    [string] $excelFilePath = ".\Inventory-INNES_PlugnCast.xlsx",
    [string] $LogFile
)
#-----------------------------------------------------------------------------------------------------------
#               Array of servers to edit
# Each object must at least contain the property "ip" or "host" which gives the address (or domain) of the Plugncast server. 
# It can also contain the properties:
# - port that defines the HTTPS port of server,
# - username that defines the authentication user,
# - password that defines the authentication password.
# Each object can contain other properties which are not used by the function and which are returned unchanged (example field1, field2, ...).
#-----------------------------------------------------------------------------------------------------------
[System.Collections.ArrayList]$servers = @(
    [PSCustomObject]@{ip="192.168.1.45";port="8443";login="superadmin";password="superadmin";field1="Field1 value1";field2="Field2 value1"}
    [PSCustomObject]@{ip="192.168.1.10";port="443";login="superadmin";password="superadmin";field1="Field1 value2";field2="Field2 value2"}
)
#-----------------------------------------------------------------------------------------------------------
#             Array of column names to edit
# The array must contain the names of the fields in the $servers array in the same order (except "login", "password" and "port").
# It must also define, at the end, the names of the fields added by the Get-Inventory function.
# So you can modify the first line, from "Field1", and modify the labels of the next 2 lines.
#-----------------------------------------------------------------------------------------------------------
$header=@("IP";"Field1";"Field2";`
"Version";"Domains";"Domain names";"License email";"Valid domain licenses";"Valid Playzilla licenses";`
"Valid Playzilla licenses with domain";"Valid Playzilla licenses without domain";"Invalid Playzilla licenses")

#-----------------------------------------------------------------------------------------------------------
#                  Do not modify anything after this line
#-----------------------------------------------------------------------------------------------------------
# Import Pnc Module
Import-Module PSPnc
# Import Module PSExcel
Import-Module PSExcel
# Clear the log file of any previous try
If ($LogFile -and (Test-Path $LogFile) -eq $True) {
    Remove-Item -Path $LogFile
}
$verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)

# Get the inventory
Write-Host("Start to query the Pnc server(s)...")
$result = Get-PncInventory $servers -LogFile $LogFile -vb:$verbose
# compute result
$nbLicensePlayzillaValid = 0
$nbLicenseDomain = 0
$nbDomain = 0;
$nbKO = 0;
function Remove-Property($server, $name)
{
    if ($name -in $server.PSobject.Properties.Name) {
        $server.PSObject.properties.remove($name)
    }
}
[System.Collections.ArrayList]$errors= @()
foreach ($server in $result) {
    Remove-Property $server "login"
    Remove-Property $server "password"
    Remove-Property $server "port"
    if ($server.status -eq "OK") {
        $nbDomain += $server.nbDomain
        $nbLicensePlayzillaValid += $server.nbLicensePlayzillaValid;
        $nbLicenseDomain += $server.nbLicenseDomain
        $errors.Add($false) | Out-Null
    }
    else {
        $errors.Add($true) | Out-Null
        $nbKO++
    }
    Remove-Property $server "status"
}
if ($nbKO)
{
    Write-Warning("Warning, some servers (" + $nbKO + ") did not respond")
}
Write-Host("Write the result...")
# Write Excel file
$worksheetName=Get-Date -Format "dd.MM.yyyy"
$result | Export-XLSX -Path $excelFilePath -header $header -Autofit -WorksheetName $worksheetName -ReplaceSheet
# Re-open the file
$Excel = New-Excel -Path $excelFilePath
$WorkSheet = $Excel | Get-WorkSheet -Name $worksheetName
$Excel.Workbook.View.ActiveTab=$WorkSheet.Index-1
# Computes additional informations
$row = $result.Length + 4
$col = 2
$cell = $WorkSheet.Cells.Item($row, $col)
$cell.value = "Total:"; 
$cell.Style.Font.Bold =$True
$row++
$WorkSheet.Cells.Item($row, $col).value = "Number of domains"; 
$WorkSheet.Cells.Item($row, $col+1).value = $nbDomain; 
$row++
$WorkSheet.Cells.Item($row, $col).value = "Valid domain licenses"; 
$WorkSheet.Cells.Item($row, $col+1).value = $nbLicenseDomain; 
$row++
$WorkSheet.Cells.Item($row, $col).value = "Valid Playzilla licenses"; 
$WorkSheet.Cells.Item($row, $col+1).value = $nbLicensePlayzillaValid; 
# Format the worksheek
$WorkSheet | Format-Cell -HorizontalAlignment "center" -VerticalAlignment "center" -Autofit -WrapText $true 
$WorkSheet | Format-Cell -Header -Bold $True 
for ($i = 0; $i -lt $errors.Count; $i++)
{
    if ($errors[$i])
    {
        $row = $i+2
        $WorkSheet | Format-Cell -StartRow $row -EndRow $row -Color Red
    }
}
# Save file
$Excel | Close-Excel -Save
Write-Host("The result is in the file " + $excelFilePath)

