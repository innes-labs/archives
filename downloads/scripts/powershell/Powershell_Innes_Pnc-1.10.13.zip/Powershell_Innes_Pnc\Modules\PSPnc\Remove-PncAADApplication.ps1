Function Remove-PncAADApplication {
<# 
.SYNOPSIS
This function remove the Azure AD application for Plugncast  
.DESCRIPTION
This function remove the Azure AD application for Plugncast  
.PARAMETER Credential
The credential of the Azure AD user used to remove the application. if absent, a dialog is displayed to connect to Azure AD 
.PARAMETER tenantId
The Active Directory Tenant. This is a GUID which represents the "Directory ID" of the AzureAD tenant
into which you want to create the apps. Look it up in the Azure portal in the "Properties" of the Azure AD
.PARAMETER appName
The name of the application 

.OUTPUTS
Nothing
 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $false)]
    [string] $appName = "Plugncast"
)

$date = Get-Date
LogWrite("$date : delete AAD application with name `"$appName`"")

Remove-AADApplication -credential $Credential -tenantId $tenantId -appName $appName 
LogWrite("Application removed")

}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUrgDx0YmQCZ4qEp5GOELpow88
# eyqgggP3MIID8zCCAtugAwIBAgIQLpa10zB5fZZJdGQByDwH8TANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDExOTExNDYzNVoXDTIyMDExOTEyMDYzNVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALVmo+DF
# MsiYOkxwtmdX/SAyAsA+fe+qAcX05GsJt0VCPjMjfAjZ+wTGEceWhkFjQkFQuMu5
# +nQW02Le4yHCoHXQA5heGajzGReTdJKrTNVu+7m7qjVqtgasvCwkIRzTqQmUx+to
# S+7fLZ2f7TmBs76fYYkgOIlkk60UO36awEfVFeSLR+9IP6rZM6nptkmeMwVd0zil
# HH1attsnntzG30n0cjdmx+wh37ZU/zHvT+pxVa9hr0TN3vp5oIlhJ71Q0fEVAo5p
# h4nzvYT7FtOhjoLjMJxVXkt1eeMiju2/EpJfiSPy144XHqOHJEJmA5vspOe7+1R8
# HMW2bveTJxKC0BUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTvlQFKuWkZlTC6h0TwG1amC06HDDANBgkqhkiG9w0BAQsFAAOCAQEAMJEZ
# j6x5YsTmy5qgYIw94wWShMtN5AWqWPiscstJF8fVvFSZTxu1hLKW7peF6Q5hESep
# GG24M24q0bGOzU8ol3/Vez74UIU3k+S/GuTrso1vyf3CsDRoxoS3wsLh3eS+Bwxh
# kAqUhf/Ta4QAF5CqntDBCS2sS6zNDWuo6w7lLBw1VtV/EN78Ji8OGjEkOkD8830p
# uIN1NqV21CPt/TaoFmVlJZPOLRBKiGQehEnDFszZx/u2dCOSKf90NYvbnOAtDuZe
# Z1KUtTk45XDnv28rlfRv3OQvQv+GrHzlGtCkzed0Fo/PpCIYUY6jH6ae5b9AiBuc
# ANLlFRySKSBcVrWOSjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEC6WtdMweX2WSXRkAcg8B/EwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFGUgSiAt5oSOd0dO0F089uq86kn/MA0GCSqGSIb3DQEBAQUABIIBAJOh9T3a
# alBdULsrGrq3pGytVumg3a61oY4aHWawpFjXncRaio8FBi8E3nt6uG4Qof8K/n6f
# /it++VjymbLrNwK4EZn8GX7HqQW6kxVscXlbPUelJhJ42ZmwO4btWq0pfA8zh+Rl
# Cli0pbjd7JRTB7qHqu9kuDTGDwGQBolj28nOsZwNo/0z3RAH6cyjHU23ldni5CHm
# PQcX6MGKfDKv/3yc0AmxyrdGrdTAvyxkeP6/laDnySDXZd0XygVp9vTGPpFTijsh
# pAr71pLT1G9e8iKjk9ONItW/aX5aZvlUN6GVQmWwsDbIxBwEaxe/rFur+LS0pHE6
# DyDUe3HF41zZzWQ=
# SIG # End signature block
