Function New-PncAADApplication {
<# 
.SYNOPSIS
This function creates the Azure AD application for Plugncast  
.DESCRIPTION
The application created can be used to create Azure AD provider with New-PncOpenIdProviderAAD function. 
.PARAMETER Credential
The credential of the Azure AD user used to create the application. if absent, a dialog is displayed to connect to Azure AD 
.PARAMETER tenantId
The Active Directory Tenant. This is a GUID which represents the "Directory ID" of the AzureAD tenant
into which you want to create the apps. Look it up in the Azure portal in the "Properties" of the Azure AD
.PARAMETER appName
The name of the application 
.PARAMETER pncUrlHost
The host (ip or domain) of Plugncast server.
.PARAMETER pncUrlPort
The port of Plugncast server
.PARAMETER logFile
The path of log file

.OUTPUTS
The object that describe the application created. This object is already dumped in the file names "<appName>.json"
Its contains the following properties:
name : the application name
tenantId : the tenant id
clientId : the client id of application
objectId : the object id of application
clientSecret: the client secret generated (present only if parameter GeneratePassword is $true)
spId : the service pricipal id of application

 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $false)]
    [string] $appName = "Plugncast",
    [Parameter(Mandatory = $true)]
    [string] $pncUrlHost,
    [string] $pncUrlPort,
    [string] $LogFile
)
$Server=$pncUrlHost
if ($pncUrlPort) {
   $Server += ":" + $pncUrlPort
}
$BaseServerUri = "https://$Server/.plugncast"

$date = Get-Date
LogWrite("$date : create new AAD application with name `"$appName`" for server `"$server`"")

[String[]] $replyUrls= @("$BaseServerUri/openid/login/redirect", "$BaseServerUri/openid/adminconsent/redirect")
$logoutUrl="$BaseServerUri/openid/logout"
$homepage="https://$Server/cms"

$app = New-AADApplication -credential $Credential -tenantId $tenantId -appName $appName `
        -ReplyUrls $replyUrls -logoutUrl $logoutUrl -homepage $homepage `
      -generatePassword $true -applicationPermissions "User.Read.All|Group.Read.All|GroupMember.Read.All"

Set-Content -Path ".\$appName.json" -Value ($app | ConvertTo-Json -Depth 5)
LogWrite("Application created")
$app
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUI8sMAcvYQcRi9wP6nw7FvorO
# n66gggP3MIID8zCCAtugAwIBAgIQLpa10zB5fZZJdGQByDwH8TANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDExOTExNDYzNVoXDTIyMDExOTEyMDYzNVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALVmo+DF
# MsiYOkxwtmdX/SAyAsA+fe+qAcX05GsJt0VCPjMjfAjZ+wTGEceWhkFjQkFQuMu5
# +nQW02Le4yHCoHXQA5heGajzGReTdJKrTNVu+7m7qjVqtgasvCwkIRzTqQmUx+to
# S+7fLZ2f7TmBs76fYYkgOIlkk60UO36awEfVFeSLR+9IP6rZM6nptkmeMwVd0zil
# HH1attsnntzG30n0cjdmx+wh37ZU/zHvT+pxVa9hr0TN3vp5oIlhJ71Q0fEVAo5p
# h4nzvYT7FtOhjoLjMJxVXkt1eeMiju2/EpJfiSPy144XHqOHJEJmA5vspOe7+1R8
# HMW2bveTJxKC0BUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTvlQFKuWkZlTC6h0TwG1amC06HDDANBgkqhkiG9w0BAQsFAAOCAQEAMJEZ
# j6x5YsTmy5qgYIw94wWShMtN5AWqWPiscstJF8fVvFSZTxu1hLKW7peF6Q5hESep
# GG24M24q0bGOzU8ol3/Vez74UIU3k+S/GuTrso1vyf3CsDRoxoS3wsLh3eS+Bwxh
# kAqUhf/Ta4QAF5CqntDBCS2sS6zNDWuo6w7lLBw1VtV/EN78Ji8OGjEkOkD8830p
# uIN1NqV21CPt/TaoFmVlJZPOLRBKiGQehEnDFszZx/u2dCOSKf90NYvbnOAtDuZe
# Z1KUtTk45XDnv28rlfRv3OQvQv+GrHzlGtCkzed0Fo/PpCIYUY6jH6ae5b9AiBuc
# ANLlFRySKSBcVrWOSjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEC6WtdMweX2WSXRkAcg8B/EwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFOt1oqCmSBJNZfyoPbcAiao1e6eEMA0GCSqGSIb3DQEBAQUABIIBAIXo2s3m
# F2A0pdT7ZVsNz66m8Nu/YTkttFulLxe3A/MInMcy6Pixe0cH9l3fybPq2OP58agp
# 6irM+zkQXuRvrNgz87SIiov7mBwwzBxUKg3gBAFWJL8U7Ad0Q/vDhdWTjN9ZzLvw
# g7nsk4OVgn0js8mmQ/cgZ9ja1w7WQp5FVIsChhLb9GSfHWHahEHLpioH9WDdO3+N
# R5+XRY5g+JmCca3ngrJsbaG1ZsWI5mTudb5swbj6Zuy+98X/9m8SiKaaknKvU7eu
# aPEK77VUu5udTIogAsnz3OhmRvfSEegEwPBzWhuslB07U9AzPto8RihCyO2o8k+1
# SYaQDZ6VG2BgU4g=
# SIG # End signature block
