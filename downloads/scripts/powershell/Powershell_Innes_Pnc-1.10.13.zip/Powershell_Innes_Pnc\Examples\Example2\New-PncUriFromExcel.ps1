<#
.SYNOPSIS
   PlugnCast : .URI generator from MS-Excel
.DESCRIPTION
  Requires the installation of the PSExcel Powershell module:
  Launch a Powershell console with administrator user and type
   > Install-Module -Name PSExcel

  MS-Excel format : 
  id	name	scheme	address	    port	thumbnail
  1	    TF1	    udp://	225.1.1.1	1234	./assets/tf1.png
.PARAMETER excelFileList
The list of MS-Excel file path (absolute or relative) describing the .URI files to generate.
.PARAMETER outputDirectory
The directory containing the generated URI files (default "./output")
.EXAMPLE
New-UriFromExcel.ps1 channels.xlsx
#>
 
[CmdletBinding()]
Param
(
    [string[]] $excelFileList = "./channels.xlsx",
    [string] $outputDirectory = "./output"
)

Begin
{
    $verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
    Import-Module PSPnc   
    Import-Module PSExcel
    function Write-UriFile {
        param (
            [Parameter(Mandatory = $True, ValueFromPipeline = $true)]
            [Object[]] $in,

            [Parameter(Mandatory = $true)]
            [String] $filename
        ) 
        process {
                
            $_filename1 = $filename.Split([IO.Path]::GetInvalidFileNameChars()) -join '_'
            $_filename = "./output/" + $_filename1 + ".uri"
            add-content -path $_filename $in
        }
    }
    function New-UriFromExcelFile($path){
        $datas = Import-XLSX -RowStart 1  -Path $path
        foreach($data in $datas ){
            $uri =  "{0}{1}:{2}" -f $data.scheme, $data.address, $data.port
            $thumbnail = $data.thumbnail
            if ($thumbnail.Contains("/"))
            {
                $thumbnail = $thumbnail.Replace("/", "`\");
            }
            if ($thumbnail.StartsWith("."))
            {
                $thumbnail = [string] (Get-Location) + "\" + $thumbnail
            }
            $tokens= @{IMG= $img; CATEGORY= 'IPTV'; TITLE=$data.name ; URI=$uri}
            New-PncUri -uri $uri -thumbnail $thumbnail -title $data.name -category 'IPTV' -vb:$verbose `
               | Write-UriFile -filename $data.name 
        }
    }     
}


Process
{
    foreach($n in $excelFileList){
        $PSDefaultParameterValues['*:Encoding'] = 'utf8'
        if (Test-Path $outputDirectory) {
            Remove-Item -Path $outputDirectory/*.uri -Force
        }
        else {
            New-Item -ItemType Directory -Force -Path $outputDirectory
        }
        $path = (resolve-path $n).Path
        Write-Verbose "Converting $path"
        New-UriFromExcelFile -path $path
        Write-Verbose "End of Job"
    }
}
End
{
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUkSVFMt0iKwQeD/ZqASggJ56x
# x3+gggP3MIID8zCCAtugAwIBAgIQLpa10zB5fZZJdGQByDwH8TANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDExOTExNDYzNVoXDTIyMDExOTEyMDYzNVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALVmo+DF
# MsiYOkxwtmdX/SAyAsA+fe+qAcX05GsJt0VCPjMjfAjZ+wTGEceWhkFjQkFQuMu5
# +nQW02Le4yHCoHXQA5heGajzGReTdJKrTNVu+7m7qjVqtgasvCwkIRzTqQmUx+to
# S+7fLZ2f7TmBs76fYYkgOIlkk60UO36awEfVFeSLR+9IP6rZM6nptkmeMwVd0zil
# HH1attsnntzG30n0cjdmx+wh37ZU/zHvT+pxVa9hr0TN3vp5oIlhJ71Q0fEVAo5p
# h4nzvYT7FtOhjoLjMJxVXkt1eeMiju2/EpJfiSPy144XHqOHJEJmA5vspOe7+1R8
# HMW2bveTJxKC0BUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTvlQFKuWkZlTC6h0TwG1amC06HDDANBgkqhkiG9w0BAQsFAAOCAQEAMJEZ
# j6x5YsTmy5qgYIw94wWShMtN5AWqWPiscstJF8fVvFSZTxu1hLKW7peF6Q5hESep
# GG24M24q0bGOzU8ol3/Vez74UIU3k+S/GuTrso1vyf3CsDRoxoS3wsLh3eS+Bwxh
# kAqUhf/Ta4QAF5CqntDBCS2sS6zNDWuo6w7lLBw1VtV/EN78Ji8OGjEkOkD8830p
# uIN1NqV21CPt/TaoFmVlJZPOLRBKiGQehEnDFszZx/u2dCOSKf90NYvbnOAtDuZe
# Z1KUtTk45XDnv28rlfRv3OQvQv+GrHzlGtCkzed0Fo/PpCIYUY6jH6ae5b9AiBuc
# ANLlFRySKSBcVrWOSjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEC6WtdMweX2WSXRkAcg8B/EwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFJtYJ6UjC2d+lYzWgTS+MXb5/PLLMA0GCSqGSIb3DQEBAQUABIIBABjDsndi
# Y/BxZ9Pc9mE1mpe1UpmQKYE2lPlppUqo9wcC9N686CXuMA31Z+l8t5wAoaYUkrpM
# iPYHbBb6tAHmqieBikZrEGc+VobaVP9JQoE7IliBp9g8OpkiqqqfY3UB79MgP5Lh
# NLD4nj0gzk03vduZP/0HDWkDCigeG7Lf+tjm24wHw/rUyuE1GpSHV3M378/687q3
# YeCT2x+xfW8j8CKkNdxLIMtSBVG9MasYTA40NIyG+RrVoEzwkFcK3re3TR4KSBKm
# LQO9bUpvOHOap9fH3wm9OzjgEtzObXjdmAS2F/o+NkN3zHRTZrGr2wxPeH2la4Qk
# hSN009uGr15FEP4=
# SIG # End signature block
