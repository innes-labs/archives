Function Get-PncAppi {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve all installed APPIs
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve all installed APPIs
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS 
The powershell object that describes all installed APPIs.
Example of object formated in JSON :
{
    "urn:innes:system-app#playzilla":  {
        "nbValidTokens":  0,
        "versions":  {
            "4.10.19":  {
                ...
            }
            ...
        }
         "domains":  {
            "domain1":  {
                "nbValidTokens":  0
            }
          },
        "hiddenDomains":  false,
        "id":  "urn:innes:system-app#playzilla",
        "hiddenLicenses":  false,
        "licenses":  {
             "PSN00690-00000 CD5":  {
                 "label":  "playzilla",
                 "valid":  false,
                  "license":  "xxxx - xxxx - xxxx - xxxx - xxxxx",
                 "domain":  "domain1",
                 "hiddenDomain":  false
             },
              ...
           }
        }
    }
    ...
}
.EXAMPLE
Get-PncAppi -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve appis for server `"$server`"")

 

$Body = @{
    target = "nsIAppliAppis.list"
}
$JsonBody = $Body | ConvertTo-Json
Start-Sleep -m $SleepDurationBeforeCommand

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}

$AppisObject = $ExecutedRequest | ConvertFrom-Json
# Filter null domain 
foreach ($prop in $AppisObject.PsObject.Properties)
{
    $appi = $prop.Value
    foreach ($prop in $appi.licenses.PsObject.Properties) {
        $license = $prop.Value
        if (!$license.domain)
        {
            $license.domain = ""
        }
    }
}
LogWrite($AppisObject | ConvertTo-Json -Depth 5)
$AppisObject
}




# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUOn/PWgRkKrikNpB4xvvqdiEb
# hdGgggP3MIID8zCCAtugAwIBAgIQLpa10zB5fZZJdGQByDwH8TANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDExOTExNDYzNVoXDTIyMDExOTEyMDYzNVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALVmo+DF
# MsiYOkxwtmdX/SAyAsA+fe+qAcX05GsJt0VCPjMjfAjZ+wTGEceWhkFjQkFQuMu5
# +nQW02Le4yHCoHXQA5heGajzGReTdJKrTNVu+7m7qjVqtgasvCwkIRzTqQmUx+to
# S+7fLZ2f7TmBs76fYYkgOIlkk60UO36awEfVFeSLR+9IP6rZM6nptkmeMwVd0zil
# HH1attsnntzG30n0cjdmx+wh37ZU/zHvT+pxVa9hr0TN3vp5oIlhJ71Q0fEVAo5p
# h4nzvYT7FtOhjoLjMJxVXkt1eeMiju2/EpJfiSPy144XHqOHJEJmA5vspOe7+1R8
# HMW2bveTJxKC0BUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTvlQFKuWkZlTC6h0TwG1amC06HDDANBgkqhkiG9w0BAQsFAAOCAQEAMJEZ
# j6x5YsTmy5qgYIw94wWShMtN5AWqWPiscstJF8fVvFSZTxu1hLKW7peF6Q5hESep
# GG24M24q0bGOzU8ol3/Vez74UIU3k+S/GuTrso1vyf3CsDRoxoS3wsLh3eS+Bwxh
# kAqUhf/Ta4QAF5CqntDBCS2sS6zNDWuo6w7lLBw1VtV/EN78Ji8OGjEkOkD8830p
# uIN1NqV21CPt/TaoFmVlJZPOLRBKiGQehEnDFszZx/u2dCOSKf90NYvbnOAtDuZe
# Z1KUtTk45XDnv28rlfRv3OQvQv+GrHzlGtCkzed0Fo/PpCIYUY6jH6ae5b9AiBuc
# ANLlFRySKSBcVrWOSjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEC6WtdMweX2WSXRkAcg8B/EwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFAH9Oe0xZXEsnom3MoJw2QkugSpMMA0GCSqGSIb3DQEBAQUABIIBAGvLYNIV
# feVGcIHJ0V/cnQiVKARZZ4sdCcpUXzxNarhhaOi+vZQPm6vsGTJk20UVm1wFe49G
# 7lvQhDymGuHZRGnuNiuRfVTyGhw5iP9z+S8OWhczgUorZV6naCAaZ3qfArNwWSZx
# 5n/6us4BKIu7iryPm3aC8+4a9i7XjgApvRnB/AxyWQf7wmP93l0+aLYHI66O83y1
# 3LXRIAxiYkyr3kF2wTpjlulPCRrNx+tLoABHC3rI+kcX78vLfbbSD5evfWruqz+r
# muN5IcjAeT5uZGEqOfffA/HBacMP+F3Gakqp6JGYBFbgjfYWOUmQ0piUl7ePsLjR
# 8AvWJzNWVR6ijnA=
# SIG # End signature block
