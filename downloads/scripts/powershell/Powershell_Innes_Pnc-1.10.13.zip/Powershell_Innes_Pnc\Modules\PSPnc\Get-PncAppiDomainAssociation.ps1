Function Get-PncAppiDomainAssociation {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the domains of an APPI
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the domains of an APPI
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER appi
The name of appi (playzilla) or identificator of appi (urn:innes:system-app#playzilla)
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell object that describes the domains of the APPI
Example of object formated in JSON :
{
    "nbDomains":  1,
    "domains":  [
                    {
                        "name":  "domain1",
                        "version":  null,
                        "nbLicenses":  9,
                        "licenses":  [ ... ]
                    }
    ]
}
.EXAMPLE
Get-PncAppiDomainAssociation -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [Parameter(Mandatory=$true)]
    [string] $appi,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$urn = "urn:innes:system-app#"
if (!$appi.StartsWith($urn))
{
    $appi = $urn + $appi
}

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve domains of APPI `"$appi`" for server `"$server`"")

 

$Body = @{
    target = "nsIAppliAppis.get"
}
[System.Collections.ArrayList]$argsArray = @()
$argsArray.Add($appi) | Out-Null
$Body | Add-Member -MemberType NoteProperty -Name args -Value $argsArray | Out-Null
$JsonBody = $Body | ConvertTo-Json

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}
$appiObject = $ExecutedRequest | ConvertFrom-Json
$result = [PSCustomObject]@{
    nbDomains = 0
}
$unsetDomain = "@unset@"
$domainsLicensesMap = [PSCustomObject]@{}
foreach ($prop in $appiObject.licenses.PsObject.Properties)
{
    $psn = $prop.Name;
    $license = $prop.Value
    $domain = $license.domain
    $l = [PSCustomObject]@{
        psn = $psn
        label = $license.label
        valid = $license.valid
        license = $license.license
    }
    if ($license.valid) {
        $l  | Add-Member -MemberType NoteProperty -Name expired -Value $license.expired | Out-Null
    }
    if ($license.PSObject.Properties['expireDate'])
    {
        $l  | Add-Member -MemberType NoteProperty -Name expireDate -Value $license.expireDate | Out-Null
    }
    if (!$domain)
    {
        $domain = $unsetDomain
    }
    $d = $domainsLicensesMap.$domain
    if (!$d)
    {
        $d = [PSCustomObject]@{nbLicenses = 1}
        [System.Collections.ArrayList]$licenses = @()
        $licenses.Add($l) | Out-Null
        $d | Add-Member -MemberType NoteProperty -Name licenses -Value $licenses | Out-Null
        $domainsLicensesMap | Add-Member -MemberType NoteProperty -Name $domain -Value $d | Out-Null
    }
    else {
        $d.nbLicenses++
        $d.licenses.Add($l) | Out-Null
    }
}
$domainsVersionsMap = [PSCustomObject]@{}
foreach ($prop in $appiObject.versions.PsObject.Properties)
{
    $version = $prop.Name;
    $obj = $prop.Value
    foreach ($domain in $obj.domains) {
        $d = $domainsVersionsMap.$domain
        if (!$d) {
            $d = [PSCustomObject]@{}
            [System.Collections.ArrayList]$versions = @()
            $versions.Add($version) | Out-Null
            $d | Add-Member -MemberType NoteProperty -Name versions -Value $versions | Out-Null
            $domainsVersionsMap | Add-Member -MemberType NoteProperty -Name $domain -Value $d | Out-Null
        }
        else {
            $d.versions.Add($l) | Out-Null
        }
    }
}
[System.Collections.ArrayList]$domainArray = @()
foreach ($prop in $appiObject.domains.PsObject.Properties)
{
        $result.nbDomains += 1
        $name = $prop.Name
        $domain = $prop.Value
        $d = [PSCustomObject]@{
            name = $name
        }
        if ($domain.version)
        {
            $d | Add-Member -MemberType NoteProperty -Name version -Value $domain.version | Out-Null
        }
        if ($domainsLicensesMap.$name)
        {
            $d | Add-Member -MemberType NoteProperty -Name nbLicenses -Value $domainsLicensesMap.$name.nbLicenses | Out-Null
            $d | Add-Member -MemberType NoteProperty -Name licenses -Value $domainsLicensesMap.$name.licenses | Out-Null
        }
        else {
            $d | Add-Member -MemberType NoteProperty -Name nbLicenses -Value 0 | Out-Null
        }
        $domainArray.Add($d) | Out-Null
}
$result | Add-Member -MemberType NoteProperty -Name domains -Value $domainArray | Out-Null
if ($domainsLicensesMap.$unsetDomain)
{
    $result | Add-Member -MemberType NoteProperty -Name nbUnusedLicenses -Value $domainsLicensesMap.$unsetDomain.nbLicenses | Out-Null
    $result | Add-Member -MemberType NoteProperty -Name unusedLicenses -Value $domainsLicensesMap.$unsetDomain.licenses | Out-Null
}
else {
    $result | Add-Member -MemberType NoteProperty -Name nbUnusedLicenses -Value 0 | Out-Null
}
LogWrite($result | ConvertTo-Json -Depth 5)
$result 
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU+71fZSKsJ2IZBuObC5ac9aQR
# XcagggP3MIID8zCCAtugAwIBAgIQLpa10zB5fZZJdGQByDwH8TANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDExOTExNDYzNVoXDTIyMDExOTEyMDYzNVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALVmo+DF
# MsiYOkxwtmdX/SAyAsA+fe+qAcX05GsJt0VCPjMjfAjZ+wTGEceWhkFjQkFQuMu5
# +nQW02Le4yHCoHXQA5heGajzGReTdJKrTNVu+7m7qjVqtgasvCwkIRzTqQmUx+to
# S+7fLZ2f7TmBs76fYYkgOIlkk60UO36awEfVFeSLR+9IP6rZM6nptkmeMwVd0zil
# HH1attsnntzG30n0cjdmx+wh37ZU/zHvT+pxVa9hr0TN3vp5oIlhJ71Q0fEVAo5p
# h4nzvYT7FtOhjoLjMJxVXkt1eeMiju2/EpJfiSPy144XHqOHJEJmA5vspOe7+1R8
# HMW2bveTJxKC0BUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTvlQFKuWkZlTC6h0TwG1amC06HDDANBgkqhkiG9w0BAQsFAAOCAQEAMJEZ
# j6x5YsTmy5qgYIw94wWShMtN5AWqWPiscstJF8fVvFSZTxu1hLKW7peF6Q5hESep
# GG24M24q0bGOzU8ol3/Vez74UIU3k+S/GuTrso1vyf3CsDRoxoS3wsLh3eS+Bwxh
# kAqUhf/Ta4QAF5CqntDBCS2sS6zNDWuo6w7lLBw1VtV/EN78Ji8OGjEkOkD8830p
# uIN1NqV21CPt/TaoFmVlJZPOLRBKiGQehEnDFszZx/u2dCOSKf90NYvbnOAtDuZe
# Z1KUtTk45XDnv28rlfRv3OQvQv+GrHzlGtCkzed0Fo/PpCIYUY6jH6ae5b9AiBuc
# ANLlFRySKSBcVrWOSjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEC6WtdMweX2WSXRkAcg8B/EwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFEtar29bUvPxGJYQQLficIhm7raxMA0GCSqGSIb3DQEBAQUABIIBAB39L+mh
# GbZs03TJfUMTDpK4NUER5OUFdl/fGzS6Rv4WzksIpdv1/e0XVvupr6qcIdByvDAx
# SzuYS2tmFEdYgY5jB9hntRwEUBmnntj4MSgk47Ojw7SJLJL8Vi7sky7UArYPUNmk
# bZbeJN/Cva2nSVlmIx/G2Bgc0Q45cpxhN1NwBH2UdPxRve0urgEzQJoXzcTwiM5D
# NTx+El+koTcCi6DEBkPqIy4t78gfkPuzH0AvvOEonxVW/LL9C62ndAtCMGjTeP0E
# Wdw904LzOf4hcJI7HdqX49qM1h58z5MRGKL2twpe0bbGIFV9IfNKrwtAcpX+HPLx
# 4CYhTzwNkPp9DXA=
# SIG # End signature block
