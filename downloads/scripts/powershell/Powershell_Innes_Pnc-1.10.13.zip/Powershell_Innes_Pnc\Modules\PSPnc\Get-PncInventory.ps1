# Load utilities
Function Get-PncInventory {
<# 
.SYNOPSIS
This function queries a array of Plugncast G3 server to create an inventory.
.DESCRIPTION
The function uses as input a array of objects associated with the servers to be queried. 
Each object must at least contain the property "ip" or "host" which gives the address (or domain) of the Plugncast server. 
It can also contain the properties:
- port that defines the HTTPS port of server,
- username that defines the authentication user,
- password that defines the authentication password.
Each object can contain other properties which are not used by the function and which are returned unchanged.

The output of the function is the input array to which the
following properties are added to each object:
- status: which is "OK" if the server answered, "KO" otherwise
- pncVersion: version of the Plugncast server,
- nbDomain: number of domains,
- domainNames: domain names separated by newlines,
- licenseMail : the mail used with license,
- nbLicenseDomain: number of valid licenses of domain,
- nbLicensePlayzillaValid: number of valid license of playzilla,
- nbLicensePlayzillaWithDomain: number of valid license of playzilla with domain,
- nbLicensePlayzillaWithoutDomain: number of valid license of playzilla without domain,
- nbLicensePlayzillaInvalid: number of invalid license of playzilla.
.PARAMETER servers
Array the objects associated with the servers to be queried. 
Each object of the array must contain the property "ip" or "host" and optionally the properties "port", "username" and password
.PARAMETER defaultAuthentication
True if the default super administrator user credentials should be used if the credentials are missing 
.PARAMETER logFile
The path of log file
.OUTPUTS
The input array completed with the retrieved information (see DESCRIPTION).
.EXAMPLE
PS C:>[System.Collections.ArrayList]$servers = @(
    [PSCustomObject]@{ip="192.168.1.45";port="8443";login="superadmin";password="superadmin";field1="Field1 value1";field2="Field2 value1"}
    [PSCustomObject]@{ip="192.168.1.10";port="443";login="superadmin";password="superadmin";field1="Field1 value2";field2="Field2 value2"}
)
PS C:>$result = Get-PncInventory -server $servers
PS C:>$result
ip                              : 192.168.1.45
port                            : 8443
login                           : superadmin
password                        : superadmin
field1                          : Field1 value1
field2                          : Field2 value1
status                          : OK
pncVersion                      : 3.12.10
nbDomain                        : 2
domainNames                     : toto
                                  odav.fr
licenseMail                            : mickael.doucet@edf.fr
nbLicenseDomain                 : 101
nbLicensePlayzillaValid         : 1500
nbLicensePlayzillaWithDomain    : 9
nbLicensePlayzillaWithoutDomain : 1491
nbLicensePlayzillaInvalid       : 13

ip                              : 192.168.1.10
port                            : 443
login                           : superadmin
password                        : superadmin
field1                          : Field1 value2
field2                          : Field2 value2
status                          : OK
pncVersion                      : 3.11.11
nbDomain                        : 3
domainNames                     : domain2
                                  domain1
                                  domain3
licenseMail                            : labs@innes.fr
nbLicenseDomain                 : 4
nbLicensePlayzillaValid         : 5
nbLicensePlayzillaWithDomain    : 4
nbLicensePlayzillaWithoutDomain : 1
nbLicensePlayzillaInvalid       : 1
.NOTES
VERSION:1.10.10
#>
    [CmdletBinding()] 
    param(

        [Parameter(Mandatory = $true)]
        [PSCustomObject[]] $servers,
        [boolean] $defaultAuthentication = $true,
        [string] $LogFile
    )
    $verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
    $date = Get-Date
    $ScriptName = $MyInvocation.MyCommand.Name
    LogWrite("$date - $ScriptName")
    foreach ($server in $servers) {
        $urlHost = $null
        $urlPort = $server.port;
        $urlLogin = $server.login;
        $urlPassword = $server.password;
        if (!$urlLogin -and $defaultAuthentication)
        {
            $urlLogin = "superadmin"
        }
        if (!$urlPassword -and $defaultAuthentication)
        {
            $urlPassword = "superadmin"
        }
        if ($server.ip) {
            $urlHost = $server.ip
        }
        elseif ($server.host) {
            $urlHost = $server.host
        }
        else {
            throw "object must defines 'ip' or 'host' property"
        }
        try {
            $server | Add-Member -MemberType NoteProperty -Name "status" -Value "KO" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "pncVersion" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "domainNames" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "licenseMail" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicenseDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaValid" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaWithDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaWithoutDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaInvalid" -Value 0 | Out-Null
            # Version
            $result = Get-PncVersion -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $server.pncVersion = $result;
            # Domains
            $result = Get-PncDomainsAndTargets -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $server.nbDomain = $result.numberDomain
            $domainNames = ""
            foreach ($domain in $result.domains) {
                $domainNames += $domain.Name + "`n"
            }
            if ($domainNames) {
                $domainNames = $domainNames.substring(0, $domainNames.length - 1)
            }
            $server.domainNames = $domainNames
            # Domain licenses
            $result = Get-PncLicense -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $server.licenseMail = $result.mail
            $server.nbLicenseDomain = $result.licenses.numberDomains;
            # Playzilla
            $result = Get-PncAppi -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $playzilla = $result."urn:innes:system-app#playzilla"
            $server.nbLicensePlayzillaValid = $playzilla.nbValidTokens
            foreach ($prop in $playzilla.licenses.PsObject.Properties)
            {
                $license = $prop.Value
                if (!$license.valid) {
                    $server.nbLicensePlayzillaInvalid++;
                }
                elseif ($license.domain)
                {
                    $server.nbLicensePlayzillaWithDomain++

                }                    
                else {
                    $server.nbLicensePlayzillaWithoutDomain++
                }
            }
            $server.status = "OK"
        }
        catch {
            LogWrite("Error with server " + $urlHost);
            Write-Warning("Error with server " + $urlHost);
        }
    }
    $servers
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUO6oiXZTxz2nrYW2WEz6POvl+
# 2KGgggP3MIID8zCCAtugAwIBAgIQLpa10zB5fZZJdGQByDwH8TANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDExOTExNDYzNVoXDTIyMDExOTEyMDYzNVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALVmo+DF
# MsiYOkxwtmdX/SAyAsA+fe+qAcX05GsJt0VCPjMjfAjZ+wTGEceWhkFjQkFQuMu5
# +nQW02Le4yHCoHXQA5heGajzGReTdJKrTNVu+7m7qjVqtgasvCwkIRzTqQmUx+to
# S+7fLZ2f7TmBs76fYYkgOIlkk60UO36awEfVFeSLR+9IP6rZM6nptkmeMwVd0zil
# HH1attsnntzG30n0cjdmx+wh37ZU/zHvT+pxVa9hr0TN3vp5oIlhJ71Q0fEVAo5p
# h4nzvYT7FtOhjoLjMJxVXkt1eeMiju2/EpJfiSPy144XHqOHJEJmA5vspOe7+1R8
# HMW2bveTJxKC0BUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTvlQFKuWkZlTC6h0TwG1amC06HDDANBgkqhkiG9w0BAQsFAAOCAQEAMJEZ
# j6x5YsTmy5qgYIw94wWShMtN5AWqWPiscstJF8fVvFSZTxu1hLKW7peF6Q5hESep
# GG24M24q0bGOzU8ol3/Vez74UIU3k+S/GuTrso1vyf3CsDRoxoS3wsLh3eS+Bwxh
# kAqUhf/Ta4QAF5CqntDBCS2sS6zNDWuo6w7lLBw1VtV/EN78Ji8OGjEkOkD8830p
# uIN1NqV21CPt/TaoFmVlJZPOLRBKiGQehEnDFszZx/u2dCOSKf90NYvbnOAtDuZe
# Z1KUtTk45XDnv28rlfRv3OQvQv+GrHzlGtCkzed0Fo/PpCIYUY6jH6ae5b9AiBuc
# ANLlFRySKSBcVrWOSjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEC6WtdMweX2WSXRkAcg8B/EwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFFxt2WJiIKwXIKxkbZZEnwDk+3wNMA0GCSqGSIb3DQEBAQUABIIBAJoUf0fc
# Tu8t47WKdLa/wLkuoZD+nJbIBpGw/SAkw4TydT2UbaLWeSBq/RzBZ+8J0YOH8n27
# 4Ke7LAZqTVrJ0kukVC4g5IU3C8YAKcmDEg7vzVcJJX5JSdrJkFeKlfIEXHUho8XR
# 2Qh6C+U0+/tIq1aX9rE/OpDqgTpzY0AMyMpR+WiNEqIlGBME0WHTgMVm1XfpYRFO
# szyieMIbteJBRBVSDh5QIwkVLkdRmSgTK96xxXORAYmEVdY9U++/Ae7W/zuE1oO8
# 5GcC5dwvYF+Qn4Zp20A3E0Nb2Djh0n9CKo2eCdOh7sCUTi281ALknUVGx01Q/m8U
# EcX0sIQvfpAqqB0=
# SIG # End signature block
