# Load utilities
Function Get-PncVersion {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve its version.
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve its version.
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The string version.
.EXAMPLE
Get-PncVersion -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()] 
param(

    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
        [string] $UrlPort,
        [string] $UrlLogin,
        [string] $UrlPassword,
    [string] $LogFile
)

$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"

$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve the Plugncast version for server `"$server`"")


$Body = @{
    target = "nsIPref.getCharPref"
    args = @("extensions.lastAppVersion")
}
$JsonBody = $Body | ConvertTo-Json

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}

$VersionObject = $ExecutedRequest | ConvertFrom-Json


LogWrite($VersionObject | ConvertTo-Json -Depth 5)
$VersionObject
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU+R3+b+SHmCMQbRUxmyScWmSw
# JQKgggP3MIID8zCCAtugAwIBAgIQLpa10zB5fZZJdGQByDwH8TANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDExOTExNDYzNVoXDTIyMDExOTEyMDYzNVowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALVmo+DF
# MsiYOkxwtmdX/SAyAsA+fe+qAcX05GsJt0VCPjMjfAjZ+wTGEceWhkFjQkFQuMu5
# +nQW02Le4yHCoHXQA5heGajzGReTdJKrTNVu+7m7qjVqtgasvCwkIRzTqQmUx+to
# S+7fLZ2f7TmBs76fYYkgOIlkk60UO36awEfVFeSLR+9IP6rZM6nptkmeMwVd0zil
# HH1attsnntzG30n0cjdmx+wh37ZU/zHvT+pxVa9hr0TN3vp5oIlhJ71Q0fEVAo5p
# h4nzvYT7FtOhjoLjMJxVXkt1eeMiju2/EpJfiSPy144XHqOHJEJmA5vspOe7+1R8
# HMW2bveTJxKC0BUCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTvlQFKuWkZlTC6h0TwG1amC06HDDANBgkqhkiG9w0BAQsFAAOCAQEAMJEZ
# j6x5YsTmy5qgYIw94wWShMtN5AWqWPiscstJF8fVvFSZTxu1hLKW7peF6Q5hESep
# GG24M24q0bGOzU8ol3/Vez74UIU3k+S/GuTrso1vyf3CsDRoxoS3wsLh3eS+Bwxh
# kAqUhf/Ta4QAF5CqntDBCS2sS6zNDWuo6w7lLBw1VtV/EN78Ji8OGjEkOkD8830p
# uIN1NqV21CPt/TaoFmVlJZPOLRBKiGQehEnDFszZx/u2dCOSKf90NYvbnOAtDuZe
# Z1KUtTk45XDnv28rlfRv3OQvQv+GrHzlGtCkzed0Fo/PpCIYUY6jH6ae5b9AiBuc
# ANLlFRySKSBcVrWOSjGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEC6WtdMweX2WSXRkAcg8B/EwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFPWFmIj88Uhjfd4joMKYU/QCLkFtMA0GCSqGSIb3DQEBAQUABIIBAHEDeYGa
# QITq1EspU5a4IKmCiy3k5cFLAX+maXOgtE19VbccBvboXFz+mo4djbtiY04QSiR0
# faWdrbJclWPhDqW2MltXxoWA0lLYkhTwo9u87ayeILXshtwIJJBFf/iCesDeo1xD
# QyTxd6DOlX/DRvA8FghrwdkIS8GEDQvp+S4v9k7vRAz58+QK3/OmR8FGyL6aHE9K
# QhdG2zoS9t3GVC8xYPH2qqG2bdbYy5tyf1L8S2EKaRSgnsMSvYe7uZkmZUNqW63B
# fMzOZk25zKJl1tlJeJJ0UYWg52B/KeJ+KNR7pdBeEs00iik20R7NwPqXQemrizVV
# 61oGl6uswS9irXU=
# SIG # End signature block
