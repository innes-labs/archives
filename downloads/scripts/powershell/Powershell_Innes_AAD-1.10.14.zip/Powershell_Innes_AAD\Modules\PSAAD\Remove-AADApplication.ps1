Function Remove-AADApplication {
<# 
.SYNOPSIS
This function removes a Azure Active Directory application.  
.DESCRIPTION
This function removes a Azure Active Directory application.  
.PARAMETER Credential
Exchange credential (admin profile) used to remove the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the Exchange credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been removed. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
The name of the Azure Active Directory application.
.OUTPUTS
Nothing
.EXAMPLE
PS C:\>Remove-AADApplication -appname "SignMeeting"
 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName
)

$date = Get-Date
LogWrite("$date : delete AAD application with name `"$appName`"")

Remove-AADApplication-CommonsUtils -credential $Credential -tenantId $tenantId -appName $appName 
LogWrite("Application removed")

}
# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUGNKiDNmaEp5ARUC1u5SFjcqj
# JBagggP3MIID8zCCAtugAwIBAgIQZjEGJJwV97BMn6gGWIUAPjANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIy
# MDYwNzA4NTc1NloXDTIzMDYwNzA5MTc1NlowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKbdBv1L
# v7xBnaDDQBFcgZqt7lyjAmsucAVlcCR5WOXukcU7MHiVQlhU8WlXEAFYkMt3PpU9
# Ht6QD99K8Dpg94y6tGG8Izl/aDSEmGXg0Hq9dbkppDbPRInh2QOcwxdiJt7ylSZM
# XfRdASCWx9fg0KAnB/YMCWXe7gYfZ3sj9FTv6B4w0y7OwOgjQ+B+OcyFqXVSt/kY
# ZUa6nFw/Z48fCHL7IZBg7W23OR/pgdcsS6AccJob8PBEsK6sVojhMcbUSODH3oZl
# 2N++ibizkRxsfgkfZAdOEAwAHIdilymHuki1ba3hyjol14ZcAZHDAzDLb24h8hLm
# SK6uoxnoxSfRNsECAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQM1rRKRiSxJQv92Jfv0uUgoe+dpDANBgkqhkiG9w0BAQsFAAOCAQEAOcfF
# ZDsMnKBCQhgO9da/voZeYuxvhUUyHu59pYBwSJCKwDQa3GXPmUccg+ASbc/LeV2x
# oZD9RzHUP1pf0iLsMqb8NB164MomRTKStROjhD398/mAwOKETECKMepVk1jB0XN0
# R3sMpqnmNOkTJIM8l4nDBhMmQIZN3zx++ClCp9jRFj8CT9Kv72zzHwFmcs/ZEgHx
# k6S3PJhwdnNwjV9LkVaCRdnBgKimxARs07niiHi51QqSTgT1WNHmjIfFgBaZXYME
# rTAeuKt1SgGMTsMhF3IcqWakQO2yhQiF52OQurZdQdm4uAXdIn0jxA+KmHXRcNf3
# 2Srwd+uFx/uBmryCuDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEGYxBiScFfewTJ+oBliFAD4wCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFLx70aBBAemhzBI57NTsD3NPEAwvMA0GCSqGSIb3DQEBAQUABIIBAJZLtDyd
# YYqcJcCXHURJB67bE0albn02k+n8Q5pkeZm1sS/WNFiSOOdrCiJ4K9s4x4u0uoxh
# Z1Ok5oQmfsQ+CnA4fnNXlOO2YX/Q8XDIxEVrLIqhMKq9CnIW12ezGER1Edl20LCn
# FbXBtZED1shmOYtnFFUiHaDfifWVmnkhRzbcEujfjdseaHOV9Gbc1D8WvRtXkhds
# hg3vtt1gzBsXc/prm5KmMwaq7M42J4gqmOlM63+M6gEk3ZsERknl3AB1F9QOVIiK
# VoCz/bEQZQS3FtTgfv9ozmuaD4Uy9loGViuzXs7cZEc2Uz3Bg3gKiKTNCCOMKbPS
# 2TACYr02SinYA8Q=
# SIG # End signature block
