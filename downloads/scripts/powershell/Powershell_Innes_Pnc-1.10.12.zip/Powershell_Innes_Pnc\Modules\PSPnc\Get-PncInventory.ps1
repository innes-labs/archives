# Load utilities
Function Get-PncInventory {
<# 
.SYNOPSIS
This function queries a array of Plugncast G3 server to create an inventory.
.DESCRIPTION
The function uses as input a array of objects associated with the servers to be queried. 
Each object must at least contain the property "ip" or "host" which gives the address (or domain) of the Plugncast server. 
It can also contain the properties:
- port that defines the HTTPS port of server,
- username that defines the authentication user,
- password that defines the authentication password.
Each object can contain other properties which are not used by the function and which are returned unchanged.

The output of the function is the input array to which the
following properties are added to each object:
- status: which is "OK" if the server answered, "KO" otherwise
- pncVersion: version of the Plugncast server,
- nbDomain: number of domains,
- domainNames: domain names separated by newlines,
- licenseMail : the mail used with license,
- nbLicenseDomain: number of valid licenses of domain,
- nbLicensePlayzillaValid: number of valid license of playzilla,
- nbLicensePlayzillaWithDomain: number of valid license of playzilla with domain,
- nbLicensePlayzillaWithoutDomain: number of valid license of playzilla without domain,
- nbLicensePlayzillaInvalid: number of invalid license of playzilla.
.PARAMETER servers
Array the objects associated with the servers to be queried. 
Each object of the array must contain the property "ip" or "host" and optionally the properties "port", "username" and password
.PARAMETER defaultAuthentication
True if the default super administrator user credentials should be used if the credentials are missing 
.PARAMETER logFile
The path of log file
.OUTPUTS
The input array completed with the retrieved information (see DESCRIPTION).
.EXAMPLE
PS C:>[System.Collections.ArrayList]$servers = @(
    [PSCustomObject]@{ip="192.168.1.45";port="8443";login="superadmin";password="superadmin";field1="Field1 value1";field2="Field2 value1"}
    [PSCustomObject]@{ip="192.168.1.10";port="443";login="superadmin";password="superadmin";field1="Field1 value2";field2="Field2 value2"}
)
PS C:>$result = Get-PncInventory -server $servers
PS C:>$result
ip                              : 192.168.1.45
port                            : 8443
login                           : superadmin
password                        : superadmin
field1                          : Field1 value1
field2                          : Field2 value1
status                          : OK
pncVersion                      : 3.12.10
nbDomain                        : 2
domainNames                     : toto
                                  odav.fr
licenseMail                            : mickael.doucet@edf.fr
nbLicenseDomain                 : 101
nbLicensePlayzillaValid         : 1500
nbLicensePlayzillaWithDomain    : 9
nbLicensePlayzillaWithoutDomain : 1491
nbLicensePlayzillaInvalid       : 13

ip                              : 192.168.1.10
port                            : 443
login                           : superadmin
password                        : superadmin
field1                          : Field1 value2
field2                          : Field2 value2
status                          : OK
pncVersion                      : 3.11.11
nbDomain                        : 3
domainNames                     : domain2
                                  domain1
                                  domain3
licenseMail                            : labs@innes.fr
nbLicenseDomain                 : 4
nbLicensePlayzillaValid         : 5
nbLicensePlayzillaWithDomain    : 4
nbLicensePlayzillaWithoutDomain : 1
nbLicensePlayzillaInvalid       : 1
.NOTES
VERSION:1.10.10
#>
    [CmdletBinding()] 
    param(

        [Parameter(Mandatory = $true)]
        [PSCustomObject[]] $servers,
        [boolean] $defaultAuthentication = $true,
        [string] $LogFile
    )
    $verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
    $date = Get-Date
    $ScriptName = $MyInvocation.MyCommand.Name
    LogWrite("$date - $ScriptName")
    foreach ($server in $servers) {
        $urlHost = $null
        $urlPort = $server.port;
        $urlLogin = $server.login;
        $urlPassword = $server.password;
        if (!$urlLogin -and $defaultAuthentication)
        {
            $urlLogin = "superadmin"
        }
        if (!$urlPassword -and $defaultAuthentication)
        {
            $urlPassword = "superadmin"
        }
        if ($server.ip) {
            $urlHost = $server.ip
        }
        elseif ($server.host) {
            $urlHost = $server.host
        }
        else {
            throw "object must defines 'ip' or 'host' property"
        }
        try {
            $server | Add-Member -MemberType NoteProperty -Name "status" -Value "KO" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "pncVersion" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "domainNames" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "licenseMail" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicenseDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaValid" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaWithDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaWithoutDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaInvalid" -Value 0 | Out-Null
            # Version
            $result = Get-PncVersion -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $server.pncVersion = $result;
            # Domains
            $result = Get-PncDomainsAndTargets -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $server.nbDomain = $result.numberDomain
            $domainNames = ""
            foreach ($domain in $result.domains) {
                $domainNames += $domain.Name + "`n"
            }
            if ($domainNames) {
                $domainNames = $domainNames.substring(0, $domainNames.length - 1)
            }
            $server.domainNames = $domainNames
            # Domain licenses
            $result = Get-PncLicense -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $server.licenseMail = $result.mail
            $server.nbLicenseDomain = $result.licenses.numberDomains;
            # Playzilla
            $result = Get-PncAppi -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $playzilla = $result."urn:innes:system-app#playzilla"
            $server.nbLicensePlayzillaValid = $playzilla.nbValidTokens
            foreach ($prop in $playzilla.licenses.PsObject.Properties)
            {
                $license = $prop.Value
                if (!$license.valid) {
                    $server.nbLicensePlayzillaInvalid++;
                }
                elseif ($license.domain)
                {
                    $server.nbLicensePlayzillaWithDomain++

                }                    
                else {
                    $server.nbLicensePlayzillaWithoutDomain++
                }
            }
            $server.status = "OK"
        }
        catch {
            LogWrite("Error with server " + $urlHost);
            Write-Warning("Error with server " + $urlHost);
        }
    }
    $servers
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUGDk3Jx40HAJ+D4ROyCB4N7jh
# PSGgggP3MIID8zCCAtugAwIBAgIQXBiQeu47d6JFviUUIEkrwDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MTEwMjE1MTYyM1oXDTIxMTEwMjE1MzYyM1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKeApW64
# x61zEhDBGhbjkXyQVDKcIob0RN/uApWLHa0zy4co2HCwWoC/Qb/DghdHkRNEx+by
# +9ux4bmwU5arB4Lc1XdXik8X0kEaOZ7uPkYSMv3M8ACBJ4AOLJ0vpJ+vg38A9paJ
# GzRmVmkKe+MUNtYhqPn5Bu/4jB/nyo+MDavHySp6SlvItTgV69QQTolXeETRDOkq
# CmGiN3YbbbetWr7wI9RBrZM8Hr3RvL1BRZi5HAgT4c4+7Cvbx4BReoFyLJbzS+a3
# MfiHzOoSw7iZRTtkOfpnO4rnOn4VFD0H7qDs1Fc+6HF580g0KtmJ+G3NweowkPVt
# e0/JsVgC8OuJMH0CAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQsEtqYl7kfb4n09cdInrzrqk/kbjANBgkqhkiG9w0BAQsFAAOCAQEAHp+c
# GiCpPJ19xyZbsxh9TPJ4nilXBMGwqk406Y6kMjCGFbZj9UqhRVGo3Nmom20NXVc1
# yXhLqNLW8M8you6PmGsbqpWPhuttHODsUkIUlAk82NHmKoHz536VTcxzfKGb0JTu
# Jf32P7yN4gkrqF1tkdvXWpODg9ND6c/qCUpGvHg10WbIogum3rh77k5a2MaJOCWZ
# OyvcR6z3ECrivgfn5uE3l4nHZr+8H04KjcpR5C/Ig/3sDtioKR8s9hjybvlL9adQ
# SzmUa1s0srnL3oCyZKcZiBk0rJl8u3lMOGNTnO3/KobZxILHZVHk+P7sJPlChT+H
# kouL1FMEy7grGQooRDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFwYkHruO3eiRb4lFCBJK8AwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFJpi2Ydq+70mzxF/1HySiyVgHzf5MA0GCSqGSIb3DQEBAQUABIIBAB82pZUE
# UA3uJOZJqBzQo/qLCg3prYfc636VA7rmxotwAYkOPZfWPU780z4aJGmlhwua30o0
# SpvuJFCxG2gzBuQ1zmwRv8+o2uR0aRDzXrnUYm3ars5E9d2J8gzDWczAassl3M3w
# OJNgeQJr9uHkRl4rYgf7HWxZtU5ek7505+xNihGFxGiUOT9LjCrfb6BQ8a1wIH79
# Sj8BDnNFPQXm90zUX2/bisCFW+3O4d3i9mOW8E/MGy8HZyafk9whCrdxWMHXEU8u
# CbVPuwVowCXJMBt50V5cEs45B//fqiMBOR+9qko0Puew966An9RE2bEITO8Uip23
# U36K5jyWf5iL8WA=
# SIG # End signature block
