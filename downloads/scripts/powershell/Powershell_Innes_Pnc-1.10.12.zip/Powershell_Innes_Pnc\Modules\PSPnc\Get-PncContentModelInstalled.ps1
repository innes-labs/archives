Function Get-PncContentModelInstalled {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the installed models
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the installed models
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER domainList
The list of domains involved in the installation. Use "all" for all domains (default)
.PARAMETER lang
The description language of the model ("en-US", "fr-FR", ...). "x-default" by default
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell array of installed models.
Example of object formated in JSON :
[
    {
        "domain":  "domain1"
        "models":  [
            {
               "title":  "title 1",
               "version":  "1.20.10",
               "format":  "16/9",
               "description":  "Description 1",
               "category":  "Category 1",
               "file":  "model1.mask.maff"
            }
        ],
    },
    {
        "domain":  "domain2"
        "models":  [
            {
                 "title":  "title 2",
                "version":  "1.10.12",
                 "format":  "16/9",
                 "description":  "Description 2",
                 "category":  "Category 2",
                 "file":  "model2.mask.maff"
             },
             ...
        ],
    }
]
.EXAMPLE
Get-PncContentModelInstalled -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
Retrieve all models installed
.EXAMPLE
Get-PncContentModelInstalled -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin -domainList domain1
Retrieve models installed on domain "domain1"
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [string[]] $domainList = "all",
    [string] $lang = "x-default",
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
$ServerUri = "https://$Server"

# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve models for server `"$server`"")

 
# List of domains
$configObject = Get-PncDomainsAndTargets $server -logFile "none" -UrlLogin $UrlLogin -UrlPassword $UrlPassword
function GetModels {
    param (
        [string] $domain
    )
    $Body = "<D:propfind xmlns:D=`"DAV:`" xmlns:ias=`"ns.innes.appli.server`"><D:prop><D:getcontenttype/></D:prop><D:prop><D:getcontentlength/></D:prop><D:prop><D:getlastmodified/></D:prop><D:prop><D:getetag/></D:prop><D:prop><D:id/></D:prop><D:prop><D:resourcetype/></D:prop><D:prop><D:owner/></D:prop><D:prop><D:current-user-privilege-set/></D:prop><D:prop><ias:hidden-resources/></D:prop></D:propfind>"
    $Headers = @{
        DEPTH = "1"
        "X-HTTP-METHOD-OVERRIDE" = "PROPFIND"
    }
    Start-Sleep -m $SleepDurationBeforeCommand
    $BaseUri = "/.plugncast/.domains/" + $domain
    try {
        $Uri = $ServerUri + $BaseUri + "/.domain-repository/.models/.medias/"
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'text/xml' -Uri $Uri   -Body $Body -Headers $Headers
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw $_.Exception
    }
    [xml]$result = [xml]$ExecutedRequest
    [System.Xml.XmlElement] $root = $result.get_DocumentElement()
    [System.Collections.ArrayList]$uris =@();
    foreach ($response in $root.ChildNodes) {
        foreach ($child in $response.ChildNodes) {
            $name = $child.ToString()
            $value = $child.InnerText
            if ($name -eq "href")
            {
                if ($value.EndsWith(".mask.maff") -or $value.EndsWith(".mask.uri"))
                {
                    $value = $value.Substring($BaseUri.Length+1);
                    $uris.Add($value) | Out-Null
                }
            }
        }
    }
    $Body = "declare namespace im = `"ns.innes.metadata`";im:getDescriptions(("
    for ($i = 0; $i -lt $uris.Count; $i++)
    {
        $Body += "`"" + $uris[$i] + "`""
        if ($i -ne $uris.Count -1)
        {
            $Body += ","
        }
    }
    $Body += "))"
    try {
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/xquery' -Uri $BaseServerUri".domains/"$domain"/.db/metadatadb"   -Body $Body
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw $_.Exception
    }
    $enc = [System.Text.Encoding]::UTF8
    $bytes = $enc.GetBytes($ExecutedRequest.Content)
    $content = $enc.GetString($bytes)
    [xml]$result = [xml]$content
    [System.Xml.XmlElement] $root = $result.get_DocumentElement()

    [PSCustomObject]$Namespace = @{rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
     xmp="http://ns.adobe.com/xap/1.0/"
     xmpMM="http://ns.adobe.com/xap/1.0/mm/"
      stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#"
      xmpGImg="http://ns.adobe.com/xap/1.0/g/img/"
      dc="http://purl.org/dc/elements/1.1/"
      Iptc4xmpExt="http://iptc.org/std/Iptc4xmpExt/2008-02-29/"
      im="ns.innes.metadata"
      xml="http://www.w3.org/XML/1998/namespace"
      xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/"}
    $ns = New-Object System.Xml.XmlNamespaceManager($result.NameTable)
    foreach ($key in $Namespace.keys) {
        $ns.AddNamespace($key, $Namespace[$key])
    }
    [System.Collections.ArrayList]$models =@()
    foreach ($child in $root.ChildNodes) {
        $file = $child.about
        $index = $file.LastIndexOf("/");
        $file = $file.Substring($index + 1);
        $category = ""
        $title = ""
        $description = ""
        $format = ""
        $version = ""
        $metadata = $child.EmbeddedMetadata
        if ($metadata) {
            $version = $metadata.VersionID
            $res = $metadata.SelectSingleNode("im:category//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
            if ($res) {
                $category = $res.InnerText
            }
            $res = $metadata.SelectSingleNode("dc:title//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
            if ($res) {
                $title = $res.InnerText
            }
            $res = $metadata.SelectSingleNode("dc:description//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
            if ($res) {
                $description = $res.InnerText
            }
            if ($metadata.videoDisplayAspectRatioCategory) {
                $format = $metadata.videoDisplayAspectRatioCategory
            }
        }
        $metadatas = @{
            file = $file
            version     = $version
            format      = $format
            category    = $category
            title       = $title
            description = $description
        }
        $models.Add($metadatas) | Out-Null
    }
    return ,$models
}
[System.Collections.ArrayList]$domainModels =@()
foreach ($domain in $configObject.domains) {
    if (($domainList -eq "all") -or ($domainList -contains $domain.Name)) {
        $models = GetModels $domain.Name
        if ($models.Count -ne 0)
        {
            [PSCustomObject]$obj = @{
                domain = $domain.Name
                models = $models
            }
            $domainModels.Add($obj) | Out-Null
        }
    }
}
LogWrite(,$domainModels | ConvertTo-Json -Depth 5)
,$domainModels
}






# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUDxkgk8oq4vHpW/Z//D/4mHqy
# eROgggP3MIID8zCCAtugAwIBAgIQXBiQeu47d6JFviUUIEkrwDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MTEwMjE1MTYyM1oXDTIxMTEwMjE1MzYyM1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKeApW64
# x61zEhDBGhbjkXyQVDKcIob0RN/uApWLHa0zy4co2HCwWoC/Qb/DghdHkRNEx+by
# +9ux4bmwU5arB4Lc1XdXik8X0kEaOZ7uPkYSMv3M8ACBJ4AOLJ0vpJ+vg38A9paJ
# GzRmVmkKe+MUNtYhqPn5Bu/4jB/nyo+MDavHySp6SlvItTgV69QQTolXeETRDOkq
# CmGiN3YbbbetWr7wI9RBrZM8Hr3RvL1BRZi5HAgT4c4+7Cvbx4BReoFyLJbzS+a3
# MfiHzOoSw7iZRTtkOfpnO4rnOn4VFD0H7qDs1Fc+6HF580g0KtmJ+G3NweowkPVt
# e0/JsVgC8OuJMH0CAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQsEtqYl7kfb4n09cdInrzrqk/kbjANBgkqhkiG9w0BAQsFAAOCAQEAHp+c
# GiCpPJ19xyZbsxh9TPJ4nilXBMGwqk406Y6kMjCGFbZj9UqhRVGo3Nmom20NXVc1
# yXhLqNLW8M8you6PmGsbqpWPhuttHODsUkIUlAk82NHmKoHz536VTcxzfKGb0JTu
# Jf32P7yN4gkrqF1tkdvXWpODg9ND6c/qCUpGvHg10WbIogum3rh77k5a2MaJOCWZ
# OyvcR6z3ECrivgfn5uE3l4nHZr+8H04KjcpR5C/Ig/3sDtioKR8s9hjybvlL9adQ
# SzmUa1s0srnL3oCyZKcZiBk0rJl8u3lMOGNTnO3/KobZxILHZVHk+P7sJPlChT+H
# kouL1FMEy7grGQooRDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFwYkHruO3eiRb4lFCBJK8AwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFPCzO2F1WttbdD6BCMoAwfKU5eo/MA0GCSqGSIb3DQEBAQUABIIBAF7Z8oJ2
# yu/IUk5k9Ip4XNF/Xe15te0Y0yaKwWaznRTRrSx435JE7AYcOhrsIdaRHruvNq1P
# uVh5uRIjsOD5nI53lXBroG5NMkI/evSsVqOr8fDgbR4I5byvZL/NBUt2Mz+zl2qT
# yqK8kTBeTCcOSlTmr2Jk8VfVFjN1Z5SyfZkq7POdrkzKnhnPu2JJBDA8azv91YGB
# dxJfLElTfS0wCtPz4bRuthkHAo2vqJv3BleXEzbj3lDywRSq+WGdjdzatk66YlIZ
# WKU+X+VSUN47LIh4tn4AiPBierMEvdik+5zLbo1fOoUcVuMh5u3JQnM/6RTnUVd1
# 4rx87Bob1S0UA/M=
# SIG # End signature block
