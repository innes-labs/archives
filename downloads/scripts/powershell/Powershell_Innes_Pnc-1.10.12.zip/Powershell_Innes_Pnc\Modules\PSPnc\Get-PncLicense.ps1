Function Get-PncLicense {
<#
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the Plugncast server licenses.
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the Plugncast server licenses.
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell object describing license.
Example of object formated in JSON :
{
    "mail":  "mail@domain.com",
    "psn":  "PSN00780-00000 CD9",
    "licenses":  {
         "numberDevices":  "unlimited",
         "numberDomains":  51,
         "valid":  true,
         "licenses":  {
            "PSN00160-00180 CD7":  {
                  "psn":  "PSN00160-00000 CD7",
                 "isCore":  false,
                 "numberDevices":  "unlimited",
                  "numberDomains":  10,
                 "label":  "plugncast domain",
                 "valid":  true,
                 "license":  "xxxx - xxxx - xxxx - xxxx - xxxxx",
                 "expired":  false
            }
        }
    }
}
.EXAMPLE
Get-PncLicense -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION: 1.10.10
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost = $(throw "Please enter the Plugncast G3 host (IP or DNS domain"),
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"

# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name
$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve the Plugncast licenses for server `"$server`"")

$Body = @{
    target = "nsIAppliLicenses.list"
}
$JsonBody = $Body | ConvertTo-Json
Start-Sleep -m $SleepDurationBeforeCommand

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}

$LicensesObject = $ExecutedRequest | ConvertFrom-Json

$Body = @{
    target = "nsIAppliLicenses.mail"
}
$JsonBody = $Body | ConvertTo-Json
try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}
$mail = $ExecutedRequest | ConvertFrom-Json
$Body = @{
    target = "nsIAppliLicenses.psn"
}
$JsonBody = $Body | ConvertTo-Json
try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}
$psn = $ExecutedRequest | ConvertFrom-Json
$resultObject=[PSCustomObject]@{
    mail= $mail;
    psn = $psn;
    licenses = $LicensesObject
}
LogWrite($resultObject | ConvertTo-Json -Depth 5)
$resultObject

}


# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU5VQ5ZCe8bRovFCHaYe23UPpB
# v/WgggP3MIID8zCCAtugAwIBAgIQXBiQeu47d6JFviUUIEkrwDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MTEwMjE1MTYyM1oXDTIxMTEwMjE1MzYyM1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKeApW64
# x61zEhDBGhbjkXyQVDKcIob0RN/uApWLHa0zy4co2HCwWoC/Qb/DghdHkRNEx+by
# +9ux4bmwU5arB4Lc1XdXik8X0kEaOZ7uPkYSMv3M8ACBJ4AOLJ0vpJ+vg38A9paJ
# GzRmVmkKe+MUNtYhqPn5Bu/4jB/nyo+MDavHySp6SlvItTgV69QQTolXeETRDOkq
# CmGiN3YbbbetWr7wI9RBrZM8Hr3RvL1BRZi5HAgT4c4+7Cvbx4BReoFyLJbzS+a3
# MfiHzOoSw7iZRTtkOfpnO4rnOn4VFD0H7qDs1Fc+6HF580g0KtmJ+G3NweowkPVt
# e0/JsVgC8OuJMH0CAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQsEtqYl7kfb4n09cdInrzrqk/kbjANBgkqhkiG9w0BAQsFAAOCAQEAHp+c
# GiCpPJ19xyZbsxh9TPJ4nilXBMGwqk406Y6kMjCGFbZj9UqhRVGo3Nmom20NXVc1
# yXhLqNLW8M8you6PmGsbqpWPhuttHODsUkIUlAk82NHmKoHz536VTcxzfKGb0JTu
# Jf32P7yN4gkrqF1tkdvXWpODg9ND6c/qCUpGvHg10WbIogum3rh77k5a2MaJOCWZ
# OyvcR6z3ECrivgfn5uE3l4nHZr+8H04KjcpR5C/Ig/3sDtioKR8s9hjybvlL9adQ
# SzmUa1s0srnL3oCyZKcZiBk0rJl8u3lMOGNTnO3/KobZxILHZVHk+P7sJPlChT+H
# kouL1FMEy7grGQooRDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFwYkHruO3eiRb4lFCBJK8AwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFKMYppfuchFWNKMQh1dl4Va3uGXQMA0GCSqGSIb3DQEBAQUABIIBAGaGV9Vc
# kJxIP82/KIFSmq7/1CJviDlSWfCDmuSSv+iulxyuDk7r1tusIzkwUQIYwA6BF4YY
# BgyQDFBwyTZSfH0dc/iUNGaTD43DQt34BZgVBsGCDpm2z/t2acsWs0AdNWPbXOdN
# nX2y3ZByxubP07jXTFbvTjRY/q8gNXCfuABwEaszUWp+akRZZ9SbaaI37+HS7ZLM
# iFBU1EUeefbssXgkrwuh149HFAvJ+9YsytaebnPY8udfLXeBkweHFGFeD76IqZxs
# TltWyBi75BZngmUtsvYgIr1lZCWPZaxoETq8zo/CiS1AQDfgkwRvjIGsD8lwTRdx
# Bk8X694/MoNKRQE=
# SIG # End signature block
