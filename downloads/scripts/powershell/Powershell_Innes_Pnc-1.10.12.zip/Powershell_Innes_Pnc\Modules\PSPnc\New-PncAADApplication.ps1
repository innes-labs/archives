Function New-PncAADApplication {
<# 
.SYNOPSIS
This function creates the Azure AD application for Plugncast  
.DESCRIPTION
The application created can be used to create Azure AD provider with New-PncOpenIdProviderAAD function. 
.PARAMETER Credential
The credential of the Azure AD user used to create the application. if absent, a dialog is displayed to connect to Azure AD 
.PARAMETER tenantId
The Active Directory Tenant. This is a GUID which represents the "Directory ID" of the AzureAD tenant
into which you want to create the apps. Look it up in the Azure portal in the "Properties" of the Azure AD
.PARAMETER appName
The name of the application 
.PARAMETER pncUrlHost
The host (ip or domain) of Plugncast server.
.PARAMETER pncUrlPort
The port of Plugncast server
.PARAMETER logFile
The path of log file

.OUTPUTS
The object that describe the application created. This object is already dumped in the file names "<appName>.json"
Its contains the following properties:
name : the application name
tenantId : the tenant id
clientId : the client id of application
objectId : the object id of application
clientSecret: the client secret generated (present only if parameter GeneratePassword is $true)
spId : the service pricipal id of application

 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $false)]
    [string] $appName = "Plugncast",
    [Parameter(Mandatory = $true)]
    [string] $pncUrlHost,
    [string] $pncUrlPort,
    [string] $LogFile
)
$Server=$pncUrlHost
if ($pncUrlPort) {
   $Server += ":" + $pncUrlPort
}
$BaseServerUri = "https://$Server/.plugncast"

$date = Get-Date
LogWrite("$date : create new AAD application with name `"$appName`" for server `"$server`"")

[String[]] $replyUrls= @("$BaseServerUri/openid/login/redirect", "$BaseServerUri/openid/adminconsent/redirect")
$logoutUrl="$BaseServerUri/openid/logout"
$homepage="https://$Server/cms"

$app = New-AADApplication -credential $Credential -tenantId $tenantId -appName $appName `
        -ReplyUrls $replyUrls -logoutUrl $logoutUrl -homepage $homepage `
      -generatePassword $true -applicationPermissions "User.Read.All|Group.Read.All|GroupMember.Read.All"

Set-Content -Path ".\$appName.json" -Value ($app | ConvertTo-Json -Depth 5)
LogWrite("Application created")
$app
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUKrAXfdvEqjeC8xyl6NgL10+U
# duugggP3MIID8zCCAtugAwIBAgIQXBiQeu47d6JFviUUIEkrwDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MTEwMjE1MTYyM1oXDTIxMTEwMjE1MzYyM1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKeApW64
# x61zEhDBGhbjkXyQVDKcIob0RN/uApWLHa0zy4co2HCwWoC/Qb/DghdHkRNEx+by
# +9ux4bmwU5arB4Lc1XdXik8X0kEaOZ7uPkYSMv3M8ACBJ4AOLJ0vpJ+vg38A9paJ
# GzRmVmkKe+MUNtYhqPn5Bu/4jB/nyo+MDavHySp6SlvItTgV69QQTolXeETRDOkq
# CmGiN3YbbbetWr7wI9RBrZM8Hr3RvL1BRZi5HAgT4c4+7Cvbx4BReoFyLJbzS+a3
# MfiHzOoSw7iZRTtkOfpnO4rnOn4VFD0H7qDs1Fc+6HF580g0KtmJ+G3NweowkPVt
# e0/JsVgC8OuJMH0CAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQsEtqYl7kfb4n09cdInrzrqk/kbjANBgkqhkiG9w0BAQsFAAOCAQEAHp+c
# GiCpPJ19xyZbsxh9TPJ4nilXBMGwqk406Y6kMjCGFbZj9UqhRVGo3Nmom20NXVc1
# yXhLqNLW8M8you6PmGsbqpWPhuttHODsUkIUlAk82NHmKoHz536VTcxzfKGb0JTu
# Jf32P7yN4gkrqF1tkdvXWpODg9ND6c/qCUpGvHg10WbIogum3rh77k5a2MaJOCWZ
# OyvcR6z3ECrivgfn5uE3l4nHZr+8H04KjcpR5C/Ig/3sDtioKR8s9hjybvlL9adQ
# SzmUa1s0srnL3oCyZKcZiBk0rJl8u3lMOGNTnO3/KobZxILHZVHk+P7sJPlChT+H
# kouL1FMEy7grGQooRDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFwYkHruO3eiRb4lFCBJK8AwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFNCGzPlcQitpPVQMI+sjZJi1lgPLMA0GCSqGSIb3DQEBAQUABIIBAHV161q7
# 4tc28Gd3P61cOR3xGhTLtzscUWXg8s5ocYcbHXKt8Al1qfY1Qh7R5hfcMnEugoOo
# nz1MqJICbFk8mfmLkzcXRYdz1zBl9G4Y1hpDo7FznlCRNfp2ylPU1JFlNSglzGrY
# ca7PWkw13NQzM1ZioGlibjAYnOyoFIlhQwH1FnnBjb/9mPrdUxobfT6w4CqsVaqE
# 6buEv1b9C8KAEnkDfOkKE6dCqenFMmLjTCaMVUSaa10xQR728WCF3kP7h544Akq0
# vf4NL+IqeZyYY6h6MgvLC7oMXyPw+SvfL3YGJrBgr8NX6IKJ2GwIP1/wDs9qYEqO
# wc7rU2u9s0Xovq4=
# SIG # End signature block
