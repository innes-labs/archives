# Load utilities
Function Get-PncVersion {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve its version.
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve its version.
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The string version.
.EXAMPLE
Get-PncVersion -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()] 
param(

    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
        [string] $UrlPort,
        [string] $UrlLogin,
        [string] $UrlPassword,
    [string] $LogFile
)

$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"

$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve the Plugncast version for server `"$server`"")


$Body = @{
    target = "nsIPref.getCharPref"
    args = @("extensions.lastAppVersion")
}
$JsonBody = $Body | ConvertTo-Json

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}

$VersionObject = $ExecutedRequest | ConvertFrom-Json


LogWrite($VersionObject | ConvertTo-Json -Depth 5)
$VersionObject
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUpv9CupHDsFD3BFIb653dnTAG
# OvigggP3MIID8zCCAtugAwIBAgIQXBiQeu47d6JFviUUIEkrwDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MTEwMjE1MTYyM1oXDTIxMTEwMjE1MzYyM1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKeApW64
# x61zEhDBGhbjkXyQVDKcIob0RN/uApWLHa0zy4co2HCwWoC/Qb/DghdHkRNEx+by
# +9ux4bmwU5arB4Lc1XdXik8X0kEaOZ7uPkYSMv3M8ACBJ4AOLJ0vpJ+vg38A9paJ
# GzRmVmkKe+MUNtYhqPn5Bu/4jB/nyo+MDavHySp6SlvItTgV69QQTolXeETRDOkq
# CmGiN3YbbbetWr7wI9RBrZM8Hr3RvL1BRZi5HAgT4c4+7Cvbx4BReoFyLJbzS+a3
# MfiHzOoSw7iZRTtkOfpnO4rnOn4VFD0H7qDs1Fc+6HF580g0KtmJ+G3NweowkPVt
# e0/JsVgC8OuJMH0CAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQsEtqYl7kfb4n09cdInrzrqk/kbjANBgkqhkiG9w0BAQsFAAOCAQEAHp+c
# GiCpPJ19xyZbsxh9TPJ4nilXBMGwqk406Y6kMjCGFbZj9UqhRVGo3Nmom20NXVc1
# yXhLqNLW8M8you6PmGsbqpWPhuttHODsUkIUlAk82NHmKoHz536VTcxzfKGb0JTu
# Jf32P7yN4gkrqF1tkdvXWpODg9ND6c/qCUpGvHg10WbIogum3rh77k5a2MaJOCWZ
# OyvcR6z3ECrivgfn5uE3l4nHZr+8H04KjcpR5C/Ig/3sDtioKR8s9hjybvlL9adQ
# SzmUa1s0srnL3oCyZKcZiBk0rJl8u3lMOGNTnO3/KobZxILHZVHk+P7sJPlChT+H
# kouL1FMEy7grGQooRDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFwYkHruO3eiRb4lFCBJK8AwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFACaOc4WrHSyB9GRDFlLBG9pXxJBMA0GCSqGSIb3DQEBAQUABIIBAD6wljQF
# v4h7QPR9Hhr+gKpYwJ8IL8lw00ZkJ+KgE+0L+zDOFCV1IkHPc2n7uM7sqAkEHExz
# ijW13AuWIx8D6aJT41Onf8F8qCLSts+JUnwBMTOZZdi4jtOxPwedwtTjp8y4AFXc
# 1kLdaYToqXpk7E4i9436FhJbCMKpA8XRCiA0aH/T62xlUqWpQP8v/FvMeigzLNZT
# mSX0wsUqIQ1Ak43NNFCXy+dp5qg6YVSbpNHJ5zSPzYqhR0OeRQ8Sfc+kx/V+ezgZ
# ookDSXW6veJZvmkzitjuzy65fxXKlueGM/99eXhivfgUmDlcoOFz3TvQEoFJyoJ/
# 3pVUQRJqGgxUa64=
# SIG # End signature block
