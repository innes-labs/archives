<#
.SYNOPSIS
This script permits to get many information from PlugnCast Server
.DESCRIPTION
This script permits to get many information from PlugnCast Server
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain). Example: "demo.plugncast.com", "localhost"
.PARAMETER urlPort
The Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used (default "superadmin")
.PARAMETER urlPassword
The password of authentication if the certificate is not used (default "superadmin")
.PARAMETER logFile
The path of log file (default "./Get-PncInformation.log")
.EXAMPLE
Get-PncInformation -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [string] $UrlLogin = "superadmin",
    [string] $UrlPassword = "superadmin",
    [string] $LogFile = "./Get-PncInformation.log"
)
# Import Pnc Module
Import-Module PSPnc
# Clear the log file of any previous try
If ($LogFile -and (Test-Path $LogFile) -eq $True) {
    Remove-Item -Path $LogFile
}
$verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
# Get all the information
$result = Get-PncVersion -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
$result = Get-PncDomainsAndTargets -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
$result = Get-PncLicense -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
$result = Get-PncAppi -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
$result = Get-PncAppiDomainAssociation -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -appi "playzilla" -logFile $LogFile -vb:$verbose
$result = Get-PncContentModelInstalled -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose


# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUEdON9oRPKjZHDj+ZPnRTYD52
# jD6gggP3MIID8zCCAtugAwIBAgIQXBiQeu47d6JFviUUIEkrwDANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIw
# MTEwMjE1MTYyM1oXDTIxMTEwMjE1MzYyM1owfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKeApW64
# x61zEhDBGhbjkXyQVDKcIob0RN/uApWLHa0zy4co2HCwWoC/Qb/DghdHkRNEx+by
# +9ux4bmwU5arB4Lc1XdXik8X0kEaOZ7uPkYSMv3M8ACBJ4AOLJ0vpJ+vg38A9paJ
# GzRmVmkKe+MUNtYhqPn5Bu/4jB/nyo+MDavHySp6SlvItTgV69QQTolXeETRDOkq
# CmGiN3YbbbetWr7wI9RBrZM8Hr3RvL1BRZi5HAgT4c4+7Cvbx4BReoFyLJbzS+a3
# MfiHzOoSw7iZRTtkOfpnO4rnOn4VFD0H7qDs1Fc+6HF580g0KtmJ+G3NweowkPVt
# e0/JsVgC8OuJMH0CAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBQsEtqYl7kfb4n09cdInrzrqk/kbjANBgkqhkiG9w0BAQsFAAOCAQEAHp+c
# GiCpPJ19xyZbsxh9TPJ4nilXBMGwqk406Y6kMjCGFbZj9UqhRVGo3Nmom20NXVc1
# yXhLqNLW8M8you6PmGsbqpWPhuttHODsUkIUlAk82NHmKoHz536VTcxzfKGb0JTu
# Jf32P7yN4gkrqF1tkdvXWpODg9ND6c/qCUpGvHg10WbIogum3rh77k5a2MaJOCWZ
# OyvcR6z3ECrivgfn5uE3l4nHZr+8H04KjcpR5C/Ig/3sDtioKR8s9hjybvlL9adQ
# SzmUa1s0srnL3oCyZKcZiBk0rJl8u3lMOGNTnO3/KobZxILHZVHk+P7sJPlChT+H
# kouL1FMEy7grGQooRDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEFwYkHruO3eiRb4lFCBJK8AwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFFh+pHy8Jg91t+jrx6FgBUDLZKl7MA0GCSqGSIb3DQEBAQUABIIBAKK0+BGq
# pPrHHyrEzs7R3eTmMTavH7CAFF5sMBQohdCQ8m3QFdWT6efUGOW4Tx+doHHnjf67
# AYIPpfIz/A2cDuyyIUDcYQ9mYo8nsSj+aCa5gncI3n6WZEIC+W+4OXpYfv0BOpzu
# dwhstV1YEXo+MJkqK+XU9ULN6wi2SEhO+6PzqFNvkBnx+NKbMeX7ZrGVnl+cobb4
# LPHH9Imdnox5MN8Y2gwqkmuelt+Jg3yQUEo6C8G2+SXDJYbBFV4d7T01CQ2mh7zf
# V+Mg5yZlgTuaX5BilrJDS0R9YtRKxbOo9+U7W8n02pff6Mvwk/3GCFBhSTxytVeT
# EW9nRu41RmlOBf0=
# SIG # End signature block
