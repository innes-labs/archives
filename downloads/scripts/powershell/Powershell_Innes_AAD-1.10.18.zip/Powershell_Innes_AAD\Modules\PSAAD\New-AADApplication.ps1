Function New-AADApplication {
<# 
.SYNOPSIS
This function creates a Azure Active Directory application.  
.DESCRIPTION
This function creates a Azure Active Directory application.  
.PARAMETER Credential
Credential (admin profile) used to create the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been created. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
Name of the Azure Active Directory application.
.PARAMETER PublicClient
The application is a public client (false by default). 
In this mode, it is possible to obtain a user type connection with the pair (susername, password) only (without secret client). 
But then the application type premissions and the secret client are no longer generated; it is then no longer possible to connect in application mode.
Only autorization types "signcom_m365", "url_launcher_m365", "m365_user" and "powerbi"  are allowed for a public client.
.PARAMETER authorizations
Authorization type:
- "signcom_m365" : to access to M365 files and folders resources and Web sites for SignCom application
- "url_launcher_m365" : to access to M365 Web sites for URL launcher application
- "signmeeting_ews": to access to MS-Exchange room mailbox resources for SignMeeting MS-Exchange application
- "signmeeting_m365": to access to M365 room mailbox resources for SignMeeting-M365 application
- "briva_calendar_ews": to access to MS-Exchange room mailbox resources for Briva Calendar EWS application
- "m365_room": to access to M365 room mailbox resource for SBL10e m365_room application
- "m365_user": to access to M365 user presence resource for SBL10e m365_user application
- "powerbi": to access to Power BI report and Power BI dashboards
.PARAMETER logFile
Log file path
.OUTPUTS
The result is an object that is describing the created Azure Active Directory application. 
It contains the following properties:
- name : Azure Active directory application name
- tenantId : Azure Active directory's tenant id
- clientId : Azure Active directory's application (client) Id
- objectId : Azure Active directory's application object id
- clientSecret: Azure Active directory's client secret
- spId : Azure Active directory's application service principal id
These object properties are flushed automatically in the "<appName>.json" file in the current directory.
.EXAMPLE
PS C:\>$result = New-AADApplication -appname "SignMeeting"  -authorizations "signmeeting_ews"
A consent request will be sent in 30 seconds in your browser.
You must log into an administrator account of your organization and grant the necessary permissions.
PS C:\>$result
Name                           Value
----                           -----
clientId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
objectId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
spId                           xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
name                           SignMeeting
tenantId                       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
clientSecret                   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
.NOTES 
 VERSION:1.10.10
#>

   [CmdletBinding()] 
   param(
      [PSCredential] $Credential,
      [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
      [string] $tenantId,
      [Parameter(Mandatory = $true)]
      [string] $appName,
      [Parameter(Mandatory = $true)]
      [ValidateSet('signcom_m365', 'url_launcher_m365', 'signmeeting_ews', 'signmeeting_m365', 'm365_room', 'm365_user', 'powerbi', 'briva_calendar_ews')]
      [string[]] $authorizations,
      [string] $LogFile,
      [bool] $PublicClient = $False,
      [bool] $multiTenants = $false
   )
   $date = Get-Date
   LogWrite("$date : create new AAD application with name `"$appName`"")
   try {
      for ($i = 0; $i -lt $authorizations.length; $i++)
      {
          $authorizations[$i] = ($authorizations[$i]).ToLower();
      }
      if ($PublicClient -and 
          -not ($authorizations.Contains("signcom_m365") -or 
          $authorizations.Contains("url_launcher_m365") -or
          $authorizations.Contains("m365_user") -or
          $authorizations.Contains("powerbi")
          )) 
      {
        Write-Error("This authorization type are not allowed with PublicClient parameter")
        exit 1
      }
      $consentRedirectUri = "http://localhost:23456/consent/redirect"
      [String[]] $replyUrls = @($consentRedirectUri)
      $app = New-AADApplication-CommonsUtils  -credential $Credential -tenantId $tenantId -appName $appName `
         -replyUrls $replyUrls `
         -generatePassword (-not $PublicClient) -AvailableToOtherTenants $multiTenants -PublicClient $PublicClient
      $requiredResourcesAccess = New-Object System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.RequiredResourceAccess]
      $hasDelegatedPermission = $false;
      if ($authorizations.Contains("signcom_m365") -or $authorizations.Contains("url_launcher_m365")) {
         $permissions = "Files.Read.All|Sites.Read.All|User.Read"
         if ($PublicClient) {
            $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions $permissions
         } else {
           $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions $permissions -requiredApplicationPermissions $permissions
         }
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("signmeeting_ews")) {
         $requiredPermissions = GetRequiredPermissions -appid "00000002-0000-0ff1-ce00-000000000000" `
            -requiredApplicationPermissions "full_access_as_app"
         $requiredResourcesAccess.Add($requiredPermissions)
         $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
            -requiredDelegatedPermissions "EWS.AccessAsUser.All|User.Read"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("briva_calendar_ews")) {
        $requiredPermissions = GetRequiredPermissions -appid "00000002-0000-0ff1-ce00-000000000000" `
           -requiredApplicationPermissions "full_access_as_app"
        $requiredResourcesAccess.Add($requiredPermissions)
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
           -requiredDelegatedPermissions "EWS.AccessAsUser.All|User.Read"
        $requiredResourcesAccess.Add($requiredPermissions)
        $hasDelegatedPermission = $true;
     }
      if ($authorizations.Contains("signmeeting_m365")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredApplicationPermissions "Place.Read.All|User.Read.All|Calendars.ReadWrite"
         $requiredResourcesAccess.Add($requiredPermissions)
      }
      if ($authorizations.Contains("m365_room")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredApplicationPermissions "Calendars.Read|User.Read.All"
         $requiredResourcesAccess.Add($requiredPermissions)
      }
      if ($authorizations.Contains("m365_user")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
        -requiredDelegatedPermissions "Directory.AccessAsUser.All|Presence.Read.All|User.Read"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      if ($authorizations.Contains("powerbi")) {
        $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Power BI Service" `
        -requiredDelegatedPermissions "App.Read.All|Content.Create|Dataset.ReadWrite.All|Report.ReadWrite.All|Dashboard.ReadWrite.All"
         $requiredResourcesAccess.Add($requiredPermissions)
         $hasDelegatedPermission = $true;
      }
      Set-AzureADApplication -ObjectId $app.ObjectId -RequiredResourceAccess $requiredResourcesAccess
    #   $app.clientSecret = [System.Web.HttpUtility]::UrlEncode($app.clientSecret)
      Set-Content -Path ".\$appName.json" -Value ($app | ConvertTo-Json -Depth 5)
      $hasDelegatedPermission = $true
      if ($hasDelegatedPermission) 
      {
        Write-Host "A consent request will be sent in 50 seconds in your browser.`
        You must log into an administrator account of your organization and grant the necessary permissions."
        Start-Sleep 50
        $request = "https://login.microsoftonline.com/" + $app.tenantId + "/adminconsent" + `
        "?client_id=" + $app.ClientId + "&redirect_uri=" + $consentRedirectUri
        Start-Process $request
        Start-ConsentRedirectServer
      }
      Write-Host("Application created")
      $app
   }
   catch {
      LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
      throw $_.Exception
   }
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUetMroPCd8OhoE/VgWrTe/v+7
# nVGgggP3MIID8zCCAtugAwIBAgIQQbXWrT3RbINCGdQ4EJKTqTANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTI0
# MDIxNjEwMDgyOFoXDTI1MDIxNjEwMjgyOFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOAj77Rg
# di2zGE25oo9G4dAV5wnOyuRoG/sKBGZrt7iX3gUh94RwGpOuVPuL3I/BLMelAGQo
# DGehtWy9SMUkNLRcVWxQaKz1EFkyjlCYJ7S2IswM1BrdaU6b2bkpfP0alxKJylR/
# NXGTwJvZDorYTqgGy2hUn2HG7k6RsF/N13bPlgzXmSysE/qBgCks4yhN8gYh1U6e
# A22M/Mk/uJFKpYF777wxA/XCdPKqFk96QXMwpbfiuiEIo+IDnpeqsYMSJ1MpsZQu
# OijUkSiM0lzxl1DPT6QY/ED0faJEm71WLe/ElrMkN9euaTC0WsfQtzj1dN0ubjr0
# ylIxNfYOzBZVXqkCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTv5lID2ajjezdSKHF+Q+18CZDfXjANBgkqhkiG9w0BAQsFAAOCAQEARBUQ
# yGG9gFaNbKKoOGhySoqf2/3ACBCBLnWKHkGnp0FLDXroaG7g89yqPcxvjvla98Aa
# 50C2RUGBNaFPatz6OE9sFBGqAJ2Hz8EHvMUypRCCyzsQlkrljttkzxcP+NdSRtR6
# JRTrZYj05w7Y4Cs5gdxnK9i6ZjGEPQfIyt3wv/wJJhplIQFIIviH8qqR8iQON+fr
# O0j+Xt322QVuwDRGrcWCCtzK2N6sApX/bxmL3bJozQAvJlZgk+NqmNdAoy/UBL8n
# vqRNvU0H5DTsVzg4AKIl0lSJ11qElh3PpWZOWh5hVVbrhwlQOmXx1WSrNl8uD7jQ
# YG0wT2HTU8whApcBaDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEEG11q090WyDQhnUOBCSk6kwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFKn8LNocYrLgD1VVLUIzPjNeD6sIMA0GCSqGSIb3DQEBAQUABIIBANUZpOrK
# WcooIWCM2prtiXGxpCbTwaKeTGNvhx3NrQEVlH5fC1M3YUG9fzsC5ez2wfVvLveO
# Uq1BFkFx1OAtWiZaXxvRD0nucybaYZ9bL9//xTXmyyvMgIaOMCGcSzpAx5pxj6iX
# w8QzFg2Wed7oYF/AleAWPge3rJst4PVrCJ/mkYPO7E/CEm0J32CfUnHFl+QBtBOF
# UBtcXi1X20Qk9wYNnRRJSdniRTE7lv1ebXgzcpKEy5tDV2zjB4LCHpy8BzFZIY4s
# VM39zUwtMgg4qSdCk/iZlcY9Cg9+5wGLlpgB4d6u1rKO7v5k8bg1YFvZ+9lI1jEZ
# aphO1IypJXMH0zs=
# SIG # End signature block
