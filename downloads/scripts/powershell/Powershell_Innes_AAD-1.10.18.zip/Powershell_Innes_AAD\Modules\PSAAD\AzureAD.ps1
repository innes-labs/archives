Function New-AADApplication-CommonsUtils  {
<#
.SYNOPSIS
This function creates the Azure AD application for the sample in the provided Azure AD tenant 
.DESCRIPTION
This function creates the Azure AD application for the sample in the provided Azure AD tenant 
.PARAMETER Credential
The credential of the Azure AD user used to create the application. if absent, a dialog is displayed to connect to Azure AD 
.PARAMETER tenantId
The Active Directory Tenant. This is a GUID which represents the "Directory ID" of the AzureAD tenant
into which you want to create the apps. Look it up in the Azure portal in the "Properties" of the Azure AD
.PARAMETER appName
The name of the application 
.PARAMETER homePage 
The home page of the application
.PARAMETER replyUrls
The list of redirect Urls of the application
.PARAMETER logoutUrl
The logout Url of the application
.PARAMETER delegatedPermissions
delegated permissions (separated by "|") for the "Microsoft Graph" application
.PARAMETER applicationPermissions
application permissions (separated by '|') for "Microsoft Graph" application
.PARAMETER certificatePath
The file path of the certificate used by application (use only if the parameter GeneratePassword is $false)
.PARAMETER certificate
The certificate used by application (use only if the parameter GeneratePassword is $false)
.PARAMETER GeneratePassword
The function generate the secret key of the application 
.PARAMETER PublicClient
The client application is a public client (false by default).
In this mode, it is possible to obtain a user type connection with the pair (susername, password) only (without secret client). 
But then the application type premissions and the secret client are no longer generated; it is then no longer possible to connect in application mode.
.OUTPUTS
The object that describe the application created. This object is already dumped in the file names "<appName>.json"
Its contains the following properties:
name : the application name
tenantId : the tenant id
clientId : the client id of application
objectId : the object id of application
clientSecret: the client secret generated (present only if parameter GeneratePassword is $true)
spId : the service pricipal id of application

#> 
[CmdletBinding()]
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName,
    [string] $homePage,
    [string[]] $replyUrls,
    [string] $logoutUrl,
    [string] $certificatePath,
    [string] $delegatedPermissions,
    [string] $applicationPermissions,
    [bool] $AvailableToOtherTenants = $false,
    [bool] $GeneratePassword = $false,
    [bool] $PublicClient = $false,
    [System.Security.Cryptography.X509Certificates.X509Certificate2] $certificate

)
# Pre-requisites
try {
    if ((Get-Module -ListAvailable -Name "AzureAD") -eq $null) { 
        Install-Module "AzureAD" -Scope CurrentUser 
    } 
    Import-Module AzureAD
    if (!$Credential -and $TenantId) {
        $creds = Connect-AzureAD -TenantId $tenantId
    }
    else {
        if (!$TenantId) {
            $creds = Connect-AzureAD -Credential $Credential
        }
        else {
            $creds = Connect-AzureAD -TenantId $tenantId -Credential $Credential
        }
    }

    if (!$tenantId) {
        $tenantId = $creds.Tenant.Id
    }

    $tenant = Get-AzureADTenantDetail
    $tenantName = ($tenant.VerifiedDomains | Where { $_._Default -eq $True }).Name

    # Get the user running the script
    $user = Get-AzureADUser -ObjectId $creds.Account.Id

    # Create the client AAD application
    LogWrite( "Creating the AAD application ($appName)")
    $clientAadApplication = $null
    if ($homePage) {
    $clientAadApplication = New-AzureADApplication -DisplayName $appName `
        -Homepage $homePage `
        -ReplyUrls $replyUrls `
        -LogoutUrl $logoutUrl `
        -PublicClient $PublicClient `
        -AvailableToOtherTenants  $AvailableToOtherTenants 
    }
    else {
        $clientAadApplication = New-AzureADApplication -DisplayName $appName `
        -ReplyUrls $replyUrls `
        -LogoutUrl $logoutUrl `
        -PublicClient $PublicClient `
        -AvailableToOtherTenants  $AvailableToOtherTenants 
    }
    LogWrite( "Creating the client application ($appName)")
    $password = $null
    if ($GeneratePassword) {
        $password = New-AzureADApplicationPasswordCredential -ObjectId $clientAadApplication.ObjectId -EndDate (Get-Date).AddYears(10)
    }
    elseif ($certificatePath){
        if (-not ($certificatePath.Contains("generate"))) {
            $certificate = Import-Certificate -FilePath $certificatePath -CertStoreLocation cert:\CurrentUser\My
        }
        $certSubject = $null
        if (!$certificate) {
            # Generate a certificate

            $certSubject = $appName + "Cert"
            $certificate = New-SelfSignedCertificate -Subject CN=$subject `
                -CertStoreLocation "Cert:\CurrentUser\My" `
                -KeyExportPolicy Exportable `
                -KeySpec Signature
        }
        $certKeyId = [Guid]::NewGuid()
        $certSubject = $certificate.Subject
        $certBase64Value = [System.Convert]::ToBase64String($certificate.GetRawCertData())
        $certBase64Thumbprint = [System.Convert]::ToBase64String($certificate.GetCertHash())

        # Add a Azure Key Credentials from the certificate for the daemon application
        $clientKeyCredentials = New-AzureADApplicationKeyCredential -ObjectId $clientAadApplication.ObjectId `
            -CustomKeyIdentifier $certBase64Thumbprint `
            -Type AsymmetricX509Cert `
            -Usage Verify `
            -Value $certBase64Value `
            -StartDate $certificate.NotBefore `
            -EndDate $certificate.NotAfter
    }

    $currentAppId = $clientAadApplication.AppId
    $clientServicePrincipal = New-AzureADServicePrincipal -AppId $currentAppId -Tags { WindowsAzureActiveDirectoryIntegratedApp }

    # add the user running the script as an app owner if needed
    $owner = Get-AzureADApplicationOwner -ObjectId $clientAadApplication.ObjectId
    if ($owner -eq $null) { 
        Add-AzureADApplicationOwner -ObjectId $clientAadApplication.ObjectId -RefObjectId $user.ObjectId
        LogWrite( "'$($user.UserPrincipalName)' added as an application owner to app '$($clientServicePrincipal.DisplayName)'")
    }

    LogWrite( "Done creating the client application ($appName)")

    # URL of the AAD application in the Azure portal
    # Future? $clientPortalUrl = "https://portal.azure.com/#@"+$tenantName+"/blade/Microsoft_AAD_RegisteredApps/ApplicationMenuBlade/Overview/appId/"+$clientAadApplication.AppId+"/objectId/"+$clientAadApplication.ObjectId+"/isMSAApp/"
    $clientPortalUrl = "https://portal.azure.com/#blade/Microsoft_AAD_RegisteredApps/ApplicationMenuBlade/CallAnAPI/appId/" + $clientAadApplication.AppId + "/objectId/" + $clientAadApplication.ObjectId + "/isMSAApp/"
    # Add-Content -Value "<tr><td>client</td><td>$currentAppId</td><td><a href='$clientPortalUrl'>$appName</a></td></tr>" -Path createdApps.html
    if ($applicationPermissions -or $delegatedPermissions) {
        $requiredResourcesAccess = New-Object System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.RequiredResourceAccess]
        # Add Required Resources Access (from 'client' to 'Microsoft Graph')
        LogWrite( "Getting access from 'client' to 'Microsoft Graph'")
        if ($PublicClient) {
            $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
                -requiredDelegatedPermissions $delegatedPermissions;
        }
        else {
            $requiredPermissions = GetRequiredPermissions -applicationDisplayName "Microsoft Graph" `
                -requiredApplicationPermissions $applicationPermissions `
                -requiredDelegatedPermissions $delegatedPermissions;
        }
        $requiredResourcesAccess.Add($requiredPermissions)
        Set-AzureADApplication -ObjectId $clientAadApplication.ObjectId -RequiredResourceAccess $requiredResourcesAccess
        LogWrite( "Granted permissions.")
    }

    $app = @{
        tenantId = $tenantId
        name     = $appName
        clientId = $clientAadApplication.AppId
        objectId = $clientAadApplication.ObjectId
        spId     = $clientServicePrincipal.ObjectId
    }
    if ($GeneratePassword) {
        $app.Add("clientSecret", $password.value);
    }
    return $app
} catch 
{
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}
}


Function Start-ConsentRedirectServer {
    <#
    .SYNOPSIS
    This function starts an HTTP server used to display the redirect URI of consent request 
    .PARAMETER baseUri
    The base URI of the server
    .PARAMETER redirectUri
    The relative redirect URI of consent request
    .PARAMETER tenantId
#> 
[CmdletBinding()]
param(
    [string] $baseUri = "http://localhost:23456/",
    [string] $redirectUri = "/consent/redirect"
);
    $http = [System.Net.HttpListener]::new() 
    # Hostname and port to listen on
    $http.Prefixes.Add($baseUri)
    # Start the Http Server 
    $http.Start()
    while ($http.IsListening) {
        $context = $http.GetContext()
        if ($context.Request.HttpMethod -eq 'GET' -and $context.Request.RawUrl.StartsWith($redirectUri)) {

            [string]$html = "<h1>Success of the consent request</h1>" 
            $buffer = [System.Text.Encoding]::UTF8.GetBytes($html) # convert htmtl to bytes
            $context.Response.ContentLength64 = $buffer.Length
            $context.Response.OutputStream.Write($buffer, 0, $buffer.Length) #stream to broswer
            $context.Response.OutputStream.Close() # close the response
            LogWrite( "show consent")
            Start-Sleep -Seconds 5
            break;
        }
    }
}
# Export-ModuleMember -Function Start-ConsentRedirectServer

# Adds the requiredAccesses (expressed as a pipe separated string) to the requiredAccess structure
# The exposed permissions are in the $exposedPermissions collection, and the type of permission (Scope | Role) is 
# described in $permissionType
Function AddResourcePermission($requiredAccess, `
        $exposedPermissions, [string]$requiredAccesses, [string]$permissionType) {
    foreach ($permission in $requiredAccesses.Trim().Split("|")) {
        foreach ($exposedPermission in $exposedPermissions) {
            if ($exposedPermission.Value -eq $permission) {
                $resourceAccess = New-Object Microsoft.Open.AzureAD.Model.ResourceAccess
                $resourceAccess.Type = $permissionType # Scope = Delegated permissions | Role = Application permissions
                $resourceAccess.Id = $exposedPermission.Id # Read directory data
                $requiredAccess.ResourceAccess.Add($resourceAccess)
            }
        }
    }
}

#
# Exemple: GetRequiredPermissions "Microsoft Graph"  "Graph.Read|User.Read"
# See also: http://stackoverflow.com/questions/42164581/how-to-configure-a-new-azure-ad-application-through-powershell
Function GetRequiredPermissions([string] $applicationDisplayName, [string] $requiredDelegatedPermissions, [string]$requiredApplicationPermissions, $servicePrincipal, $appid) {
    # If we are passed the service principal we use it directly, otherwise we find it from the display name (which might not be unique)
    if ($servicePrincipal) {
        $sp = $servicePrincipal
    }
    else {
        if ($appid)
        {
            $sp = Get-AzureADServicePrincipal -Filter "AppId eq '$appid'"
        }
        else {
            $sp = Get-AzureADServicePrincipal -Filter "DisplayName eq '$applicationDisplayName'"
        }
    }
    $appid = $sp.AppId
    $requiredAccess = New-Object Microsoft.Open.AzureAD.Model.RequiredResourceAccess
    $requiredAccess.ResourceAppId = $appid 
    $requiredAccess.ResourceAccess = New-Object System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.ResourceAccess]

    # $sp.Oauth2Permissions | Select Id,AdminConsentDisplayName,Value: To see the list of all the Delegated permissions for the application:
    if ($requiredDelegatedPermissions) {
        AddResourcePermission $requiredAccess -exposedPermissions $sp.Oauth2Permissions -requiredAccesses $requiredDelegatedPermissions -permissionType "Scope"
    }

    # $sp.AppRoles | Select Id,AdminConsentDisplayName,Value: To see the list of all the Application permissions for the application
    if ($requiredApplicationPermissions) {
        AddResourcePermission $requiredAccess -exposedPermissions $sp.AppRoles -requiredAccesses $requiredApplicationPermissions -permissionType "Role"
    }
    return $requiredAccess
}


Function Remove-AADApplication-CommonsUtils {
    <#
    .SYNOPSIS
    This function creates the Azure AD application for the sample in the provided Azure AD tenant 
    .DESCRIPTION
    This function creates the Azure AD application for the sample in the provided Azure AD tenant 
    .PARAMETER Credential
    The credential of the Azure AD user used to create the application. if absent, a dialog is displayed to connect to Azure AD 
    .PARAMETER tenantId
    The Active Directory Tenant. This is a GUID which represents the "Directory ID" of the AzureAD tenant
    into which you want to create the apps. Look it up in the Azure portal in the "Properties" of the Azure AD
    .PARAMETER appName
    The name of the application to be removed
#> 
[CmdletBinding()]
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName
)
# Pre-requisites
try {
    if ((Get-Module -ListAvailable -Name "AzureAD") -eq $null) { 
        Install-Module "AzureAD" -Scope CurrentUser 
    } 
    Import-Module AzureAD
    if (!$Credential -and $TenantId) {
        $creds = Connect-AzureAD -TenantId $tenantId
    }
    else {
        if (!$TenantId) {
            $creds = Connect-AzureAD -Credential $Credential
        }
        else {
            $creds = Connect-AzureAD -TenantId $tenantId -Credential $Credential
        }
    }
    $filter = "DisplayName eq '" + $appName + "'"
    $app = Get-AzureADApplication -Filter $filter
    if ($app) {
        Remove-AzureADApplication -ObjectId $app.objectId
    }
    else  {
        throw "Application '$appName' does not exist"
    }
} catch 
{
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUtf8U0OinFoQ10yrerYv/TjMj
# tdOgggP3MIID8zCCAtugAwIBAgIQQbXWrT3RbINCGdQ4EJKTqTANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTI0
# MDIxNjEwMDgyOFoXDTI1MDIxNjEwMjgyOFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOAj77Rg
# di2zGE25oo9G4dAV5wnOyuRoG/sKBGZrt7iX3gUh94RwGpOuVPuL3I/BLMelAGQo
# DGehtWy9SMUkNLRcVWxQaKz1EFkyjlCYJ7S2IswM1BrdaU6b2bkpfP0alxKJylR/
# NXGTwJvZDorYTqgGy2hUn2HG7k6RsF/N13bPlgzXmSysE/qBgCks4yhN8gYh1U6e
# A22M/Mk/uJFKpYF777wxA/XCdPKqFk96QXMwpbfiuiEIo+IDnpeqsYMSJ1MpsZQu
# OijUkSiM0lzxl1DPT6QY/ED0faJEm71WLe/ElrMkN9euaTC0WsfQtzj1dN0ubjr0
# ylIxNfYOzBZVXqkCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTv5lID2ajjezdSKHF+Q+18CZDfXjANBgkqhkiG9w0BAQsFAAOCAQEARBUQ
# yGG9gFaNbKKoOGhySoqf2/3ACBCBLnWKHkGnp0FLDXroaG7g89yqPcxvjvla98Aa
# 50C2RUGBNaFPatz6OE9sFBGqAJ2Hz8EHvMUypRCCyzsQlkrljttkzxcP+NdSRtR6
# JRTrZYj05w7Y4Cs5gdxnK9i6ZjGEPQfIyt3wv/wJJhplIQFIIviH8qqR8iQON+fr
# O0j+Xt322QVuwDRGrcWCCtzK2N6sApX/bxmL3bJozQAvJlZgk+NqmNdAoy/UBL8n
# vqRNvU0H5DTsVzg4AKIl0lSJ11qElh3PpWZOWh5hVVbrhwlQOmXx1WSrNl8uD7jQ
# YG0wT2HTU8whApcBaDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEEG11q090WyDQhnUOBCSk6kwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFGIVXsmYgrWxDoO+9g3TV4U2d1R4MA0GCSqGSIb3DQEBAQUABIIBABfEgXqU
# xxV+Z1GKL+6GphfwR0aV2oifsod68PBFdYlkp02UlQ6PSshEJ2am8IrA2rTIT4yP
# 5IQ0AvkKXOHZ6HTFQwHNaq3KXwpONQ4I80Arnot/EMWozhtucDob71o2FzTeFQIr
# 9Ex7WZBE5LD+rNR2j45VnNQ+ATQp9RI/kGD5g4HzUkn7baYnNuJNLRvFVRat/W+a
# KYl5GNeslPvPFOdShxp/MV8BNLYiqlp7dMqT+RnksPVDniwefZV2URjQPOI87LOJ
# myTyNxdBjVrx1pGysOxEzj+L4jMCSxnXVsbj2p/IXTg5mmrTH0xy4QNQKgh3lRko
# /rcD/HXtaZa7Fx0=
# SIG # End signature block
