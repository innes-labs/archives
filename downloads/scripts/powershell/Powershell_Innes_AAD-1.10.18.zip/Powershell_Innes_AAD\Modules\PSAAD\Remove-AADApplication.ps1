Function Remove-AADApplication {
<# 
.SYNOPSIS
This function removes a Azure Active Directory application.  
.DESCRIPTION
This function removes a Azure Active Directory application.  
.PARAMETER Credential
Exchange credential (admin profile) used to remove the Azure Active Directory application. If absent, a dialog is displayed in the browser to enter the Exchange credentials.
.PARAMETER tenantId
Azure Active Directory Tenant Id of the tenant in which the application has been removed. This parameter is not mandatory. If absent, the tenantId is retrieved automatically after the credentials have been entered in the dialog.
.PARAMETER appName
The name of the Azure Active Directory application.
.OUTPUTS
Nothing
.EXAMPLE
PS C:\>Remove-AADApplication -appname "SignMeeting"
 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $true)]
    [string] $appName
)

$date = Get-Date
LogWrite("$date : delete AAD application with name `"$appName`"")

Remove-AADApplication-CommonsUtils -credential $Credential -tenantId $tenantId -appName $appName 
LogWrite("Application removed")

}
# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUGNKiDNmaEp5ARUC1u5SFjcqj
# JBagggP3MIID8zCCAtugAwIBAgIQQbXWrT3RbINCGdQ4EJKTqTANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTI0
# MDIxNjEwMDgyOFoXDTI1MDIxNjEwMjgyOFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOAj77Rg
# di2zGE25oo9G4dAV5wnOyuRoG/sKBGZrt7iX3gUh94RwGpOuVPuL3I/BLMelAGQo
# DGehtWy9SMUkNLRcVWxQaKz1EFkyjlCYJ7S2IswM1BrdaU6b2bkpfP0alxKJylR/
# NXGTwJvZDorYTqgGy2hUn2HG7k6RsF/N13bPlgzXmSysE/qBgCks4yhN8gYh1U6e
# A22M/Mk/uJFKpYF777wxA/XCdPKqFk96QXMwpbfiuiEIo+IDnpeqsYMSJ1MpsZQu
# OijUkSiM0lzxl1DPT6QY/ED0faJEm71WLe/ElrMkN9euaTC0WsfQtzj1dN0ubjr0
# ylIxNfYOzBZVXqkCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBTv5lID2ajjezdSKHF+Q+18CZDfXjANBgkqhkiG9w0BAQsFAAOCAQEARBUQ
# yGG9gFaNbKKoOGhySoqf2/3ACBCBLnWKHkGnp0FLDXroaG7g89yqPcxvjvla98Aa
# 50C2RUGBNaFPatz6OE9sFBGqAJ2Hz8EHvMUypRCCyzsQlkrljttkzxcP+NdSRtR6
# JRTrZYj05w7Y4Cs5gdxnK9i6ZjGEPQfIyt3wv/wJJhplIQFIIviH8qqR8iQON+fr
# O0j+Xt322QVuwDRGrcWCCtzK2N6sApX/bxmL3bJozQAvJlZgk+NqmNdAoy/UBL8n
# vqRNvU0H5DTsVzg4AKIl0lSJ11qElh3PpWZOWh5hVVbrhwlQOmXx1WSrNl8uD7jQ
# YG0wT2HTU8whApcBaDGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCEEG11q090WyDQhnUOBCSk6kwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFLx70aBBAemhzBI57NTsD3NPEAwvMA0GCSqGSIb3DQEBAQUABIIBANtQHSrd
# /uL4AudTlZ5jRmA2qQt/c/zF63rR5P8AAVb/K3BwtT5xqNegolFRJKOPWou9eBC1
# 6gCrnjp1gAsVxczZQaGnREoISuMjDmuiTef9UfLir38U09eMG/y6wvlSRUUZM6Sd
# nwTVK/h+VIJJ2+imLzQw+ib6htmgykii7y4unoIYO2sauA4ZUN1k+5fgY23XV+Lz
# mItUC2lNPrSxddxSOj88YpxuSc96ESCh8j0vjLV7u1AWie6XNJmD4GvTyD5IY0vk
# z44C9qsz1XlPJDq9diSqnMjaZX9s6upWGrtH3c3dJB6OsU/ixnieLax/LA3Su22m
# xbk7v+jagsj9o5E=
# SIG # End signature block
