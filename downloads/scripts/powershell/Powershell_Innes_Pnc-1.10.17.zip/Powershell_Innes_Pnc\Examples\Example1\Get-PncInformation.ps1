<#
.SYNOPSIS
This script permits to get many information from PlugnCast Server
.DESCRIPTION
This script permits to get many information from PlugnCast Server
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain). Example: "demo.plugncast.com", "localhost"
.PARAMETER urlPort
The Plugncast G3 server port (443 by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used (default "superadmin")
.PARAMETER urlPassword
The password of authentication if the certificate is not used (default "superadmin")
.PARAMETER logFile
The path of log file (default "./Get-PncInformation.log")
.EXAMPLE
Get-PncInformation -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort = 443,
    [string] $UrlLogin = "superadmin",
    [string] $UrlPassword = "superadmin",
    [string] $LogFile = "./Get-PncInformation.log"
)
# Import Pnc Module
Import-Module PSPnc
# Clear the log file of any previous try
If ($LogFile -and (Test-Path $LogFile) -eq $True) {
    Remove-Item -Path $LogFile
}
$verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
# Get all the information
$result = Get-PncVersion -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
$result = Get-PncDomainsAndTargets -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
$result = Get-PncLicense -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
$result = Get-PncAppi -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
$result = Get-PncAppiDomainAssociation -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -appi "playzilla" -logFile $LogFile -vb:$verbose
$result = Get-PncContentModelInstalled -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose


# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUnG7nSjqgFdQ1EaDMqkdFonUk
# rb+gggP3MIID8zCCAtugAwIBAgIQJzAOpCsXRaZBggO0ElA95zANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDYyNTE0Mzg0MFoXDTIyMDYyNTE0NTg0MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALF+uOga
# IaW41f6uzuOE2vvJLV+am8SZaD6OQZYCy9s8v/iFGC2r5oUzcYIZ6KpktbTYgET2
# a+m6IaMsU+S6uM/PHML3RVcY8oucFulyvaeewR2iRjnmWB+nWLWPmwdcN9yGgooH
# YcWcn1eQM2LNl/d49yhakmgGUB5vT0KtKu8aaIJ8JBSxacmKGj+8EgnEBL51qIsp
# SNq73cMIQBTw8/ABPmIIZnxTXBrI+FbGgtwf7x6liwLVmAnWa+cLR9tuvd4F+DEH
# 6DjNTwrA8Nwf+iUZQPJFpMuYN+yEMWuXNGWuWxmNx/xY9q2Cb75O7Fc+zekLiKkv
# UnrL5+ch/Mgz02UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRFjyhs3nJq3Ohjqpq4IccsXX8P2jANBgkqhkiG9w0BAQsFAAOCAQEAOU5c
# jdTLoGA+qs2VoPmnNfjb0MC3dbo9+li6mdgp+UJRV/7jW+tvKOItt/NUK+ycxYRL
# 9bDiqQnGGjxcNh+wwKdQxUZZQGASl+sh/PslLSaf/WVJH7gpO/oy6fsMgn15fY3z
# S6xlxo4uYq1kx2+0uXkP7Kkf4yFEWZMtDFwazUsenhfHnMzBPx5I6IFZVi0yoiHd
# /p/EIpbGmqtVGqKmgpVyuf/sEplvSmIMnOEtHyKQE1wW7sOysK0KXJVeboS3ixyH
# IuygOQUCopLedfw37VdIsfQ/K6VljYxHbiF4l4N7Fu9SkHOYVpmfyu/tG7F/vPH7
# 3ExUnpV5PUH5xEAxszGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECcwDqQrF0WmQYIDtBJQPecwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFFaNgKvOMM7ZVOHyFUVa1Rci08G0MA0GCSqGSIb3DQEBAQUABIIBAGmRnmbI
# Mo6uURgloulQ0gd3FVurrYOxUzB2/xVoFrzpKAotnxBp5eLOkhd3eAgaOxv1aLbW
# w6ClXdxrPLAQxMuKniiRIJuPtVJpqMpsJTADVimVVQskkWqlNHCe5M0G27OMFAGH
# Ipqmu7q635t8AAbdnP9S1S2s9d5VwOh+95JnnvucV2ij6N6zEwz7X2Ei5DytwhDH
# g8Wv1R/Ta00Z/FCNx9w3OS5GG5CdFTL46SngvUgmbyWXnBqZDuqJNiHakXO8sJlP
# 8ufJjzlUaD5wtcnEEN9Ea+VSA82t+lTcX+H4lcM7HbbX4m3N3CmGS52W9oQawCK6
# 3qxMTkd5e7mfeYA=
# SIG # End signature block
