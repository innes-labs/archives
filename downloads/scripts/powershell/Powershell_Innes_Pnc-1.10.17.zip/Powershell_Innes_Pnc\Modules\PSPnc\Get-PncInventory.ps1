# Load utilities
Function Get-PncInventory {
<# 
.SYNOPSIS
This function queries a array of Plugncast G3 server to create an inventory.
.DESCRIPTION
The function uses as input a array of objects associated with the servers to be queried. 
Each object must at least contain the property "ip" or "host" which gives the address (or domain) of the Plugncast server. 
It can also contain the properties:
- port that defines the HTTPS port of server,
- username that defines the authentication user,
- password that defines the authentication password.
Each object can contain other properties which are not used by the function and which are returned unchanged.

The output of the function is the input array to which the
following properties are added to each object:
- status: which is "OK" if the server answered, "KO" otherwise
- pncVersion: version of the Plugncast server,
- nbDomain: number of domains,
- domainNames: domain names separated by newlines,
- licenseMail : the mail used with license,
- nbLicenseDomain: number of valid licenses of domain,
- nbLicensePlayzillaValid: number of valid license of playzilla,
- nbLicensePlayzillaWithDomain: number of valid license of playzilla with domain,
- nbLicensePlayzillaWithoutDomain: number of valid license of playzilla without domain,
- nbLicensePlayzillaInvalid: number of invalid license of playzilla.
.PARAMETER servers
Array the objects associated with the servers to be queried. 
Each object of the array must contain the property "ip" or "host" and optionally the properties "port", "username" and password
.PARAMETER defaultAuthentication
True if the default super administrator user credentials should be used if the credentials are missing 
.PARAMETER logFile
The path of log file
.OUTPUTS
The input array completed with the retrieved information (see DESCRIPTION).
.EXAMPLE
PS C:>[System.Collections.ArrayList]$servers = @(
    [PSCustomObject]@{ip="192.168.1.45";port="8443";login="superadmin";password="superadmin";field1="Field1 value1";field2="Field2 value1"}
    [PSCustomObject]@{ip="192.168.1.10";port="443";login="superadmin";password="superadmin";field1="Field1 value2";field2="Field2 value2"}
)
PS C:>$result = Get-PncInventory -server $servers
PS C:>$result
ip                              : 192.168.1.45
port                            : 8443
login                           : superadmin
password                        : superadmin
field1                          : Field1 value1
field2                          : Field2 value1
status                          : OK
pncVersion                      : 3.12.10
nbDomain                        : 2
domainNames                     : toto
                                  odav.fr
licenseMail	                    : labs@innes.fr
psnCore                         : PSN00780-00449 CD6
psnDomain                       : -
                                  PSN00160-00319 CD4
nbLicenseDomain                 : 101
nbLicensePlayzillaValid         : 1500
nbLicensePlayzillaWithDomain    : 9
nbLicensePlayzillaWithoutDomain : 1491
nbLicensePlayzillaInvalid       : 13

ip                              : 192.168.1.10
port                            : 443
login                           : superadmin
password                        : superadmin
field1                          : Field1 value2
field2                          : Field2 value2
status                          : OK
pncVersion                      : 3.11.11
nbDomain                        : 3
domainNames                     : domain2
                                  domain1
                                  domain3
licenseMail                     : labs@innes.fr
psnCore                         : PSN00780-00449 CD6
psnDomain                       : -
                                  PSN00160-00319 CD4
                                  PSN00160-00391 CD0
nbLicenseDomain                 : 4
nbLicensePlayzillaValid         : 5
nbLicensePlayzillaWithDomain    : 4
nbLicensePlayzillaWithoutDomain : 1
nbLicensePlayzillaInvalid       : 1
.NOTES
VERSION:1.10.11
#>
    [CmdletBinding()] 
    param(

        [Parameter(Mandatory = $true)]
        [PSCustomObject[]] $servers,
        [boolean] $defaultAuthentication = $true,
        [string] $LogFile
    )
    $verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)
    $date = Get-Date
    $ScriptName = $MyInvocation.MyCommand.Name
    LogWrite("$date - $ScriptName")
    foreach ($server in $servers) {
        $urlHost = $null
        $urlPort = $server.port;
        $urlLogin = $server.login;
        $urlPassword = $server.password;
        if (!$urlLogin -and $defaultAuthentication)
        {
            $urlLogin = "superadmin"
        }
        if (!$urlPassword -and $defaultAuthentication)
        {
            $urlPassword = "superadmin"
        }
        if ($server.ip) {
            $urlHost = $server.ip
        }
        elseif ($server.host) {
            $urlHost = $server.host
        }
        else {
            throw "object must defines 'ip' or 'host' property"
        }
        try {
            $server | Add-Member -MemberType NoteProperty -Name "status" -Value "KO" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "pncVersion" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "domainNames" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "licenseMail" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "psnCore" -Value "" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "psnDomain" -Value "-" | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicenseDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaValid" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaWithDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaWithoutDomain" -Value 0 | Out-Null
            $server | Add-Member -MemberType NoteProperty -Name "nbLicensePlayzillaInvalid" -Value 0 | Out-Null
            # Version
            $result = Get-PncVersion -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $server.pncVersion = $result;
            # Domains
            $result = Get-PncDomainsAndTargets -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $server.nbDomain = $result.numberDomain
            $domainNames = ""
            foreach ($domain in $result.domains) {
                $domainNames += $domain.Name + "`n"
            }
            if ($domainNames) {
                $domainNames = $domainNames.substring(0, $domainNames.length - 1)
            }
            $server.domainNames = $domainNames
            # Domain licenses
            $result = Get-PncLicense -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $server.licenseMail = $result.mail
            $server.nbLicenseDomain = $result.licenses.numberDomains
			$server.psnCore = $result.psn
			if ( $server.nbLicenseDomain -gt 1) {
				foreach ($prop in $result.licenses.licenses.PsObject.Properties) {
                    if ($prop.Value.psn -ne $result.psn) {
					    $server.psnDomain += "`n" + $prop.Value.psn
                    }
				}
			}
            # Playzilla
            $result = Get-PncAppi -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -urlPassword $urlPassword -logFile $LogFile -vb:$verbose
            $playzilla = $result."urn:innes:system-app#playzilla"
            $server.nbLicensePlayzillaValid = $playzilla.nbValidTokens
            foreach ($prop in $playzilla.licenses.PsObject.Properties)
            {
                $license = $prop.Value
                if (!$license.valid) {
                    $server.nbLicensePlayzillaInvalid++;
                }
                elseif ($license.domain)
                {
                    $server.nbLicensePlayzillaWithDomain++

                }                    
                else {
                    $server.nbLicensePlayzillaWithoutDomain++
                }
            }
            $server.status = "OK"
        }
        catch {
            LogWrite("Error with server " + $urlHost);
            Write-Warning("Error with server " + $urlHost);
        }
    }
    $servers
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUwaGtJLeZgYMNHhAzLK0Krois
# JNagggP3MIID8zCCAtugAwIBAgIQJzAOpCsXRaZBggO0ElA95zANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDYyNTE0Mzg0MFoXDTIyMDYyNTE0NTg0MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALF+uOga
# IaW41f6uzuOE2vvJLV+am8SZaD6OQZYCy9s8v/iFGC2r5oUzcYIZ6KpktbTYgET2
# a+m6IaMsU+S6uM/PHML3RVcY8oucFulyvaeewR2iRjnmWB+nWLWPmwdcN9yGgooH
# YcWcn1eQM2LNl/d49yhakmgGUB5vT0KtKu8aaIJ8JBSxacmKGj+8EgnEBL51qIsp
# SNq73cMIQBTw8/ABPmIIZnxTXBrI+FbGgtwf7x6liwLVmAnWa+cLR9tuvd4F+DEH
# 6DjNTwrA8Nwf+iUZQPJFpMuYN+yEMWuXNGWuWxmNx/xY9q2Cb75O7Fc+zekLiKkv
# UnrL5+ch/Mgz02UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRFjyhs3nJq3Ohjqpq4IccsXX8P2jANBgkqhkiG9w0BAQsFAAOCAQEAOU5c
# jdTLoGA+qs2VoPmnNfjb0MC3dbo9+li6mdgp+UJRV/7jW+tvKOItt/NUK+ycxYRL
# 9bDiqQnGGjxcNh+wwKdQxUZZQGASl+sh/PslLSaf/WVJH7gpO/oy6fsMgn15fY3z
# S6xlxo4uYq1kx2+0uXkP7Kkf4yFEWZMtDFwazUsenhfHnMzBPx5I6IFZVi0yoiHd
# /p/EIpbGmqtVGqKmgpVyuf/sEplvSmIMnOEtHyKQE1wW7sOysK0KXJVeboS3ixyH
# IuygOQUCopLedfw37VdIsfQ/K6VljYxHbiF4l4N7Fu9SkHOYVpmfyu/tG7F/vPH7
# 3ExUnpV5PUH5xEAxszGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECcwDqQrF0WmQYIDtBJQPecwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFK7l9/92DBAgtXE0rutCkT9bCxNkMA0GCSqGSIb3DQEBAQUABIIBAIZzaSBV
# YjkBScDU8OytMlTMnZKjqxbpHmeO5+kOuM2JvpFNb8PsS2eS/elnR6bQ8+SajrGx
# 8pY5WV+AaO9gXlQsTkrBDbTYFD41RNk6fWdjpswBAQt5kd+ARGLKW/AGAXRzonFK
# Yv4bRqhYoZy2KDvFquFnfpH6y1nOC7XBC2ZKdgfVt80kR08b/dwqFI+5+m59nFRW
# JIQoUd/5dMIC4mzfarDeKQV+R0OHO4+BB8HBBAz2RrCy8GyaW77hs7aT0xXScm/L
# orLpAP+3uA9faNHX5hz4rD+/siV2ceokXu1sNl6ckiPLNBLPFETH/Zi4U5e+B49x
# WgHP/vUPOp0aNZo=
# SIG # End signature block
