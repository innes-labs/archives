Function New-PncAADApplication {
<# 
.SYNOPSIS
This function creates the Azure AD application for Plugncast  
.DESCRIPTION
The application created can be used to create Azure AD provider with New-PncOpenIdProviderAAD function. 
.PARAMETER Credential
The credential of the Azure AD user used to create the application. if absent, a dialog is displayed to connect to Azure AD 
.PARAMETER tenantId
The Active Directory Tenant. This is a GUID which represents the "Directory ID" of the AzureAD tenant
into which you want to create the apps. Look it up in the Azure portal in the "Properties" of the Azure AD
.PARAMETER appName
The name of the application 
.PARAMETER pncUrlHost
The host (ip or domain) of Plugncast server.
.PARAMETER pncUrlPort
The port of Plugncast server
.PARAMETER logFile
The path of log file

.OUTPUTS
The object that describe the application created. This object is already dumped in the file names "<appName>.json"
Its contains the following properties:
name : the application name
tenantId : the tenant id
clientId : the client id of application
objectId : the object id of application
clientSecret: the client secret generated (present only if parameter GeneratePassword is $true)
spId : the service pricipal id of application

 .NOTES 
 VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [PSCredential] $Credential,
    [Parameter(Mandatory = $False, HelpMessage = 'Tenant ID (This is a GUID which represents the "Directory ID" of the AzureAD tenant into which you want to create the apps')]
    [string] $tenantId,
    [Parameter(Mandatory = $false)]
    [string] $appName = "Plugncast",
    [Parameter(Mandatory = $true)]
    [string] $pncUrlHost,
    [string] $pncUrlPort,
    [string] $LogFile
)
$Server=$pncUrlHost
if ($pncUrlPort) {
   $Server += ":" + $pncUrlPort
}
$BaseServerUri = "https://$Server/.plugncast"

$date = Get-Date
LogWrite("$date : create new AAD application with name `"$appName`" for server `"$server`"")

[String[]] $replyUrls= @("$BaseServerUri/openid/login/redirect", "$BaseServerUri/openid/adminconsent/redirect")
$logoutUrl="$BaseServerUri/openid/logout"
$homepage="https://$Server/cms"

$app = New-AADApplication -credential $Credential -tenantId $tenantId -appName $appName `
        -ReplyUrls $replyUrls -logoutUrl $logoutUrl -homepage $homepage `
      -generatePassword $true -applicationPermissions "User.Read.All|Group.Read.All|GroupMember.Read.All"

Set-Content -Path ".\$appName.json" -Value ($app | ConvertTo-Json -Depth 5)
LogWrite("Application created")
$app
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUI8sMAcvYQcRi9wP6nw7FvorO
# n66gggP3MIID8zCCAtugAwIBAgIQJzAOpCsXRaZBggO0ElA95zANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDYyNTE0Mzg0MFoXDTIyMDYyNTE0NTg0MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALF+uOga
# IaW41f6uzuOE2vvJLV+am8SZaD6OQZYCy9s8v/iFGC2r5oUzcYIZ6KpktbTYgET2
# a+m6IaMsU+S6uM/PHML3RVcY8oucFulyvaeewR2iRjnmWB+nWLWPmwdcN9yGgooH
# YcWcn1eQM2LNl/d49yhakmgGUB5vT0KtKu8aaIJ8JBSxacmKGj+8EgnEBL51qIsp
# SNq73cMIQBTw8/ABPmIIZnxTXBrI+FbGgtwf7x6liwLVmAnWa+cLR9tuvd4F+DEH
# 6DjNTwrA8Nwf+iUZQPJFpMuYN+yEMWuXNGWuWxmNx/xY9q2Cb75O7Fc+zekLiKkv
# UnrL5+ch/Mgz02UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRFjyhs3nJq3Ohjqpq4IccsXX8P2jANBgkqhkiG9w0BAQsFAAOCAQEAOU5c
# jdTLoGA+qs2VoPmnNfjb0MC3dbo9+li6mdgp+UJRV/7jW+tvKOItt/NUK+ycxYRL
# 9bDiqQnGGjxcNh+wwKdQxUZZQGASl+sh/PslLSaf/WVJH7gpO/oy6fsMgn15fY3z
# S6xlxo4uYq1kx2+0uXkP7Kkf4yFEWZMtDFwazUsenhfHnMzBPx5I6IFZVi0yoiHd
# /p/EIpbGmqtVGqKmgpVyuf/sEplvSmIMnOEtHyKQE1wW7sOysK0KXJVeboS3ixyH
# IuygOQUCopLedfw37VdIsfQ/K6VljYxHbiF4l4N7Fu9SkHOYVpmfyu/tG7F/vPH7
# 3ExUnpV5PUH5xEAxszGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECcwDqQrF0WmQYIDtBJQPecwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFOt1oqCmSBJNZfyoPbcAiao1e6eEMA0GCSqGSIb3DQEBAQUABIIBAHexZNBe
# dU48r9W9OKQYJXSlwVXSR5nUq61oQnOgbBfpK4WrsP2uqFoJlkuGB5e6PTdjUbH8
# mz2Vg0FgW6VV1ReYsHe73FB0aIvQ00TfRzHcqPk7v/BaWYmpzHb03rwhavlg5ieu
# B3SGlnIdR7z+4pDLplHSkyXorImkXJUJcDj/Kmg1ki/FdmGqD3JO7719gP2bN5fR
# Pd11ddWY8ogdNwcWPMQq4BmL1FaLDr5pEztFBhyB7g/2101UwnCO6CJiHqRgrb/0
# csdTvoTqF3eqLvtSVz8KwBd4jnrhAvHEi54+4bV7etViMoCCpsDYLtdEjeIGqMp1
# oQogLCNnmxAYIuQ=
# SIG # End signature block
