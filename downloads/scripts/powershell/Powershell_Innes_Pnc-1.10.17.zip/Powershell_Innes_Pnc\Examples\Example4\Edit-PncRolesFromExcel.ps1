﻿<#
.SYNOPSIS
This script permits to change the roles of a PlugnCast server from an MS-Excel file.
.DESCRIPTION
This script permits to change the roles of a PlugnCast server from an MS-Excel file.
The table of the Excel file must respect the format of the table produced by the script Get-PncRolesToExcel.
.PARAMETER excelFilePath
The path of the MS-Excel file path. The default value is ".\Roles-INNES_PlugnCast.xlsx"
.PARAMETER permitWord
The word stored in the MS-Excel cells for the allowed features. Comparisons are not case sensitive and spaces in MS-Excel cells are removed 
.PARAMETER notPermitWord
The word stored in the MS-Excel cells for the unauthorized features. Comparisons are not case sensitive and spaces in MS-Excel cells are removed 
.PARAMETER urlHost
The plugncast G3 server host (IP or DNS domain)
 .PARAMETER urlPort
The  plugncast G3 server port (443 by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used (default "superadmin")
.PARAMETER urlPassword
The password of authentication if the certificate is not used (default "superadmin")
.PARAMETER logFile
The path of log file
.EXAMPLE
PS C:\install directory>.\Edit-PncRolesToExcel -excelFilePath ".\input.xlsx" -urlHost 192.168.1.23
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$false)]
    [string] $excelFilePath = ".\Roles-INNES_PlugnCast.xlsx",
    [Parameter(Mandatory=$false)]
    [ValidatePattern("^[^ ]*$")]
    [string] $permitWord = "x",
    [Parameter(Mandatory=$false)]
    [ValidatePattern("^[^ ]*$")]
    [string] $notPermitWord = "",
    [string] $UrlHost,
    [string] $UrlPort = 443,
    [string] $UrlLogin = "superadmin",
    [string] $UrlPassword = "superadmin",
    [string] $LogFile
)
$permitWord = $permitWord.ToLower();
$notPermitWord = $notPermitWord.ToLower();
$header=@("Description","Identifier")
[PSCustomObject] $rolesAndFeatures = Get-PncRolesInformation
$header += $rolesAndFeatures.roles

# Import Pnc Module
Import-Module PSPnc -MinimumVersion 1.10.17
if (!$?) {
	Write-Host("You must use PnC module Version 1.10.17 minimum. Please update it before re-trying.")
	exit(1)
}
# Import Module PSExcel
Import-Module PSExcel
# Clear the log file of any previous try
If ($LogFile -and (Test-Path $LogFile) -eq $True) {
    Remove-Item -Path $LogFile
}
$verbose = ($VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue)

# Get roles
Write-Host("Start to query the Pnc server '$urlHost'")
$roles = Get-PncRoles -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -UrlPassword $UrlPassword -LogFile $LogFile -vb:$verbose
try {
# Get new role in excel file
    $excel = Import-XLSX -Path $excelFilePath -Header $header
}
catch 
{
    Write-Error($Ex.Exception.message)
    Write-Error("Unable to read the Excel file `"" + $excelFilePath + "`"")
    exit 1
}
if (!$excel)
{
    Write-Error("Unable to read the Excel file `"" + $excelFilePath + "`"")
	exit(1)
}
$edited = 0
for ($i = 0; $i -lt $rolesAndFeatures.roles.Count; $i++) { 
    $role = $rolesAndFeatures.roles[$i]
    [System.Collections.ArrayList]$features = @()

    foreach ($line in $excel)
    {
        $feature = $line.identifier;
        $r = [string] $line.$role
        $r = $r.Trim().ToLower()
        if ($r -eq $permitWord)
        {
            $features += $feature
        }
        elseif ($r -eq $notPermitWord)
        {
        }
        else {
            Write-Error("Value '" + $r + "' not permitted")
            exit 1         
        }
    }
    #  Verify if features are changed
    [System.Collections.ArrayList]$oldFeatures = @()
    foreach ($p in $roles.$role.permissions.PSObject.Properties)
    {
        if ($p.value -eq "permit")
        {
            $oldFeatures += $p.name
        }
        
    }
    $oldFeatures = $oldFeatures | Sort-Object
    $diff = Compare-Object -ReferenceObject $features -DifferenceObject $oldFeatures
    if ($diff)
    {
        if ($i -eq 0)
        {
            Write-Error ("cannot modify the super administrator role ");
            exit 1
        }
        else {
            Write-Host("Change role `"" + $role + "`"")
            Edit-PncRole -urlHost $urlHost -urlPort $urlPort -urlLogin $urlLogin -UrlPassword $UrlPassword -role $role -feature $features -LogFile $LogFile -vb:$verbose
            $edited++
        }
    }
}
if ($edited -eq 0)
{
    Write-Host("No role changed")
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUkVTtG/S9Z7otVGzlfsb5DBEj
# t1igggP3MIID8zCCAtugAwIBAgIQJzAOpCsXRaZBggO0ElA95zANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDYyNTE0Mzg0MFoXDTIyMDYyNTE0NTg0MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALF+uOga
# IaW41f6uzuOE2vvJLV+am8SZaD6OQZYCy9s8v/iFGC2r5oUzcYIZ6KpktbTYgET2
# a+m6IaMsU+S6uM/PHML3RVcY8oucFulyvaeewR2iRjnmWB+nWLWPmwdcN9yGgooH
# YcWcn1eQM2LNl/d49yhakmgGUB5vT0KtKu8aaIJ8JBSxacmKGj+8EgnEBL51qIsp
# SNq73cMIQBTw8/ABPmIIZnxTXBrI+FbGgtwf7x6liwLVmAnWa+cLR9tuvd4F+DEH
# 6DjNTwrA8Nwf+iUZQPJFpMuYN+yEMWuXNGWuWxmNx/xY9q2Cb75O7Fc+zekLiKkv
# UnrL5+ch/Mgz02UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRFjyhs3nJq3Ohjqpq4IccsXX8P2jANBgkqhkiG9w0BAQsFAAOCAQEAOU5c
# jdTLoGA+qs2VoPmnNfjb0MC3dbo9+li6mdgp+UJRV/7jW+tvKOItt/NUK+ycxYRL
# 9bDiqQnGGjxcNh+wwKdQxUZZQGASl+sh/PslLSaf/WVJH7gpO/oy6fsMgn15fY3z
# S6xlxo4uYq1kx2+0uXkP7Kkf4yFEWZMtDFwazUsenhfHnMzBPx5I6IFZVi0yoiHd
# /p/EIpbGmqtVGqKmgpVyuf/sEplvSmIMnOEtHyKQE1wW7sOysK0KXJVeboS3ixyH
# IuygOQUCopLedfw37VdIsfQ/K6VljYxHbiF4l4N7Fu9SkHOYVpmfyu/tG7F/vPH7
# 3ExUnpV5PUH5xEAxszGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECcwDqQrF0WmQYIDtBJQPecwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFJkhU9YPpuirdaA9JG/IKCYkYuTMMA0GCSqGSIb3DQEBAQUABIIBALD2J+Kh
# 7x7yLR/Pv3qPJVzZYO5ci2bFH1I1NMRvnk4ECLg5A2U3uRR8O8OLuYyqZ8j+XisO
# vyaasv6cHIPKCVMNK7JP4xj3bYhdXjOvrRL9gkDq8ILxdAS0WVD5iJWiOsT3WfnT
# 5DOPIHoi+XHApzIXrJ8krgX7jUhMm4U/e+sNUUT3yaUnfHvPrtbJn73cjqyg6hsl
# VFE8abC9e2dIGnhRm6vUFjfh9E2qIhViIG4ZzLRoduiGDW/JWv0DeS9RgQMcRGTJ
# SpZqImXx5sRKXhQFREWK9oaijpGexX3Zsv9zaOqxUQfobOT5Lvb7HM/ujObRah54
# ZllMBL3c4nKUMbo=
# SIG # End signature block
