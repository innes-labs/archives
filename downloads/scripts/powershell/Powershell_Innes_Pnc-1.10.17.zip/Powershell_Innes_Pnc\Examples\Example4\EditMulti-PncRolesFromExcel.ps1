﻿<#
.SYNOPSIS
This script permits to change the roles of a list of PlugnCast server from an MS-Excel file.
.DESCRIPTION
This script permits to change the roles of a list of PlugnCast server from an MS-Excel file.
The table of the MS-Excel file must respect the format of the table produced by the script  Get-PncRolesToExcel.
Warning, this script file must be encoded in UTF8 with BOM so that the accented characters are correctly displayed in the Excel file.

The user can modify the following script variables (at the start):
- $servers which defines the array of objects associated with the servers to query.
   Each object must at least contain the property "ip" or "host" which gives the address (or domain) of the PlugnCast server. 
   It can also contain the properties:
    - port that defines the HTTPS port of server,
    - username that defines the authentication user,
    - password that defines the authentication password.
    (otherwise the default values will be: 443, "superadmin", "superadmin").
.PARAMETER excelFilePath
The path of the MS-Excel file path. The default value is ".\Roles-INNES_PlugnCast.xlsx"
.PARAMETER permitWord
The word stored in the MS-Excel cells for the allowed features. Comparisons are not case sensitive and spaces in MS-Excel cells are removed 
.PARAMETER notPermitWord
The word stored in the MS-Excel cellsfor the unauthorized features. Comparisons are not case sensitive and spaces in MS-Excel cells are removed 
.PARAMETER logFile
The path of log file
.EXAMPLE
PS C:\install directory>.\Edit-PncRolesToExcel -excelFilePath ".\input.xlsx"
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$false)]
    [string] $excelFilePath = ".\Roles-INNES_PlugnCast.xlsx",
    [Parameter(Mandatory=$false)]
    [ValidatePattern("^[^ ]*$")]
    [string] $permitWord = "x",
    [Parameter(Mandatory=$false)]
    [ValidatePattern("^[^ ]*$")]
    [string] $notPermitWord = "",
    [string] $LogFile
)
#-----------------------------------------------------------------------------------------------------------
#               Array of servers to edit
# Each object must at least contain the property "ip" or "host" which gives the address (or domain) of the Plugncast server. 
# It can also contain the properties:
# - port that defines the HTTPS port of server,
# - username that defines the authentication user,
# - password that defines the authentication password.
#-----------------------------------------------------------------------------------------------------------
[System.Collections.ArrayList]$servers = @(
    [PSCustomObject]@{ip="localhost";port="8443";login="superadmin";password="superadmin"}
    [PSCustomObject]@{ip="192.168.1.102";port="8443"}
)
#-----------------------------------------------------------------------------------------------------------
#                  Do not modify anything after this line
#-----------------------------------------------------------------------------------------------------------
# Import Pnc Module
Import-Module PSPnc -MinimumVersion 1.10.17
if (!$?) {
	Write-Host("You must use PnC module Version 1.10.17 minimum. Please update it before re-trying.")
	exit(1)
}
# Import Module PSExcel
Import-Module PSExcel
# Clear the log file of any previous try
If ($LogFile -and (Test-Path $LogFile) -eq $True) {
    Remove-Item -Path $LogFile
}

foreach ($server in $servers)
{
    $urlHost = $server.ip
    if (!$urlHost)
    {
        $UrlHost = $server.host
    }
	$urlPort = $server.port
    if (!$urlPort)
    {
        $urlPort = 443
    }
	$serverLogin = $server.login
    if (!$serverLogin)
    {
        $serverLogin = "superadmin"
    }
	$serverPassword = $server.password
    if (!$serverPassword)
    {
        $serverPassword = "superadmin"
    }
    .\Edit-PncRolesFromExcel.ps1 -excelFilePath $excelFilePath -permitWord $permitWord -notPermitWord $notPermitWord `
    -urlHost $urlHost -urlPort $urlPort -urlLogin $serverLogin -UrlPassword $serverPassword 
}




# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU7djrxg+pPZTXWsq/ePKPwVL7
# trGgggP3MIID8zCCAtugAwIBAgIQJzAOpCsXRaZBggO0ElA95zANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDYyNTE0Mzg0MFoXDTIyMDYyNTE0NTg0MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALF+uOga
# IaW41f6uzuOE2vvJLV+am8SZaD6OQZYCy9s8v/iFGC2r5oUzcYIZ6KpktbTYgET2
# a+m6IaMsU+S6uM/PHML3RVcY8oucFulyvaeewR2iRjnmWB+nWLWPmwdcN9yGgooH
# YcWcn1eQM2LNl/d49yhakmgGUB5vT0KtKu8aaIJ8JBSxacmKGj+8EgnEBL51qIsp
# SNq73cMIQBTw8/ABPmIIZnxTXBrI+FbGgtwf7x6liwLVmAnWa+cLR9tuvd4F+DEH
# 6DjNTwrA8Nwf+iUZQPJFpMuYN+yEMWuXNGWuWxmNx/xY9q2Cb75O7Fc+zekLiKkv
# UnrL5+ch/Mgz02UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRFjyhs3nJq3Ohjqpq4IccsXX8P2jANBgkqhkiG9w0BAQsFAAOCAQEAOU5c
# jdTLoGA+qs2VoPmnNfjb0MC3dbo9+li6mdgp+UJRV/7jW+tvKOItt/NUK+ycxYRL
# 9bDiqQnGGjxcNh+wwKdQxUZZQGASl+sh/PslLSaf/WVJH7gpO/oy6fsMgn15fY3z
# S6xlxo4uYq1kx2+0uXkP7Kkf4yFEWZMtDFwazUsenhfHnMzBPx5I6IFZVi0yoiHd
# /p/EIpbGmqtVGqKmgpVyuf/sEplvSmIMnOEtHyKQE1wW7sOysK0KXJVeboS3ixyH
# IuygOQUCopLedfw37VdIsfQ/K6VljYxHbiF4l4N7Fu9SkHOYVpmfyu/tG7F/vPH7
# 3ExUnpV5PUH5xEAxszGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECcwDqQrF0WmQYIDtBJQPecwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFH6FSj0+p0LY6djYtIG+iQOVBip4MA0GCSqGSIb3DQEBAQUABIIBABMd+hIr
# WLObvo6qvYsLccspLzVwx4Ye4O1/iKz8bx+MH4L2o7UpHyc902pV32y2kJ89+Hwz
# L5KIJZ3V7fhcbdHqH441DjbTdiQj1Hnzatx+gEyb0cbxdSCK9+S31CF2Mx+8FnLZ
# AQ9/wX6t9I3t7sM+IelME2mhZCqvShjTOgVfHV+5CC21DLay9haznwMQI46Iy7Km
# 6qeGvJaDW7LzqNXUlV4VesSRXE8HTWMB2PyCOkzs5xuaJn/3ftVX8XJT4JNULWP/
# ae009vOirFqA+xz8nO9GRGgDMGNlkl7VtfRzKu5yPYbqcw4V7xwvnBqN9kPp9KWn
# J7kfJ9A3vfiWuF8=
# SIG # End signature block
