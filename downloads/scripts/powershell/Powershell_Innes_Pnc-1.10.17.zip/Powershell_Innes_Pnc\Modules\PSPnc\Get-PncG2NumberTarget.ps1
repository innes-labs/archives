Function Get-PncG2NumberTarget {
<#
.SYNOPSIS
This function queries a Plugncast G2 server to retrieve the number of targets registered.
.DESCRIPTION
This function queries a Plugncast G2 server to retrieve the number of targets registered.
.PARAMETER urlHost
The Plugncast G2 server host (IP or DNS domain)
.PARAMETER urlPort
The Plugncast G2 server port (empty by default)
.PARAMETER urlLogin
The login of PNC authentication
.PARAMETER urlPassword
The password of PNC authentication
.PARAMETER logFile
The path of log file
.OUTPUTS
The number of targets registered

.EXAMPLE
Get-PncG2NumberTarget -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION: 1.10.10
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost = $(throw "Please enter the Plugncast G3 host (IP or DNS domain"),
    [string] $UrlPort,
    [Parameter(Mandatory=$true)]
    [string] $UrlLogin,
    [Parameter(Mandatory=$true)]
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/"

# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name
$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve the number of targets registered on PNC G2 server `"$server`"")

Start-Sleep -m $SleepDurationBeforeCommand

try {
    $Uri = $BaseServerUri + "nb.php"
    $ExecutedRequest =  MakeRequest -Method 'GET' -Uri $Uri 
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}

$nb = [int] $ExecutedRequest.Content
LogWrite("Number of targets : " + $nb)
$nb

}


# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUbGm1J127TpjD1r0dmxyD7tzn
# cmugggP3MIID8zCCAtugAwIBAgIQJzAOpCsXRaZBggO0ElA95zANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDYyNTE0Mzg0MFoXDTIyMDYyNTE0NTg0MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALF+uOga
# IaW41f6uzuOE2vvJLV+am8SZaD6OQZYCy9s8v/iFGC2r5oUzcYIZ6KpktbTYgET2
# a+m6IaMsU+S6uM/PHML3RVcY8oucFulyvaeewR2iRjnmWB+nWLWPmwdcN9yGgooH
# YcWcn1eQM2LNl/d49yhakmgGUB5vT0KtKu8aaIJ8JBSxacmKGj+8EgnEBL51qIsp
# SNq73cMIQBTw8/ABPmIIZnxTXBrI+FbGgtwf7x6liwLVmAnWa+cLR9tuvd4F+DEH
# 6DjNTwrA8Nwf+iUZQPJFpMuYN+yEMWuXNGWuWxmNx/xY9q2Cb75O7Fc+zekLiKkv
# UnrL5+ch/Mgz02UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRFjyhs3nJq3Ohjqpq4IccsXX8P2jANBgkqhkiG9w0BAQsFAAOCAQEAOU5c
# jdTLoGA+qs2VoPmnNfjb0MC3dbo9+li6mdgp+UJRV/7jW+tvKOItt/NUK+ycxYRL
# 9bDiqQnGGjxcNh+wwKdQxUZZQGASl+sh/PslLSaf/WVJH7gpO/oy6fsMgn15fY3z
# S6xlxo4uYq1kx2+0uXkP7Kkf4yFEWZMtDFwazUsenhfHnMzBPx5I6IFZVi0yoiHd
# /p/EIpbGmqtVGqKmgpVyuf/sEplvSmIMnOEtHyKQE1wW7sOysK0KXJVeboS3ixyH
# IuygOQUCopLedfw37VdIsfQ/K6VljYxHbiF4l4N7Fu9SkHOYVpmfyu/tG7F/vPH7
# 3ExUnpV5PUH5xEAxszGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECcwDqQrF0WmQYIDtBJQPecwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFKnrGxa8/CsS1KgqfrhaOYii0XZhMA0GCSqGSIb3DQEBAQUABIIBAIHukDJw
# UB1GELe7ilsz90cnd9JHCG62SfSFvMToY+Zm/T/WESmne6V9hGd3dAKGqHK9r0ZT
# OYgRoa1kem2B7Com0l4QqdTIy1+8AMt2ndG9UZWLrrlKtCVyRRPdADYupT6kt43x
# m8sdBzxh/0mOQjowPb8Ylq1zDvSe0vI/9vMnGQ3lNFJ+iYTq4lEuwFjZfCp3SVmc
# FLTxAyCXtqQJ1RRT9jLctQcgHPnhdJVwkH/cscXUYthi3G54ci2Wq3hIjEHCBMJF
# 6OTYewW11tOMk9ltIwj7DA5/PjBDj/dLzpDDbwtd+tnOfmnNCvlVZNjnSPICR9vi
# 5WxZQ1U07FafVmQ=
# SIG # End signature block
