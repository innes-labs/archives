

Function New-PncUri {
<#
.SYNOPSIS
This function generates a Plugncast URI file
.DESCRIPTION
This function generates a Plugncast URI file
.PARAMETER uri
The uri of the media to play, it can be absolute path or relative
.PARAMETER title
The title of URI file
.PARAMETER fallback
The fallback media to play if the URI is not accessible
.PARAMETER thumbnail
The thumbnail associated with the media
.PARAMETER category
The category of the URI file
.PARAMETER mediatype
The type of the media which can be "iframe", "video", "audio", "image", "ebook", "animation" (default "video")
.EXAMPLE
New-PncUri -uri "udp://225.1.1.1:1234" -title "TF1" -thumbnail ".\assets\TF1.png" -category "IPTV"
.NOTES
VERSION:1.10.10
#>
 
[CmdletBinding()]
Param
(
    # Name of the file, can be absolute path or relative
    [Parameter(Mandatory=$true)]
    [string] $uri,
    [string] $title,
    [string] $fallback,
    [string] $thumbnail,
    [string] $category,
    [string] $mediatype = "video"
)
$strDoc=@'
<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:app="ns.innes.app" xmlns="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:ib="ns.innes.backoffice" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
	<x:xmpmeta x:xmptk="Adobe XMP Core 4.4.0-1" xmlns:x="adobe:ns:meta/">
		<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
			<rdf:Description rdf:about=""
					xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:xmpGImg="http://ns.adobe.com/xap/1.0/g/img/"
					xmlns:xmpMM="http://ns.adobe.com/xap/1.0/mm/" xmlns:dc="http://purl.org/dc/elements/1.1/" 
					xmlns:is="ns.innes.metadata" >
				<xmp:Thumbnails>
					<rdf:Alt>
						<rdf:li rdf:parseType="Resource">
							<xmpGImg:format>__FORMAT__</xmpGImg:format>
							<xmpGImg:width>__W__</xmpGImg:width>
							<xmpGImg:height>__H__</xmpGImg:height>
							<xmpGImg:image>__IMG__</xmpGImg:image>
						</rdf:li>
					 </rdf:Alt>
				</xmp:Thumbnails>
				<dc:title>
					<rdf:Alt>
						<rdf:li xml:lang="x-default">__TITLE__</rdf:li>
					</rdf:Alt>
				</dc:title>
				<is:category>
					<rdf:Bag>
						<rdf:li>
							<rdf:Alt>
								<rdf:li xml:lang="x-default">__CATEGORY__</rdf:li>
							</rdf:Alt>
						</rdf:li>
					</rdf:Bag>
				</is:category>
			</rdf:Description>
		</rdf:RDF>
	</x:xmpmeta>
	<rdf:Description xmlns:RDF="http://www.w3.org/1999/02/22-rdf-syntax-ns#" rdf:about="__URI__" rdf:type="uri" ib:mediatype="video">
		<app:condition/>
		<app:fallback active="false" src=""/>
	</rdf:Description>
</rdf:RDF>
'@
$xmlDoc = [System.Xml.XmlDocument] $strDoc
$ns = New-Object System.Xml.XmlNamespaceManager($xmlDoc.NameTable)
[PSCustomObject]$Namespace = @{rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
     x="adobe:ns:meta/"
     is="ns.innes.metadata"
     app="ns.innes.app"
     xmp="http://ns.adobe.com/xap/1.0/"
     xmpMM="http://ns.adobe.com/xap/1.0/mm/"
      stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#"
      xmpGImg="http://ns.adobe.com/xap/1.0/g/img/"
      dc="http://purl.org/dc/elements/1.1/"
      Iptc4xmpExt="http://iptc.org/std/Iptc4xmpExt/2008-02-29/"
      im="ns.innes.metadata"
      xml="http://www.w3.org/XML/1998/namespace"
      xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/"}
    foreach ($key in $Namespace.keys) {
        $ns.AddNamespace($key, $Namespace[$key])
    }
# $nodes = $xmlDoc.SelectNodes("//RDF/Description/", $ns)
$description = $xmlDoc.SelectSingleNode("/rdf:RDF/rdf:Description", $ns)
$description.SetAttribute("rdf:about", $uri);
if ($mediatype){
    $description.SetAttribute("ib:mediatype", $mediatype);
}
if ($fallback) {
    $n = $description.SelectSingleNode("app:fallback", $ns);
    $n.SetAttribute("src", $fallback)
    $n.SetAttribute("active", "true");
}
$xmpmeta = $xmlDoc.SelectSingleNode("//x:xmpmeta", $ns)
if ($thumbnail)
{
    $image  = New-Object -ComObject Wia.ImageFile
    $file = $thumbnail
    if ($thumbnail.StartsWith("."))
    {
        $file = [string] (Get-Location) + "\" +  $thumbnail
    }
    $image.loadfile($file)
    $node = $xmlDoc.SelectSingleNode("//xmp:Thumbnails/rdf:Alt/rdf:li", $ns)
    $n = $node.SelectSingleNode("xmpGImg:format", $ns);
    $n.InnerText = $image.FileExtension.ToUpper();
    $n = $node.SelectSingleNode("xmpGImg:width", $ns);
    $n.InnerText = [string] $image.width;
    $n = $node.SelectSingleNode("xmpGImg:height", $ns);
    $n.InnerText = [string] $image.height;
    $data = [convert]::ToBase64String((get-content $thumbnail -encoding byte -ErrorAction Stop))
    $n = $node.SelectSingleNode("xmpGImg:image", $ns);
    $n.InnerText = $data;
}
else {
    $node = $xmlDoc.SelectSingleNode("//xmp:Thumbnails", $ns)
    $node.ParentNode.RemoveChild($node);
}
if ($title) {
    $node = $xmlDoc.SelectSingleNode("//dc:title/rdf:Alt/rdf:li", $ns)
    $node.InnerText = $title
}
else {
    $node = $xmlDoc.SelectSingleNode("//dc:title", $ns);
    $node.ParentNode.RemoveChild($node);
}
if ($category) {
    $node = $xmlDoc.SelectSingleNode("//is:category/rdf:Bag/rdf:li/rdf:Alt/rdf:li", $ns)
    $node.InnerText = $category
}
else {
    $node = $xmlDoc.SelectSingleNode("//is:category", $ns);
    $node.ParentNode.RemoveChild($node);
}
$str = WriteXml $xmlDoc
$str
}
# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUwBPkPlyZugTv+fnpbvRrezUJ
# V2egggP3MIID8zCCAtugAwIBAgIQJzAOpCsXRaZBggO0ElA95zANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDYyNTE0Mzg0MFoXDTIyMDYyNTE0NTg0MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALF+uOga
# IaW41f6uzuOE2vvJLV+am8SZaD6OQZYCy9s8v/iFGC2r5oUzcYIZ6KpktbTYgET2
# a+m6IaMsU+S6uM/PHML3RVcY8oucFulyvaeewR2iRjnmWB+nWLWPmwdcN9yGgooH
# YcWcn1eQM2LNl/d49yhakmgGUB5vT0KtKu8aaIJ8JBSxacmKGj+8EgnEBL51qIsp
# SNq73cMIQBTw8/ABPmIIZnxTXBrI+FbGgtwf7x6liwLVmAnWa+cLR9tuvd4F+DEH
# 6DjNTwrA8Nwf+iUZQPJFpMuYN+yEMWuXNGWuWxmNx/xY9q2Cb75O7Fc+zekLiKkv
# UnrL5+ch/Mgz02UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRFjyhs3nJq3Ohjqpq4IccsXX8P2jANBgkqhkiG9w0BAQsFAAOCAQEAOU5c
# jdTLoGA+qs2VoPmnNfjb0MC3dbo9+li6mdgp+UJRV/7jW+tvKOItt/NUK+ycxYRL
# 9bDiqQnGGjxcNh+wwKdQxUZZQGASl+sh/PslLSaf/WVJH7gpO/oy6fsMgn15fY3z
# S6xlxo4uYq1kx2+0uXkP7Kkf4yFEWZMtDFwazUsenhfHnMzBPx5I6IFZVi0yoiHd
# /p/EIpbGmqtVGqKmgpVyuf/sEplvSmIMnOEtHyKQE1wW7sOysK0KXJVeboS3ixyH
# IuygOQUCopLedfw37VdIsfQ/K6VljYxHbiF4l4N7Fu9SkHOYVpmfyu/tG7F/vPH7
# 3ExUnpV5PUH5xEAxszGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECcwDqQrF0WmQYIDtBJQPecwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFIzS6uIqYMsNdTLg2hhcnjtCLkfYMA0GCSqGSIb3DQEBAQUABIIBAHt8IsOK
# pLUEdmkg4epd89wPPa0c9qtfNX5rPBSK0aLcVfefvL/TveIqRlhBa0L+SIvyUcDx
# TOr8rU7Hzaxp3lK2Bs8DCLBmxF5UBG0TY8Rdk7hBVbwKoM9LUmhL6hMJkGZtsjWU
# 8oTP+C0wWd7CTNHU4UE4JY2EUIFsq419AUjCz0ro5mB8bQodH+2DXaw6Fy8LIXWj
# 6y+N4Z8reDHPlxE4CZVYFNicGKkc6GvZC+ce/KTLTkjtozi/vanfvRqu3Ti1ToXm
# SiSgoQlIVKoRU2f+D0EcmZ20QSKlsKL/BIexKK0Wll61TQXTOb7/Z4fd/FNlgSU/
# +oTX2vPRwzTrC/s=
# SIG # End signature block
