Function Get-PncAppiDomainAssociation {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the domains of an APPI
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the domains of an APPI
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER appi
The name of appi (playzilla) or identificator of appi (urn:innes:system-app#playzilla)
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell object that describes the domains of the APPI
Example of object formated in JSON :
{
    "nbDomains":  1,
    "domains":  [
                    {
                        "name":  "domain1",
                        "version":  null,
                        "nbLicenses":  9,
                        "licenses":  [ ... ]
                    }
    ]
}
.EXAMPLE
Get-PncAppiDomainAssociation -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [Parameter(Mandatory=$true)]
    [string] $appi,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$urn = "urn:innes:system-app#"
if (!$appi.StartsWith($urn))
{
    $appi = $urn + $appi
}

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve domains of APPI `"$appi`" for server `"$server`"")

 

$Body = @{
    target = "nsIAppliAppis.get"
}
[System.Collections.ArrayList]$argsArray = @()
$argsArray.Add($appi) | Out-Null
$Body | Add-Member -MemberType NoteProperty -Name args -Value $argsArray | Out-Null
$JsonBody = $Body | ConvertTo-Json

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw $_.Exception
}
$appiObject = $ExecutedRequest | ConvertFrom-Json
$result = [PSCustomObject]@{
    nbDomains = 0
}
$unsetDomain = "@unset@"
$domainsLicensesMap = [PSCustomObject]@{}
foreach ($prop in $appiObject.licenses.PsObject.Properties)
{
    $psn = $prop.Name;
    $license = $prop.Value
    $domain = $license.domain
    $l = [PSCustomObject]@{
        psn = $psn
        label = $license.label
        valid = $license.valid
        license = $license.license
    }
    if ($license.valid) {
        $l  | Add-Member -MemberType NoteProperty -Name expired -Value $license.expired | Out-Null
    }
    if ($license.PSObject.Properties['expireDate'])
    {
        $l  | Add-Member -MemberType NoteProperty -Name expireDate -Value $license.expireDate | Out-Null
    }
    if (!$domain)
    {
        $domain = $unsetDomain
    }
    $d = $domainsLicensesMap.$domain
    if (!$d)
    {
        $d = [PSCustomObject]@{nbLicenses = 1}
        [System.Collections.ArrayList]$licenses = @()
        $licenses.Add($l) | Out-Null
        $d | Add-Member -MemberType NoteProperty -Name licenses -Value $licenses | Out-Null
        $domainsLicensesMap | Add-Member -MemberType NoteProperty -Name $domain -Value $d | Out-Null
    }
    else {
        $d.nbLicenses++
        $d.licenses.Add($l) | Out-Null
    }
}
$domainsVersionsMap = [PSCustomObject]@{}
foreach ($prop in $appiObject.versions.PsObject.Properties)
{
    $version = $prop.Name;
    $obj = $prop.Value
    foreach ($domain in $obj.domains) {
        $d = $domainsVersionsMap.$domain
        if (!$d) {
            $d = [PSCustomObject]@{}
            [System.Collections.ArrayList]$versions = @()
            $versions.Add($version) | Out-Null
            $d | Add-Member -MemberType NoteProperty -Name versions -Value $versions | Out-Null
            $domainsVersionsMap | Add-Member -MemberType NoteProperty -Name $domain -Value $d | Out-Null
        }
        else {
            $d.versions.Add($l) | Out-Null
        }
    }
}
[System.Collections.ArrayList]$domainArray = @()
foreach ($prop in $appiObject.domains.PsObject.Properties)
{
        $result.nbDomains += 1
        $name = $prop.Name
        $domain = $prop.Value
        $d = [PSCustomObject]@{
            name = $name
        }
        if ($domain.version)
        {
            $d | Add-Member -MemberType NoteProperty -Name version -Value $domain.version | Out-Null
        }
        if ($domainsLicensesMap.$name)
        {
            $d | Add-Member -MemberType NoteProperty -Name nbLicenses -Value $domainsLicensesMap.$name.nbLicenses | Out-Null
            $d | Add-Member -MemberType NoteProperty -Name licenses -Value $domainsLicensesMap.$name.licenses | Out-Null
        }
        else {
            $d | Add-Member -MemberType NoteProperty -Name nbLicenses -Value 0 | Out-Null
        }
        $domainArray.Add($d) | Out-Null
}
$result | Add-Member -MemberType NoteProperty -Name domains -Value $domainArray | Out-Null
if ($domainsLicensesMap.$unsetDomain)
{
    $result | Add-Member -MemberType NoteProperty -Name nbUnusedLicenses -Value $domainsLicensesMap.$unsetDomain.nbLicenses | Out-Null
    $result | Add-Member -MemberType NoteProperty -Name unusedLicenses -Value $domainsLicensesMap.$unsetDomain.licenses | Out-Null
}
else {
    $result | Add-Member -MemberType NoteProperty -Name nbUnusedLicenses -Value 0 | Out-Null
}
LogWrite($result | ConvertTo-Json -Depth 5)
$result 
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU+71fZSKsJ2IZBuObC5ac9aQR
# XcagggP3MIID8zCCAtugAwIBAgIQJzAOpCsXRaZBggO0ElA95zANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDYyNTE0Mzg0MFoXDTIyMDYyNTE0NTg0MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALF+uOga
# IaW41f6uzuOE2vvJLV+am8SZaD6OQZYCy9s8v/iFGC2r5oUzcYIZ6KpktbTYgET2
# a+m6IaMsU+S6uM/PHML3RVcY8oucFulyvaeewR2iRjnmWB+nWLWPmwdcN9yGgooH
# YcWcn1eQM2LNl/d49yhakmgGUB5vT0KtKu8aaIJ8JBSxacmKGj+8EgnEBL51qIsp
# SNq73cMIQBTw8/ABPmIIZnxTXBrI+FbGgtwf7x6liwLVmAnWa+cLR9tuvd4F+DEH
# 6DjNTwrA8Nwf+iUZQPJFpMuYN+yEMWuXNGWuWxmNx/xY9q2Cb75O7Fc+zekLiKkv
# UnrL5+ch/Mgz02UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRFjyhs3nJq3Ohjqpq4IccsXX8P2jANBgkqhkiG9w0BAQsFAAOCAQEAOU5c
# jdTLoGA+qs2VoPmnNfjb0MC3dbo9+li6mdgp+UJRV/7jW+tvKOItt/NUK+ycxYRL
# 9bDiqQnGGjxcNh+wwKdQxUZZQGASl+sh/PslLSaf/WVJH7gpO/oy6fsMgn15fY3z
# S6xlxo4uYq1kx2+0uXkP7Kkf4yFEWZMtDFwazUsenhfHnMzBPx5I6IFZVi0yoiHd
# /p/EIpbGmqtVGqKmgpVyuf/sEplvSmIMnOEtHyKQE1wW7sOysK0KXJVeboS3ixyH
# IuygOQUCopLedfw37VdIsfQ/K6VljYxHbiF4l4N7Fu9SkHOYVpmfyu/tG7F/vPH7
# 3ExUnpV5PUH5xEAxszGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECcwDqQrF0WmQYIDtBJQPecwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFEtar29bUvPxGJYQQLficIhm7raxMA0GCSqGSIb3DQEBAQUABIIBAJPE+Pd5
# Tyd9lI1w+XT97GHj68h814VvPZK2Tckpj7LY/wUkWTWZ6Q4SGueviqB6lZgWa1Md
# mUVxgS3Irmzp+5qG91hw+qFvM6pBoBJKRXb5lBK2Juf9rTYdPc5XEuCv4QjekKzU
# 5nfnkmXhyyqz+COyB3O+f04eSpNlHt2snryFX7SL9s1P5CBP0tz1rsDUdZDG+m8U
# yK+o6w2u6jGxlnw81hAfUxKDGynNUwCJP5PMNmG04cHt6fMc81vJ9yfVCwcj701P
# mrR3Cw8/sMdMMq5paDmOir/+qOlEZ7Md+BlEykh13bqRuw4XDKM1UIJYbEB+Z3gK
# hAcOVszbvTK0rbM=
# SIG # End signature block
