# Load utilities
Function Get-PncVersion {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve its version.
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve its version.
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The string version.
.EXAMPLE
Get-PncVersion -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION:1.10.10
#>
[CmdletBinding()] 
param(

    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
        [string] $UrlPort,
        [string] $UrlLogin,
        [string] $UrlPassword,
    [string] $LogFile
)

$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"

$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve the Plugncast version for server `"$server`"")


$Body = @{
    target = "nsIPref.getCharPref"
    args = @("extensions.lastAppVersion")
}
$JsonBody = $Body | ConvertTo-Json

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}

$VersionObject = $ExecutedRequest | ConvertFrom-Json


LogWrite($VersionObject | ConvertTo-Json -Depth 5)
$VersionObject
}

# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU+R3+b+SHmCMQbRUxmyScWmSw
# JQKgggP3MIID8zCCAtugAwIBAgIQJzAOpCsXRaZBggO0ElA95zANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDYyNTE0Mzg0MFoXDTIyMDYyNTE0NTg0MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALF+uOga
# IaW41f6uzuOE2vvJLV+am8SZaD6OQZYCy9s8v/iFGC2r5oUzcYIZ6KpktbTYgET2
# a+m6IaMsU+S6uM/PHML3RVcY8oucFulyvaeewR2iRjnmWB+nWLWPmwdcN9yGgooH
# YcWcn1eQM2LNl/d49yhakmgGUB5vT0KtKu8aaIJ8JBSxacmKGj+8EgnEBL51qIsp
# SNq73cMIQBTw8/ABPmIIZnxTXBrI+FbGgtwf7x6liwLVmAnWa+cLR9tuvd4F+DEH
# 6DjNTwrA8Nwf+iUZQPJFpMuYN+yEMWuXNGWuWxmNx/xY9q2Cb75O7Fc+zekLiKkv
# UnrL5+ch/Mgz02UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRFjyhs3nJq3Ohjqpq4IccsXX8P2jANBgkqhkiG9w0BAQsFAAOCAQEAOU5c
# jdTLoGA+qs2VoPmnNfjb0MC3dbo9+li6mdgp+UJRV/7jW+tvKOItt/NUK+ycxYRL
# 9bDiqQnGGjxcNh+wwKdQxUZZQGASl+sh/PslLSaf/WVJH7gpO/oy6fsMgn15fY3z
# S6xlxo4uYq1kx2+0uXkP7Kkf4yFEWZMtDFwazUsenhfHnMzBPx5I6IFZVi0yoiHd
# /p/EIpbGmqtVGqKmgpVyuf/sEplvSmIMnOEtHyKQE1wW7sOysK0KXJVeboS3ixyH
# IuygOQUCopLedfw37VdIsfQ/K6VljYxHbiF4l4N7Fu9SkHOYVpmfyu/tG7F/vPH7
# 3ExUnpV5PUH5xEAxszGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECcwDqQrF0WmQYIDtBJQPecwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFPWFmIj88Uhjfd4joMKYU/QCLkFtMA0GCSqGSIb3DQEBAQUABIIBAHrGX3nJ
# laOnmlPeJ1VH9T2PReoWFzWNxwJv7InJCyaQ/5KtzQ7iC/j4rEi4HbF/0dlABfl2
# zwTtXfOfIIiYof/b2RabgfYd3UnzcLmIhlgvDUCWAfakfxb5rnDysO44HQol7Nmi
# Le6XV34igmbMEh7PwUHJJ+RGF7dkmAnXipXTdA6VopNVTgQoIQZkgioE741TLILj
# zgwFxNCx7BE8nlI1+472I9mKZsllzz8qzKZ2y7juP9SHjmMlDtrEFt+e4XjX1wo2
# FJ9H3zJoWSDZ+AOyQbzaCBe0fM206FiBfqOfxGkdSNwOULhh/OFhtn+urc9+eb65
# Gg0bwqCbc3r8EpA=
# SIG # End signature block
