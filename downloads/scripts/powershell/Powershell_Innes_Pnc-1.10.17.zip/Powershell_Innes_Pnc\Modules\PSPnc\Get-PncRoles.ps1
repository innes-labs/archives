Function Get-PncRoles {
<#
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the Plugncast server roles.
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the Plugncast server roles.
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell object describing the roles.
Example of object formated in JSON :
{
    "editor":  {
                   "label":  "editor",
                   "builtin":  true,
                   "permissions":  {
                                       "cms.playouts.layout.grids.create":  "permit",
                                       "cms.library.domainrepository.fonts.edit":  "permit",
                                       "cms.targetgroups.remove":  "permit",
                                       "cms.targetgroups.create":  "permit",
                                       "cms.settings.licenses.view":  "not_applicable",
                                       "cms.playouts.layout.grids.rename":  "permit",
                                       "cms.targets.digitalsignage.system.software.publish":  "not_applicable",
                                       "cms.targets.digitalsignage.tasks.reboot.edit":  "permit",
                                       "cms.targets.digitalsignage.system.clean":  "permit",
                                    ...
                                   }
               },
    "super-administrator":  {
                                "label":  "super-administrator",
                                "builtin":  true,
                                "permissions":  {
                                                    "cms.playouts.layout.grids.create":  "permit",
                                                    "cms.library.domainrepository.fonts.edit":  "permit",
                                                    "cms.targetgroups.remove":  "permit",
                                                    "cms.targetgroups.create":  "permit",
                                                    "cms.settings.licenses.view":  "permit",
                                                    "cms.playouts.layout.grids.rename":  "permit",
                                                    "cms.targets.digitalsignage.system.software.publish":  "permit",
                                                    ...
                                                }
                            },
    "help-desk":  {
                      "label":  "help-desk",
                      "builtin":  true,
                      "permissions":  {
                                          "cms.playouts.layout.grids.create":  "not_applicable",
                                          "cms.library.domainrepository.fonts.edit":  "not_applicable",
                                          "cms.targetgroups.remove":  "not_applicable",
                                          "cms.targetgroups.create":  "not_applicable",
                                          "cms.settings.licenses.view":  "not_applicable",
                                          "cms.playouts.layout.grids.rename":  "not_applicable",
                                          "cms.targets.digitalsignage.system.software.publish":  "not_applicable",
                                          "cms.targets.digitalsignage.tasks.reboot.edit":  "not_applicable",
                                          "cms.targets.digitalsignage.system.clean":  "permit",
                                          "cms.settings.devices.scripts.remove":  "not_applicable",
                                          "cms.playouts.layout.grids.remove":  "not_applicable",
                                          "cms.targets.digitalsignage.publication.clean":  "not_applicable",
                                          "cms.library.domainrepository.models.view":  "permit",
                                          "cms.library.sharedrepository.files.create":  "not_applicable",
                                          "cms.playouts.rename":  "not_applicable",
                                          ...
                                      }
                  },
    "contributor":  {
                        "label":  "contributor",
                        "builtin":  true,
                        "permissions":  {
                                            "cms.playouts.layout.grids.create":  "not_applicable",
                                            "cms.library.domainrepository.fonts.edit":  "not_applicable",
                                            "cms.targetgroups.remove":  "not_applicable",
                                            "cms.targetgroups.create":  "not_applicable",
                                            "cms.settings.licenses.view":  "not_applicable",
                                            "cms.playouts.layout.grids.rename":  "not_applicable",
                                            "cms.targets.digitalsignage.system.software.publish":  "not_applicable",
                                            "cms.targets.digitalsignage.tasks.reboot.edit":  "not_applicable",
                                            "...
                                        }
                    },
    "administrator":  {
                          "label":  "administrator",
                          "builtin":  true,
                          "permissions":  {
                                              "cms.playouts.layout.grids.create":  "permit",
                                              "cms.library.domainrepository.fonts.edit":  "permit",
                                              "cms.targetgroups.remove":  "permit",
                                              "cms.targetgroups.create":  "permit",
                                              "cms.settings.licenses.view":  "permit",
                                              "cms.playouts.layout.grids.rename":  "permit",
                                              ...
                                          }
                      },
    "domain-editor":  {
                          "label":  "domain-editor",
                          "builtin":  true,
                          "permissions":  {
                                              "cms.playouts.layout.grids.create":  "permit",
                                              "cms.library.domainrepository.fonts.edit":  "permit",
                                              "cms.targetgroups.remove":  "permit",
                                              "cms.targetgroups.create":  "permit",
                                              "cms.settings.licenses.view":  "not_applicable",
                                              "cms.playouts.layout.grids.rename":  "permit",
                                              ...
                                          }
                      },
     ...
}
.EXAMPLE
Get-PncRoles -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION: 1.10.10
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost = $(throw "Please enter the Plugncast G3 host (IP or DNS domain"),
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"

# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name
$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve the Plugncast roles for server `"$server`"")

$Body = @{
    target = "nsIAppliRoles.list"
}
$JsonBody = $Body | ConvertTo-Json
Start-Sleep -m $SleepDurationBeforeCommand

try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}

$RolesObject = $ExecutedRequest | ConvertFrom-Json


LogWrite($rolesObject | ConvertTo-Json -Depth 5)
$rolesObject

}


# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUutwp4lYs6VDVkuNu6tvS2fJF
# ppagggP3MIID8zCCAtugAwIBAgIQJzAOpCsXRaZBggO0ElA95zANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDYyNTE0Mzg0MFoXDTIyMDYyNTE0NTg0MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALF+uOga
# IaW41f6uzuOE2vvJLV+am8SZaD6OQZYCy9s8v/iFGC2r5oUzcYIZ6KpktbTYgET2
# a+m6IaMsU+S6uM/PHML3RVcY8oucFulyvaeewR2iRjnmWB+nWLWPmwdcN9yGgooH
# YcWcn1eQM2LNl/d49yhakmgGUB5vT0KtKu8aaIJ8JBSxacmKGj+8EgnEBL51qIsp
# SNq73cMIQBTw8/ABPmIIZnxTXBrI+FbGgtwf7x6liwLVmAnWa+cLR9tuvd4F+DEH
# 6DjNTwrA8Nwf+iUZQPJFpMuYN+yEMWuXNGWuWxmNx/xY9q2Cb75O7Fc+zekLiKkv
# UnrL5+ch/Mgz02UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRFjyhs3nJq3Ohjqpq4IccsXX8P2jANBgkqhkiG9w0BAQsFAAOCAQEAOU5c
# jdTLoGA+qs2VoPmnNfjb0MC3dbo9+li6mdgp+UJRV/7jW+tvKOItt/NUK+ycxYRL
# 9bDiqQnGGjxcNh+wwKdQxUZZQGASl+sh/PslLSaf/WVJH7gpO/oy6fsMgn15fY3z
# S6xlxo4uYq1kx2+0uXkP7Kkf4yFEWZMtDFwazUsenhfHnMzBPx5I6IFZVi0yoiHd
# /p/EIpbGmqtVGqKmgpVyuf/sEplvSmIMnOEtHyKQE1wW7sOysK0KXJVeboS3ixyH
# IuygOQUCopLedfw37VdIsfQ/K6VljYxHbiF4l4N7Fu9SkHOYVpmfyu/tG7F/vPH7
# 3ExUnpV5PUH5xEAxszGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECcwDqQrF0WmQYIDtBJQPecwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFLPujf6xCx0DYBz3jWQJmPdSOsrSMA0GCSqGSIb3DQEBAQUABIIBAFfZWxg+
# dGpJFe8AxdFkofItIj7onys1c2+rhTT43DdPA4bVEzEFK+x6gPX48QAxukpdjI3M
# X7e/RI399XONIm+pnh/nidFMwNmC/n8KXUAmvMK8y86SBdLFkDcZM5DsIdN+IrdA
# ZONuR6K880U7cxC8svYK19UQm4667R9E+XNADSRNNp4LTjpCzMcjV1dBYzwiYrv+
# 5Ts94LOOvx1qUSdf3aUucbirRln/nzVYDM4OuFfiIOZ8HSQ3A5/mgfdt4KpreNlp
# pWBVQTQh8bSJkpoqNixn2mhZ05BoC1ZQjW8Z5FLdBPSvvj30jvzkxRYnyl5YKwTg
# Vx2GzqrU4TrEKMU=
# SIG # End signature block
