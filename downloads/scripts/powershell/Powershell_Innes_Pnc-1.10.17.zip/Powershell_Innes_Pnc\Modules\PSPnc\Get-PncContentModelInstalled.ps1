Function Get-PncContentModelInstalled {
<# 
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve the installed models
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve the installed models
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER domainList
The list of domains involved in the installation. Use "all" for all domains (default)
.PARAMETER lang
The description language of the model ("en-US", "fr-FR", ...). "x-default" by default
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell array of installed models.
Example of object formated in JSON :
[
    {
        "domain":  "domain1"
        "models":  [
            {
               "title":  "title 1",
               "version":  "1.20.10",
               "format":  "16/9",
               "description":  "Description 1",
               "category":  "Category 1",
               "file":  "model1.mask.maff"
            }
        ],
    },
    {
        "domain":  "domain2"
        "models":  [
            {
                 "title":  "title 2",
                "version":  "1.10.12",
                 "format":  "16/9",
                 "description":  "Description 2",
                 "category":  "Category 2",
                 "file":  "model2.mask.maff"
             },
             ...
        ],
    }
]
.EXAMPLE
Get-PncContentModelInstalled -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
Retrieve all models installed
.EXAMPLE
Get-PncContentModelInstalled -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin -domainList domain1
Retrieve models installed on domain "domain1"
.NOTES
VERSION:1.10.10
#>

[CmdletBinding()] 
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost,
    [string] $UrlPort,
    [string[]] $domainList = "all",
    [string] $lang = "x-default",
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"
$ServerUri = "https://$Server"

# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve models for server `"$server`"")

 
# List of domains
$configObject = Get-PncDomainsAndTargets $server -logFile "none" -UrlLogin $UrlLogin -UrlPassword $UrlPassword
function GetModels {
    param (
        [string] $domain
    )
    $Body = "<D:propfind xmlns:D=`"DAV:`" xmlns:ias=`"ns.innes.appli.server`"><D:prop><D:getcontenttype/></D:prop><D:prop><D:getcontentlength/></D:prop><D:prop><D:getlastmodified/></D:prop><D:prop><D:getetag/></D:prop><D:prop><D:id/></D:prop><D:prop><D:resourcetype/></D:prop><D:prop><D:owner/></D:prop><D:prop><D:current-user-privilege-set/></D:prop><D:prop><ias:hidden-resources/></D:prop></D:propfind>"
    $Headers = @{
        DEPTH = "1"
        "X-HTTP-METHOD-OVERRIDE" = "PROPFIND"
    }
    Start-Sleep -m $SleepDurationBeforeCommand
    $BaseUri = "/.plugncast/.domains/" + $domain
    try {
        $Uri = $ServerUri + $BaseUri + "/.domain-repository/.models/.medias/"
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'text/xml' -Uri $Uri   -Body $Body -Headers $Headers
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw $_.Exception
    }
    [xml]$result = [xml]$ExecutedRequest
    [System.Xml.XmlElement] $root = $result.get_DocumentElement()
    [System.Collections.ArrayList]$uris =@();
    foreach ($response in $root.ChildNodes) {
        foreach ($child in $response.ChildNodes) {
            $name = $child.ToString()
            $value = $child.InnerText
            if ($name -eq "href")
            {
                if ($value.EndsWith(".mask.maff") -or $value.EndsWith(".mask.uri"))
                {
                    $value = $value.Substring($BaseUri.Length+1);
                    $uris.Add($value) | Out-Null
                }
            }
        }
    }
    $Body = "declare namespace im = `"ns.innes.metadata`";im:getDescriptions(("
    for ($i = 0; $i -lt $uris.Count; $i++)
    {
        $Body += "`"" + $uris[$i] + "`""
        if ($i -ne $uris.Count -1)
        {
            $Body += ","
        }
    }
    $Body += "))"
    try {
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/xquery' -Uri $BaseServerUri".domains/"$domain"/.db/metadatadb"   -Body $Body
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
        throw $_.Exception
    }
    $enc = [System.Text.Encoding]::UTF8
    $bytes = $enc.GetBytes($ExecutedRequest.Content)
    $content = $enc.GetString($bytes)
    [xml]$result = [xml]$content
    [System.Xml.XmlElement] $root = $result.get_DocumentElement()

    [PSCustomObject]$Namespace = @{rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
     xmp="http://ns.adobe.com/xap/1.0/"
     xmpMM="http://ns.adobe.com/xap/1.0/mm/"
      stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#"
      xmpGImg="http://ns.adobe.com/xap/1.0/g/img/"
      dc="http://purl.org/dc/elements/1.1/"
      Iptc4xmpExt="http://iptc.org/std/Iptc4xmpExt/2008-02-29/"
      im="ns.innes.metadata"
      xml="http://www.w3.org/XML/1998/namespace"
      xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/"}
    $ns = New-Object System.Xml.XmlNamespaceManager($result.NameTable)
    foreach ($key in $Namespace.keys) {
        $ns.AddNamespace($key, $Namespace[$key])
    }
    [System.Collections.ArrayList]$models =@()
    foreach ($child in $root.ChildNodes) {
        $file = $child.about
        $index = $file.LastIndexOf("/");
        $file = $file.Substring($index + 1);
        $category = ""
        $title = ""
        $description = ""
        $format = ""
        $version = ""
        $metadata = $child.EmbeddedMetadata
        if ($metadata) {
            $version = $metadata.VersionID
            $res = $metadata.SelectSingleNode("im:category//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
            if ($res) {
                $category = $res.InnerText
            }
            $res = $metadata.SelectSingleNode("dc:title//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
            if ($res) {
                $title = $res.InnerText
            }
            $res = $metadata.SelectSingleNode("dc:description//rdf:Alt/rdf:li[@xml:lang='$lang']", $ns);
            if ($res) {
                $description = $res.InnerText
            }
            if ($metadata.videoDisplayAspectRatioCategory) {
                $format = $metadata.videoDisplayAspectRatioCategory
            }
        }
        $metadatas = @{
            file = $file
            version     = $version
            format      = $format
            category    = $category
            title       = $title
            description = $description
        }
        $models.Add($metadatas) | Out-Null
    }
    return ,$models
}
[System.Collections.ArrayList]$domainModels =@()
foreach ($domain in $configObject.domains) {
    if (($domainList -eq "all") -or ($domainList -contains $domain.Name)) {
        $models = GetModels $domain.Name
        if ($models.Count -ne 0)
        {
            [PSCustomObject]$obj = @{
                domain = $domain.Name
                models = $models
            }
            $domainModels.Add($obj) | Out-Null
        }
    }
}
LogWrite(,$domainModels | ConvertTo-Json -Depth 5)
,$domainModels
}






# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU81JFoBrn30s6w2lqhbd8qWWP
# MSOgggP3MIID8zCCAtugAwIBAgIQJzAOpCsXRaZBggO0ElA95zANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDYyNTE0Mzg0MFoXDTIyMDYyNTE0NTg0MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALF+uOga
# IaW41f6uzuOE2vvJLV+am8SZaD6OQZYCy9s8v/iFGC2r5oUzcYIZ6KpktbTYgET2
# a+m6IaMsU+S6uM/PHML3RVcY8oucFulyvaeewR2iRjnmWB+nWLWPmwdcN9yGgooH
# YcWcn1eQM2LNl/d49yhakmgGUB5vT0KtKu8aaIJ8JBSxacmKGj+8EgnEBL51qIsp
# SNq73cMIQBTw8/ABPmIIZnxTXBrI+FbGgtwf7x6liwLVmAnWa+cLR9tuvd4F+DEH
# 6DjNTwrA8Nwf+iUZQPJFpMuYN+yEMWuXNGWuWxmNx/xY9q2Cb75O7Fc+zekLiKkv
# UnrL5+ch/Mgz02UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRFjyhs3nJq3Ohjqpq4IccsXX8P2jANBgkqhkiG9w0BAQsFAAOCAQEAOU5c
# jdTLoGA+qs2VoPmnNfjb0MC3dbo9+li6mdgp+UJRV/7jW+tvKOItt/NUK+ycxYRL
# 9bDiqQnGGjxcNh+wwKdQxUZZQGASl+sh/PslLSaf/WVJH7gpO/oy6fsMgn15fY3z
# S6xlxo4uYq1kx2+0uXkP7Kkf4yFEWZMtDFwazUsenhfHnMzBPx5I6IFZVi0yoiHd
# /p/EIpbGmqtVGqKmgpVyuf/sEplvSmIMnOEtHyKQE1wW7sOysK0KXJVeboS3ixyH
# IuygOQUCopLedfw37VdIsfQ/K6VljYxHbiF4l4N7Fu9SkHOYVpmfyu/tG7F/vPH7
# 3ExUnpV5PUH5xEAxszGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECcwDqQrF0WmQYIDtBJQPecwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFANLZhUF4e1boGESXfPXg6W8j/CaMA0GCSqGSIb3DQEBAQUABIIBAGqb9cfM
# evFp/ZibNxfAK2wXD0Pi9DEayi6lex3iaODGpUp7s8o5iittyA7hPiybS+XUNIUB
# tUP4ZaS47BjgwBNDFrl5iY6CnHATcSLCUyOP374TnrfkuMFWMV452HFYtrlRdCQd
# 8/G2m+oQQmH2I2XIjSnm03/k6fdncHZF38pm9Nk71KEtIoE5sm/yVuIkskFpRjTc
# pEK25AELEgP261Tv293Utc2cmo1zt1ZUDA8RIwJIfKJ1ddDsbgVjuXxaEKvoZd7G
# UJix8RMGpfvK466iLTnpUTJYhFw7qslNJk/JKeOOPuh2iVd4bTKW8djuJMV9pYae
# bvKQ5DVlrmTi3hM=
# SIG # End signature block
