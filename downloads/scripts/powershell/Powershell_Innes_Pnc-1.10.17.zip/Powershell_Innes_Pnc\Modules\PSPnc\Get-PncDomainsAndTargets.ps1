Function Get-PncDomainsAndTargets {
<#
.SYNOPSIS
This function queries a Plugncast G3 server to retrieve domains and targets of each domain.
.DESCRIPTION
This function queries a Plugncast G3 server to retrieve domains and targets of each domain.
.PARAMETER urlHost
The Plugncast G3 server host (IP or DNS domain)
.PARAMETER urlPort
The  Plugncast G3 server port (empty by default)
.PARAMETER urlLogin
The login of authentication if the certificate is not used
.PARAMETER urlPassword
The password of authentication if the certificate is not used
.PARAMETER logFile
The path of log file
.OUTPUTS
The powershell object describing the domains and its targets
Example of object formated in JSON :
{
     "numberDomain":  1,
     "numberTarget":  2,
     "domains":  [
         {
             "Name":  "domain1",
             "numberTarget":  2,
             "targets":  [
                 {
                     "label":  "target 1",
                     "targetId":  "30-9c-23-1e-d8-1b",
                     "modelFamily":  "nt_iaxx-1",
                     "middlewareFamily":  "gekkota-4",
                     "targetIdType":  "mac",
                      "info":  {
                          "date-status":  "2019-05-15T09:18:26.598Z",
                          "mac":  "30-9c-23-1e-d8-1b",
                          "hostname":  "innes-sw36",
                          "uuid":  "00000000-0000-0000-0001-309c231ed81b",
                          "modelName":  "nt_ia32",
                          "modelNumber":  "4.10.10",
                          "serialNumber":  "",
                              "middleware":  "gekkota-4",
                           "ip-addresses":  [
                                {
                                    "origin":  "auto",
                                        "value":  "fc00::d47a:b234:cee4:1a3/64",
                                    "if-type":  "LAN"
                                },
                                ...
                           ]
                     }
                 }
                 ...
             ]
         }
          ...
}
.EXAMPLE
Get-PncDomainsAndTargets -urlHost 192.168.1.186 -urlLogin superadmin -urlPassword superadmin
.NOTES
VERSION: 1.10.10
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string] $UrlHost = $(throw "Please enter the Plugncast G3 host (IP or DNS domain"),
    [string] $UrlPort,
    [string] $UrlLogin,
    [string] $UrlPassword,
    [string] $LogFile
)

$SleepDurationBeforeCommand = 100
$Server=$urlHost
if ($urlPort) {
   $Server += ":" + $urlPort
}
$BaseServerUri = "https://$Server/.plugncast/"

# Load utilities
$ScriptName=$MyInvocation.MyCommand.Name

$date = Get-Date
LogWrite("$date - $ScriptName")
LogWrite("Retrieve configuration for Plugncast G3 server `"$server`"")

 
 

# Configuration object
$configObject = [PSCustomObject]@{
    numberDomain = 0;
    numberTarget = 0;
}
[System.Collections.ArrayList]$domainsArray = @()

# List domain Ids
$Body = @{
    target = "nsIAppliDomains.listIds"
}
$JsonBody = $Body | ConvertTo-Json
Start-Sleep -m $SleepDurationBeforeCommand

function Storage {
    param (
        [string] $total,
        [string] $used
    )
    $t = [int64]$total
    $u = [int64]$used

    switch ($t) {
        { $_ -gt 1tb } 
        { "{0:n2}/{1:n2} Tio" -f ($u/1tb),($_ / 1tb); break }
        { $_ -gt 1gb } 
        { "{0:n2}/{1:n2} Gio" -f ($u/1gb),($_ / 1gb); break }
        { $_ -gt 1mb } 
        { "{0:n2}/{1:n2} Mio" -f ($u/1mb),($_ / 1mb); break }
        { $_ -gt 1kb } 
        { "{0:n2}/{1:n2} Kio" -f ($u/1kb),($_ / 1kb); break }
        default  
        { "{0}/{1} o" -f $u,$_; break }
    }      

}
function RetrieveStatus {
    param (
        [System.Xml.XmlElement] $status,
        [PSCustomObject] $info
    )
    foreach ($child in $status.ChildNodes) {
        $name = $child.ToString()
        $value = $child.InnerText
        if ($name -eq "date-status" ) {
            $info | Add-Member -MemberType NoteProperty -Name $name -Value $value | Out-Null
        }
        elseif ($name -eq "device-status" ) {
            $device = $child.device;
            $info |  Add-Member -MemberType NoteProperty -Name "mac" -Value $device.mac | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "hostname" -Value $device.hostname | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "uuid" -Value $device.uuid | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "modelName" -Value $device.modelName | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "modelNumber" -Value $device.modelNumber | Out-Null
            $info |  Add-Member -MemberType NoteProperty -Name "serialNumber" -Value $device.serialNumber | Out-Null
            if ($device.middleware) {
                $info |  Add-Member -MemberType NoteProperty -Name "middleware" -Value $device.middleware | Out-Null
            }
            else {
                $info |  Add-Member -MemberType NoteProperty -Name "middleware" -Value "" | Out-Null
            }
            [System.Collections.ArrayList]$ips = @()
            $ip_addresses = $device."ip-addresses"
            foreach ($ip in $ip_addresses.ChildNodes) {
                $ips.Add(@{
                    "if-type" = $ip."if-type"
                    origin = $ip.origin
                    value = $ip.value
                }) | Out-Null
            }
            $info | Add-Member -MemberType NoteProperty -Name "ip-addresses" -Value $ips | Out-Null
            $status = $child.status
            $storage = $status.storage
            $str = Storage $storage.total.InnerText $storage.used.InnerText
            $info |  Add-Member -MemberType NoteProperty -Name "storage" -Value $str | Out-Null
            $launcher = $status.launcher
            $info |  Add-Member -MemberType NoteProperty -Name "state" -Value $launcher.state | Out-Null
            $powermanager = $launcher."power-manager"
            if ($powermanager)
            {
                $level = $powermanager.level
                $info |  Add-Member -MemberType NoteProperty -Name "power-manager-level" -Value $powermanager.level | Out-Null
            }

        }
        
    }
    
}
try {
    $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri   -Body $JsonBody
}
catch {
    LogWrite( $_.Exception.Message + $_.ErrorDetails.Message )
    throw "Exception during request"
}
$DomainsJson = $ExecutedRequest | ConvertFrom-Json
$configObject.numberDomain = $DomainsJson.Length
foreach ($domain in $DomainsJson) {
    $domainObject = [PSCustomObject]@{
        Name = $domain
    }
    [System.Collections.ArrayList]$targetsArray = @()
    $Body = "declare namespace targets = `"ns.innes.plugncast.cms.targets`";targets:getAll()"
    try {
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/xquery' -Uri $BaseServerUri".domains/"$domain"/.db/cmsdb"   -Body $Body
        [xml]$result = [xml]$ExecutedRequest
        [System.Xml.XmlElement] $root = $result.get_DocumentElement()
        foreach ($targetNode in $root.ChildNodes) {
            $target = @{}
            foreach ($child in $targetNode.ChildNodes) {
                $name = $child.ToString()
                $value = $child.InnerText
                if ($name -eq "modelFamily" ) {
                    $target.Add("modelFamily", $value) | Out-Null
                }
                elseif ($name -eq "targetIdType" ) {
                    $target.Add("targetIdType", $value) | Out-Null
                }
                elseif ($name -eq "targetId" ) {
                    $target.Add("targetId", $value) | Out-Null
                }     
                elseif ($name -eq "label" ) {
                    $target.Add("label", $value) | Out-Null
                }      
                elseif ($name -eq "middlewareFamily" ) {
                    $target.Add("middlewareFamily", $value) | Out-Null
                }      
            }
            if ($target.Count -ne 0)
            {
                $targetsArray.Add([PSCustomObject]$target) | Out-Null
                $configObject.numberTarget++
            }
        }
        $domainObject | Add-Member -MemberType NoteProperty -Name numberTarget -Value $targetsArray.Count | Out-Null
        if ($targetsArray.Count -gt 0)
        {
            $domainObject | Add-Member -MemberType NoteProperty -Name targets -Value $targetsArray | Out-Null
        }
        

    }
    catch {
        LogWrite( "Exception during request" )
        LogWrite( ($_.Exception).ToString().Trim() )
        LogWrite( ($_.Exception.Message).ToString().Trim() )
        throw "Exception during request"
    } 
    $Body = "declare namespace pncf = `"ns.innes.plugncast.frontals`";pncf:getRegisteredDevicesWithStatus()"
    try {
        $ExecutedRequest =  MakeRequest -Method 'POST' -ContentType 'application/xquery' -Uri $BaseServerUri".domains/"$domain"/.db/frontalsdb"   -Body $Body
        [xml]$result = [xml]$ExecutedRequest
        #$str = WriteXml $result
        [System.Xml.XmlElement] $root = $result.get_DocumentElement()

        foreach ($target in $root.ChildNodes) {
            $targetInfo = [PSCustomObject]@{}
            $id = $null
            foreach ($child in $target.ChildNodes) {
                $name = $child.ToString()
                $value = $child.InnerText
                if ($name -eq "id") {
                    $id = $value
                }
                elseif ($name -eq "phantom") {
                    $targetInfo | Add-Member -MemberType NoteProperty -Name $name -Value $value | Out-Null
                }
                elseif ($name -eq "registered") {
                    $targetInfo | Add-Member -MemberType NoteProperty -Name $name -Value $value | Out-Null
                }
                elseif ($name -eq "status") {
                    RetrieveStatus $child $targetInfo
                }
            }
            foreach ($target in $targetsArray) {
                if ($target.targetId -eq $id)
                {
                    if (!$target.info) {
                        $target | Add-Member -MemberType NoteProperty -Name info -Value $targetInfo | Out-Null
                    }
                }
            }
        }
    }
    catch {
        LogWrite( "Exception during request" )
        LogWrite( ($_.Exception).ToString().Trim() )
        LogWrite( ($_.Exception.Message).ToString().Trim() )
        throw "Exception during request"
    } 
    $domainsArray.Add($domainObject) | Out-Null
}
$configObject | Add-Member -MemberType NoteProperty -Name domains -Value $domainsArray | Out-Null
LogWrite($configObject | ConvertTo-Json -Depth 10)
$configObject
}



# SIG # Begin signature block
# MIIGxwYJKoZIhvcNAQcCoIIGuDCCBrQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUqh2/Ukko+z/MymZTqLBDIDyi
# LWugggP3MIID8zCCAtugAwIBAgIQJzAOpCsXRaZBggO0ElA95zANBgkqhkiG9w0B
# AQsFADCBgzELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkZyYW5jZTEPMA0GA1UEBwwG
# UmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4GCSqGSIb3DQEJARYRc3VwcG9ydEBp
# bm5lcy5wcm8xIDAeBgNVBAMMF0lubmVzIENvZGUgU2lnbmluZyBSb290MB4XDTIx
# MDYyNTE0Mzg0MFoXDTIyMDYyNTE0NTg0MFowfjELMAkGA1UEBhMCRlIxDzANBgNV
# BAgMBkZyYW5jZTEPMA0GA1UEBwwGUmVubmVzMQ4wDAYDVQQKDAVJTk5FUzEgMB4G
# CSqGSIb3DQEJARYRc3VwcG9ydEBpbm5lcy5wcm8xGzAZBgNVBAMMEklubmVzIENv
# ZGUgU2lnbmluZzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALF+uOga
# IaW41f6uzuOE2vvJLV+am8SZaD6OQZYCy9s8v/iFGC2r5oUzcYIZ6KpktbTYgET2
# a+m6IaMsU+S6uM/PHML3RVcY8oucFulyvaeewR2iRjnmWB+nWLWPmwdcN9yGgooH
# YcWcn1eQM2LNl/d49yhakmgGUB5vT0KtKu8aaIJ8JBSxacmKGj+8EgnEBL51qIsp
# SNq73cMIQBTw8/ABPmIIZnxTXBrI+FbGgtwf7x6liwLVmAnWa+cLR9tuvd4F+DEH
# 6DjNTwrA8Nwf+iUZQPJFpMuYN+yEMWuXNGWuWxmNx/xY9q2Cb75O7Fc+zekLiKkv
# UnrL5+ch/Mgz02UCAwEAAaNnMGUwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFOhub3mcy4lalttahOCukRizaKBjMB0GA1Ud
# DgQWBBRFjyhs3nJq3Ohjqpq4IccsXX8P2jANBgkqhkiG9w0BAQsFAAOCAQEAOU5c
# jdTLoGA+qs2VoPmnNfjb0MC3dbo9+li6mdgp+UJRV/7jW+tvKOItt/NUK+ycxYRL
# 9bDiqQnGGjxcNh+wwKdQxUZZQGASl+sh/PslLSaf/WVJH7gpO/oy6fsMgn15fY3z
# S6xlxo4uYq1kx2+0uXkP7Kkf4yFEWZMtDFwazUsenhfHnMzBPx5I6IFZVi0yoiHd
# /p/EIpbGmqtVGqKmgpVyuf/sEplvSmIMnOEtHyKQE1wW7sOysK0KXJVeboS3ixyH
# IuygOQUCopLedfw37VdIsfQ/K6VljYxHbiF4l4N7Fu9SkHOYVpmfyu/tG7F/vPH7
# 3ExUnpV5PUH5xEAxszGCAjowggI2AgEBMIGYMIGDMQswCQYDVQQGEwJGUjEPMA0G
# A1UECAwGRnJhbmNlMQ8wDQYDVQQHDAZSZW5uZXMxDjAMBgNVBAoMBUlOTkVTMSAw
# HgYJKoZIhvcNAQkBFhFzdXBwb3J0QGlubmVzLnBybzEgMB4GA1UEAwwXSW5uZXMg
# Q29kZSBTaWduaW5nIFJvb3QCECcwDqQrF0WmQYIDtBJQPecwCQYFKw4DAhoFAKB4
# MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkE
# MRYEFFZNTUpFm2pQd4XWa3RicNkynwdWMA0GCSqGSIb3DQEBAQUABIIBAI8rRtEy
# Akzu5QU9wD+zZfmlSXeMejChrAiXuCbbGKgC2+JAkFe1IhFGsvTVCc30gPw768w3
# 4rBOtROXBBuunT/aDjK6hcJKdgRUyF2k2uQ3nRjPV9LYAeaSnd2MvA8RIog1Tb3K
# yHG6qnAHWpp9/7YK+wvsPHeoVvQGzGJW6Lfa0sijqnF5SzOTUDa2LwoSkCk9aZ3o
# 9gUDvWvAfYTwJ/3ZkdxmJ3ZlRrTdGMbraP3ziG5CEdCb9tLJAqlRCbD/GuJFD2qN
# lOGwToH65dbsKgdAkTEkrdjuJUrnAntUI5wFSMr146xLmcfPc8zyH3l/ulwDmGAi
# uj2Pnm0Z0e0atXk=
# SIG # End signature block
