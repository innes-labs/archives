# The script updates a Plugncast G3 server from an XML file containing domains, players and users.

# Parameters
# input 1 : Plugncast G3 URL
# input 2 : XML configuration file from PnC G2 (done by retrieveG2Config script)
# input 3 : Plugncast G3 super administrator login
# input 4 : Plugncast G3 super administrator password 
# input 5 : Device type attribution policy for Innes MAC addresses
#
# VERSION 1.10.10
#

param(
    [string] $i1 = $(throw "Please enter the Plugncast G3 URL"),
    [string] $i2 = $(throw "Please enter the Plugncast G2 config file path"),
    [string] $i3 = $(throw "Please enter the Plugncast super administrator login"),
    [string] $i4 = $(throw "Please enter the Plugncast super administrator password"),
    [string] $i5 = $(throw "Please enter the device type attribution policy for Innes MAC addresses")
)



$SleepDurationBeforeCommand = 100
$BaseServerUri = $i1
$Logfile = "setG3Config.log"

Function LogWrite {
    Param ([string]$logstring)
    Write-Host $logstring
    Add-content $Logfile -value $logstring
   
}

LogWrite( $i5 + " param 5")

# delete existing Log file
If ((Test-Path $Logfile) -eq $True) {
    Remove-Item -Path $Logfile
}

# test XML file presence
If ((Test-Path $i2) -ne $True) {
    LogWrite( "Error : " + $i2 + " not found. Exiting...")
    Exit
}


# Load config file extracted from Plugncast G2
[xml]$PnCG2ConfigFile = [xml](Get-Content -Path $i2)

# Accept all certificates for http connection.
add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

# Prepare authentication header
$user = $i3
$pass = $i4
$pair = "$($user):$($pass)"
$encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))
$basicAuthValue = "Basic $encodedCreds"
$Headers = @{
    Authorization = $basicAuthValue
}

# retreive all domains from XML file
[System.Xml.XmlElement] $root = $PnCG2ConfigFile.get_DocumentElement()
[System.Xml.XmlElement] $domains = $root.domains
[System.Xml.XmlElement] $domain = $null

Write-Host "Executing script : writing logs to setG3Config.log file..."

foreach ($domain in $domains.ChildNodes) {

    LogWrite( "")
    LogWrite( "Domain creation : " + $domain.Name)
    LogWrite( "----------------")

    $Body = @{
        target = "nsIAppliDomains.create"
        args   = @($domain.Name, "0")
    }
    $JsonBody = $Body | ConvertTo-Json
    Start-Sleep -m $SleepDurationBeforeCommand
    
    try {
        $ExecutedRequest = Invoke-WebRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri -Headers $Headers -Body $JsonBody
        LogWrite( "domain created : " + $domain.Name )
    }
    catch {
        LogWrite( $_.Exception.Message + $_.ErrorDetails.Message + " " + $domain.Name  )
    }

    $FrontalID = $Null
    $Body = @{
        target = "nsIPlugncastFrontals.createBuiltinWebdav"
        args   = @($domain.Name, "internal")
    }
    $JsonBody = $Body | ConvertTo-Json
    Start-Sleep -m $SleepDurationBeforeCommand
    try {
        $ExecutedRequest = Invoke-WebRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri -Headers $Headers -Body $JsonBody
        $FrontalID = $ExecutedRequest.Content
        $FrontalID = $FrontalID.Replace("`"", "")
        LogWrite( "Frontal created for domain : " + $domain.Name)
    }
    catch {
        #LogWrite( ($_.Exception.Message).ToString().Trim() )
        LogWrite( "Frontal already exists" )
    }
    
    if ( $FrontalID -eq $Null ) {
        LogWrite( "Retrieveing internal FrontalID")
        $Body = @{
            target = "nsIPlugncastFrontals.list"
            args   = @( $domain.Name )
        }   
        $JsonBody = $Body | ConvertTo-Json
        Start-Sleep -m $SleepDurationBeforeCommand
        try {
            $ExecutedRequest = Invoke-WebRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri -Headers $Headers -Body $JsonBody
            $FrontalsJson = $ExecutedRequest | ConvertFrom-Json
            foreach ($parsedFrontalId in $FrontalsJson.psobject.properties.name) {
                if ( $parsedFrontalId.StartsWith("urn:builtin")) {
                    $FrontalID = $parsedFrontalId
                    break
                }
            }
        }
        catch {
            LogWrite( ($_.Exception.Message).ToString().Trim() )
        }                 
    }

    LogWrite( "" )
    LogWrite( "Players creation for domain " + $domain.Name + " using frontal Id " + $FrontalID)
    LogWrite( "---------------------------")

    # uri to updates devices through xquery
    $uri = $BaseServerUri + ".domains/" + $domain.Name + "/.db/cmsdb"

    if ( $domain.players.GetType().FullName -eq "System.Xml.XmlElement") {
        [System.Xml.XmlElement] $players = $domain.players
   
        foreach ($player in $players.ChildNodes) {

            # create player by its Mac address 
            $Body = @{
                target = "nsIPlugncastFrontals.registerDevice"
                args   = @( $FrontalID, $player.MAC_ADDRESS, "mac")
            }    
            $JsonBody = $Body | ConvertTo-Json
            Start-Sleep -m $SleepDurationBeforeCommand
            try {
                $ExecutedRequest = Invoke-WebRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri -Headers $Headers -Body $JsonBody

                $deviceModelFamily = "dmb4xx-1"
                $deviceMiddlewareFamily = "gekkota-4"
                $MacAddressHexaString = $player.MAC_ADDRESS.Replace(":", "")
                $MacDecimal = [convert]::toint64($MacAddressHexaString, 16)

                # Identify DMC200 MAC addresses

                # prefixes Mac Address DMC200
                if ( $player.MAC_ADDRESS.StartsWith("00:14:2D") -or $player.MAC_ADDRESS.StartsWith("00:E0:4B") ) {
                    $deviceModelFamily = "dmc2xx-1"
                    $deviceMiddlewareFamily = "gekkota-3"
                }
                else {
                    if ( $player.MAC_ADDRESS.StartsWith("00:1C:E6") ) {
                        # fifth parameter contains the device type attribution policy for Innes MAC addresses (1 : DMB300-G3/DMB400-G4, 2 : SMA 200, 3, SMA 300)
                        if ( $i5 -eq "1" ) {
                            # Identify DMB300 MAC addresses
                            $LastMACAddressDM300Decimal = [convert]::toint64("001CE6022295", 16)
                            if ( $MacDecimal -le $LastMACAddressDM300Decimal -and $player.MAC_ADDRESS -ne "00:1C:E6:02:22:8A" -and $player.MAC_ADDRESS -ne "00:1C:E6:02:22:81" -and $player.MAC_ADDRESS -ne "00:1C:E6:02:22:82" -and $player.MAC_ADDRESS -ne "00:1C:E6:02:22:83" -and $player.MAC_ADDRESS -ne "00:1C:E6:02:22:84") {
                                $deviceModelFamily = "dmb3xx-1"
                                $deviceMiddlewareFamily = "gekkota-3"
                            }
                            # Identify DMB400 MAC addresses
                            $FirstMACAddressDM400Decimal = [convert]::toint64("001CE6022282", 16)
                            if ( $MacDecimal -ge $FirstMACAddressDM400Decimal -and $player.MAC_ADDRESS -ne "00:1C:E6:02:22:85" -and $player.MAC_ADDRESS -ne "00:1C:E6:02:22:86" -and $player.MAC_ADDRESS -ne "00:1C:E6:02:22:87" -and $player.MAC_ADDRESS -ne "00:1C:E6:02:22:88" -and $player.MAC_ADDRESS -ne "00:1C:E6:02:22:89" -and $player.MAC_ADDRESS -ne "00:1C:E6:02:22:95" ) {
                                $deviceModelFamily = "dmb4xx-1"
                                $deviceMiddlewareFamily = "gekkota-4"
                            }
                        }
                        if ( $i5 -eq "2" ) {
                            $deviceModelFamily = "sma2xx-1"
                            $deviceMiddlewareFamily = "gekkota-3"                            
                        }
                        if ( $i5 -eq "3" ) {
                            $deviceModelFamily = "sma3xx-1"
                            $deviceMiddlewareFamily = "gekkota-3"                            
                        }
                    }
                    else {
                        # for Non INNES MAC, set to Gekkota RT G3
                        $deviceModelFamily = "nt_iaxx-1"
                        $deviceMiddlewareFamily = "gekkota-3"
                    }
                }

                # create player information (label, device type)
                $Body = "declare namespace targets = `"ns.innes.plugncast.cms.targets`";"
                $Body = $Body + "targets:add(<target xmlns=`"ns.innes.plugncast.cms`" xmlns:xs=`"http://www.w3.org/2001/XMLSchema`" xmlns:xsi=`"http://www.w3.org/2001/XMLSchema-instance`">"
                $Body = $Body + "<id xsi:type=`"xs:string`"><![CDATA[" + $FrontalID + "_" + $player.MAC_ADDRESS + "]]></id>"
                $Body = $Body + "<type xsi:type=`"xs:string`"><![CDATA[digitalsignage]]></type>"
                $Body = $Body + "<scopeId xsi:type=`"xs:string`"><![CDATA[" + $FrontalID + "]]></scopeId>"
                $Body = $Body + "<targetId xsi:type=`"xs:string`"><![CDATA[" + $player.MAC_ADDRESS + "]]></targetId>"
                $Body = $Body + "<targetIdType xsi:type=`"xs:string`"><![CDATA[mac]]></targetIdType>"
                $Body = $Body + "<label xsi:type=`"xs:string`"><![CDATA[" + $player.Label + "]]></label>"
                $Body = $Body + "<labelEnabled xsi:type=`"xs:boolean`">true</labelEnabled>"
                $Body = $Body + "<middlewareFamily xsi:type=`"xs:string`"><![CDATA[" + $deviceMiddlewareFamily + "]]></middlewareFamily>"
                $Body = $Body + "<modelFamily xsi:type=`"xs:string`"><![CDATA[" + $deviceModelFamily + "]]></modelFamily>"
                $Body = $Body + "</target>)"

                Start-Sleep -m $SleepDurationBeforeCommand

                try {
                    $ExecutedRequest = Invoke-WebRequest -Method 'POST' -ContentType 'application/xquery' -Uri $uri -Headers $Headers -Body $Body
                    LogWrite( $player.Label + " " + $player.MAC_ADDRESS + " created")
                }
                catch {
                    LogWrite( "Player already exists" )

                    # exception during CMS attributes creation, trying to update instead

                    # update player information (label, device type)
                    $Body = "declare namespace targets = `"ns.innes.plugncast.cms.targets`";"
                    $Body = $Body + "targets:updateProperties(<target xmlns=`"ns.innes.plugncast.cms`" xmlns:xs=`"http://www.w3.org/2001/XMLSchema`" xmlns:xsi=`"http://www.w3.org/2001/XMLSchema-instance`">"
                    $Body = $Body + "<id xsi:type=`"xs:string`"><![CDATA[" + $FrontalID + "_" + $player.MAC_ADDRESS + "]]></id>"
                    $Body = $Body + "<type xsi:type=`"xs:string`"><![CDATA[digitalsignage]]></type>"
                    $Body = $Body + "<scopeId xsi:type=`"xs:string`"><![CDATA[" + $FrontalID + "]]></scopeId>"
                    $Body = $Body + "<targetId xsi:type=`"xs:string`"><![CDATA[" + $player.MAC_ADDRESS + "]]></targetId>"
                    $Body = $Body + "<targetIdType xsi:type=`"xs:string`"><![CDATA[mac]]></targetIdType>"
                    $Body = $Body + "<label xsi:type=`"xs:string`"><![CDATA[" + $player.Label + "]]></label>"
                    $Body = $Body + "<labelEnabled xsi:type=`"xs:boolean`">true</labelEnabled>"
                    $Body = $Body + "<middlewareFamily xsi:type=`"xs:string`"><![CDATA[" + $deviceMiddlewareFamily + "]]></middlewareFamily>"
                    $Body = $Body + "<modelFamily xsi:type=`"xs:string`"><![CDATA[" + $deviceModelFamily + "]]></modelFamily>"
                    $Body = $Body + "</target>)"
                    Start-Sleep -m $SleepDurationBeforeCommand

                    try {
                        $ExecutedRequest = Invoke-WebRequest -Method 'POST' -ContentType 'application/xquery' -Uri $uri -Headers $Headers -Body $Body
                        LogWrite( $player.Label + " " + $player.MAC_ADDRESS + " updated" )
                    }
                    catch {
                        LogWrite( "Exception during update" )
                        LogWrite( ($_.Exception).ToString().Trim() )
                        LogWrite( ($_.Exception.Message).ToString().Trim() )
                    } 
                } 
            }
            catch {
                LogWrite( ($_.Exception.Message).ToString().Trim() )
                LogWrite( ($_.ErrorDetails.Message).ToString().Trim() )    
            }   
        }
    }

    LogWrite( "")
    LogWrite( "Users")
    LogWrite( "-------")

    if ( $domain.users.GetType().FullName -eq "System.Xml.XmlElement") {

        [System.Xml.XmlElement] $users = $domain.users
        foreach ($user in $users.ChildNodes) {

            $Body = @{
                target = "nsIAppliUsers.isLoginFree"
                args   = @( $user.Name )
            }    
            $JsonBody = $Body | ConvertTo-Json
            Start-Sleep -m $SleepDurationBeforeCommand
            try {
                $ExecutedRequest = Invoke-WebRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri -Headers $Headers -Body $JsonBody
                $UserDoesNotExists = $ExecutedRequest.Content

                if ( $UserDoesNotExists -eq "true" ) {

                    $role = "domain-editor"
                    if ( $user.Administrator -eq "true" ) {
                        $role = "domain-administrator"
                    }

                    $Body = @{
                        target = "nsIAppliUsers.createBuiltin"
                        args   = @( $user.Name, $user.Password, $role, @( $domain.Name ) )
                    } 
                    $JsonBody = $Body | ConvertTo-Json

                    try {
                        $ExecutedRequest = Invoke-WebRequest -Method 'POST' -ContentType 'application/json+rpc' -Uri $BaseServerUri -Headers $Headers -Body $JsonBody
                        LogWrite( $user.Name + " user created")
                    }
                    catch {
                        LogWrite( ($_.Exception.Message).ToString().Trim() )
                        LogWrite( ($_.ErrorDetails.Message).ToString().Trim() )    
                    }                 
                }
                else {
                    LogWrite( $user.Name + " already exists. Please update doamins for this user manually.")
                }
            }
            catch {
                LogWrite( ($_.Exception.Message).ToString().Trim() )
                LogWrite( ($_.ErrorDetails.Message).ToString().Trim() )    
            }            
        }    
    }
}
LogWrite( " " )  
LogWrite( "Done !" )    

