# The script rename a domain in a PlugnCast G3 server.

# Parameters
# input 1 : Plugncast G3 data directory path, for exemple "C:\Users\Public\Documents\Innes Plugncast Server" 
# input 2 : The old domain name
# input 3 : The new domain name
#
# VERSION 1.10.10
#

param(
    [string] $i1 = $(throw "Please enter the Plugncast G3 data directoy path"),
    [string] $i2 = $(throw "Please enter the domain name to be renamed"),
    [string] $i3 = $(throw "Please enter the new domain name")
)



$DataDirectory = $i1
$OldName = $i2
$NewName = $i3
$Logfile = "setG3Config.log"

Function LogWrite {
    Param ([string]$logstring)
    Write-Host $logstring
    Add-content $Logfile -value $logstring
   
}
Function Replace {
    Param ([string]$file, [string]$old, [string]$new)
    LogWrite("Replace: file = $file old=$old new=$new")
    If ((Test-Path "$file") -ne $True) {
        LogWrite( "Replace: file '" + $file + "' not found.")
    }
    else {
        If ($debug) {
            (Get-Content -path $file -Raw) -replace "$old","$new"
        }
        ((Get-Content -path $file -Raw) -replace "$old","$new") | Set-Content -Path $file
    }
}

$ProcessActive = Get-Process "plugncast" -ErrorAction SilentlyContinue

if ($ProcessActive)
{
    LogWrite( "Error : pluncast running. Exiting...")
    Exit
}
# delete existing Log file
If ((Test-Path $Logfile) -eq $True) {
    Remove-Item -Path $Logfile
}

# test data directory presence
If ((Test-Path $DataDirectory) -ne $True) {
    LogWrite( "Error : directory '" + $i1 + "' not found. Exiting...")
    Exit
}
# test old domain presence
If ((Test-Path "$DataDirectory\.domains\$OldName") -ne $True) {
    LogWrite( "Error : domain '" + $OldName + "' not found. Exiting...")
    Exit
}
# Make a copy of directory
#Copy-Item "$DataDirectory" -Destination "$DataDirectory.save" -Recurse
# Replace domain in configuration files
Replace "$DataDirectory\.profile\preferences\domains.js" "innes.appli.domains.$OldName" "innes.appli.domains.$NewName"
Replace "$DataDirectory\.profile\preferences\frontals.js" "innes.plugncast.frontals.builtins.webdav.$OldName" "innes.plugncast.frontals.builtins.webdav.$NewName"
Replace "$DataDirectory\.profile\preferences\frontals.js" "/.webdav/$OldName" "/.webdav/$NewName"
Replace "$DataDirectory\.profile\preferences\frontals.js" ":$OldName" ":$NewName"
Replace "$DataDirectory\.profile\preferences\frontals.js" "\\`"$OldName\\`"" "\`"$NewName\`""
Replace "$DataDirectory\.profile\preferences\users.js" "\\`"$OldName\\`"" "\`"$NewName\`""

Replace "$DataDirectory\.profile\preferences\usergroups.js" "\\`"$OldName\\`"" "\`"$NewName\`""
Replace "$DataDirectory\.profile\preferences\appis.js" "\\`"$OldName\\`"" "\`"$NewName\`""
Replace "$DataDirectory\.profile\preferences\tasks.js" "\\`"$OldName\\`"" "\`"$NewName\`""
Replace "$DataDirectory\.shared\io_uuids.json" "/.domains/$OldName" "/.domains/$NewName"
Replace "$DataDirectory\.shared\owners.json" ":$OldName" ":$NewName"

# Rename files and directory
Rename-Item -Path "$DataDirectory\.domains\$OldName" -NewName "$NewName"
If ((Test-Path "$DataDirectory\.frontals\.webdav\$OldName") -eq $True) {
    Rename-Item -Path "$DataDirectory\.frontals\.webdav\$OldName" -NewName "$NewName"
}

LogWrite( " " )  
LogWrite( "Done !" )    

