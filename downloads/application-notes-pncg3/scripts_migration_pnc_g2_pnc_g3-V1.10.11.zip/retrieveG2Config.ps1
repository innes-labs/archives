# This Powershell script retreives a PlugnCast G2 configuration and writes it to an XML file

# input : Plugncast G2 installation directory
# output : XML file (name provided in the second parameter)
# 
# VERSION 1.10.10
#

param(
    [string] $i = $(throw "Please enter an input folder name"),
    [string] $o = $(throw "Please enter the output file path")
)

$FileExists = Test-Path $i 
If ($FileExists -ne $True) {
    Write-Host "Plugncast G2 server path does not exist. Exiting..."
    Exit
}

# loading .htpasswd file containing users
$usersFile = Get-Content $i"\.shared\.configuration\.htpasswd"

# loading .htaccounts file to list admin users
[xml]$adminFile = Get-Content $i"\.shared\.configuration\.htaccounts.xml"

# XML output file
$xmlo = new-object System.Xml.XmlDocument

# XML declaration
$xmldecl = $xmlo.CreateXmlDeclaration("1.0", "UTF-8", "yes")
$xmlo.AppendChild($xmldecl) | Out-Null

# root node
$rootNode = $xmlo.CreateNode("element","PnCG2_configuration",$null)

# "domains" element
$domainsNode = $xmlo.CreateNode("element","domains",$null)
$rootNode.AppendChild($domainsNode) | Out-Null

# browse sub directories in \.accounts to get the domains
foreach ($domain in Get-ChildItem -Directory -Path $i"\.accounts" -Exclude ".default" -Name) {

    $domainNode = $xmlo.CreateNode("element","domain",$null)
    $domainNode.SetAttribute("Name",$domain)
    $domainsNode.AppendChild($domainNode) | Out-Null
    $playersNode = $xmlo.CreateNode("element","players",$null)
    $domainNode.AppendChild($playersNode) | Out-Null

    # browse sub directories in .players to list players inside domain
    foreach ($players in Get-ChildItem -Directory -Path $i"\.accounts\"$domain"\.players" -Exclude ".DAV") {
        [xml]$playerXmlMetadata = Get-Content $players"\META-INF\player.xml"

        $playerNode = $xmlo.CreateNode("element","player",$null)
        $playerNode.SetAttribute("Label",$playerXmlMetadata.player.label)
        $playerNode.SetAttribute("MAC_ADDRESS",$playerXmlMetadata.player.mac_address)
        $playersNode.AppendChild($playerNode) | Out-Null
    }  

    # "users" element
    $usersNode = $xmlo.CreateNode("element","users",$null)
    $domainNode.AppendChild($usersNode) | Out-Null

    # browse  .htpasswd to list users
    foreach ($user in $usersFile) {
        if ($user.IndexOf("@") -gt -1 ) {
            if ($user.IndexOf(":") -gt -1 ) {
                $domainInPlayerLogin = $user.Substring($user.IndexOf("@")+1,$user.IndexOf(":")-$user.IndexOf("@")-1 )
                if ( $domainInPlayerLogin -eq $domain ) {
                    $userNode = $xmlo.CreateNode("element","user",$null)
                    $userName = $user.Substring(0,$user.IndexOf(":")).Trim()
                    $userPassword = $user.Substring($user.IndexOf(":")+1).Trim()
                    $userNode.SetAttribute("Name", $userName)
                    $userNode.SetAttribute("Password",$userPassword)

                    # retreive all domains administrators
                    $domainAdmins = $adminFile | Select-XML -XPath "//domain_administrator"
                    foreach ($domainadmin in $domainAdmins) {
                        $domainadminString = $domainadmin.ToString().Trim()
                        if ($domainadminString -eq $userName ) {
                            $userNode.SetAttribute("Administrator","true")
                            break
                        }
                    }
                    $usersNode.AppendChild($userNode) | Out-Null     
                }
            }
        }
    }

}

$xmlo.AppendChild($rootNode) | Out-Null
$xmlo.Save($o)

Write-Host "Output file saved to : " $o
Write-Host " "